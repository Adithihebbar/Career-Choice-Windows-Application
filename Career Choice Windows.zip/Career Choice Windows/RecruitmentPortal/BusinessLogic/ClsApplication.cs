﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Windows.Forms;
/// <summary>
/// Summary description for ClsApplication
/// </summary>
public class ClsApplication
{
    DataManager DBManager = new DataManager();

    public ClsApplication()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int ApplicationTransaction(int Opt, int apply_Mid, int apply_regMid, string apply_jobcode, string apply_jobpost,
        string apply_reference_no, string apply_name, string apply_mobile_no, string apply_email, string apply_dob, string apply_nationality,
        string apply_marital_status, string apply_gender, string apply_min_qualification, string apply_experience_type, string apply_total_experience,
         string apply_resume, string apply_photo, string apply_payment_receipt, string status, int UserId,
        string apply_extra1, string apply_extra2, string apply_extra3, string apply_extra4, string apply_extra5)
    {
        int result = 0;
        try
        {
            bool blnattemptconn = DBManager.OpenSQLConnection();
            if (blnattemptconn == false)
            {
                DBManager.CloseConnection();
                DBManager.OpenSQLConnection();
            }
            SqlCommand cmd = new SqlCommand("usp_Application");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = DBManager.myConn;
            cmd.Parameters.AddWithValue("@opt", Opt);
            cmd.Parameters.AddWithValue("@apply_Mid", apply_Mid);
            cmd.Parameters.AddWithValue("@apply_regMid", apply_regMid);
            cmd.Parameters.AddWithValue("@apply_jobcode", apply_jobcode);
            cmd.Parameters.AddWithValue("@apply_jobpost", apply_jobpost);
            cmd.Parameters.AddWithValue("@apply_reference_no", apply_reference_no);
            cmd.Parameters.AddWithValue("@apply_name", apply_name);
            cmd.Parameters.AddWithValue("@apply_mobile_no", apply_mobile_no);
            cmd.Parameters.AddWithValue("@apply_email", apply_email);
            cmd.Parameters.AddWithValue("@apply_dob", apply_dob);
            cmd.Parameters.AddWithValue("@apply_nationality", apply_nationality);
            cmd.Parameters.AddWithValue("@apply_marital_status", apply_marital_status);
            cmd.Parameters.AddWithValue("@apply_gender", apply_gender);
            cmd.Parameters.AddWithValue("@apply_min_qualification", apply_min_qualification);
            cmd.Parameters.AddWithValue("@apply_experience_type", apply_experience_type);
            cmd.Parameters.AddWithValue("@apply_total_experience", apply_total_experience);
            cmd.Parameters.AddWithValue("@apply_payment_receipt", apply_payment_receipt);
            cmd.Parameters.AddWithValue("@apply_resume", apply_resume);
            cmd.Parameters.AddWithValue("@apply_photo", apply_photo);
            cmd.Parameters.AddWithValue("@apply_status", status);
            cmd.Parameters.AddWithValue("@apply_extra1", apply_extra1);
            cmd.Parameters.AddWithValue("@apply_extra2", apply_extra2);
            cmd.Parameters.AddWithValue("@apply_extra3", apply_extra3);
            cmd.Parameters.AddWithValue("@apply_extra4", apply_extra4);
            cmd.Parameters.AddWithValue("@apply_extra5", apply_extra5);
            cmd.Parameters.AddWithValue("@UserId", UserId);

            result = cmd.ExecuteNonQuery();
           // MessageBox.Show("Rows Affected : " + result);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "SQL Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);

            return 0;
        }
        finally
        {
            DBManager.CloseConnection();
        }
        return result;
    }


}


﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ClsJob
/// </summary>
public class ClsJob
{
    DataManager DBManager = new DataManager();

    public ClsJob()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int JobTransaction(int Opt, int job_Mid, string job_title, string job_code, string job_description, string job_location,
        string job_salary, string job_min_experience, string job_age_limit, string job_status,
        string job_extra1, string job_extra2, string job_extra3, string job_extra4, string job_extra5, int UserId)
    {
        int result = 0;
        try
        {
            bool blnattemptconn = DBManager.OpenSQLConnection();
            if (blnattemptconn == false)
            {
                DBManager.CloseConnection();
                DBManager.OpenSQLConnection();
            }
            SqlCommand cmd = new SqlCommand("usp_jobs");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = DBManager.myConn;
            cmd.Parameters.AddWithValue("@opt", Opt);
            cmd.Parameters.AddWithValue("@job_Mid", job_Mid);
            cmd.Parameters.AddWithValue("@job_title", job_title);
            cmd.Parameters.AddWithValue("@job_code", job_code);
            cmd.Parameters.AddWithValue("@job_description", job_description);
            cmd.Parameters.AddWithValue("@job_location", job_location);
            cmd.Parameters.AddWithValue("@job_salary", job_salary);
            cmd.Parameters.AddWithValue("@job_min_experience", job_min_experience);
            cmd.Parameters.AddWithValue("@job_age_limit", job_age_limit);
            cmd.Parameters.AddWithValue("@job_status", job_status);
            cmd.Parameters.AddWithValue("@job_extra1", job_extra1);
            cmd.Parameters.AddWithValue("@job_extra2", job_extra2);
            cmd.Parameters.AddWithValue("@job_extra3", job_extra3);
            cmd.Parameters.AddWithValue("@job_extra4", job_extra4);
            cmd.Parameters.AddWithValue("@job_extra5", job_extra5);
            cmd.Parameters.AddWithValue("@UserId", UserId);

            result = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ex.Data.Clear();
            result = 0;
        }
        finally
        {
            DBManager.CloseConnection();
        }
        return result;
    }
}

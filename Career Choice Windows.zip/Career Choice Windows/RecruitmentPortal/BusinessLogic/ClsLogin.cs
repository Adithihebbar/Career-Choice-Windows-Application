﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for ClsLogin
/// </summary>
public class ClsLogin
{
    DataManager dm = new DataManager();

    public ClsLogin()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public int Login(int opt, int login_Mid, string login_username, string login_password)
    {
        int res = 0;
        try
        {
            bool blnAttmpt = dm.OpenSQLConnection();
            if (blnAttmpt == true)
            {
                SqlCommand cmd = new SqlCommand("usp_login");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = dm.myConn;
                cmd.Parameters.AddWithValue("@Opt", opt);
                cmd.Parameters.AddWithValue("@login_Mid", login_Mid);

                cmd.Parameters.AddWithValue("@login_username", login_username);
                cmd.Parameters.AddWithValue("@login_password", login_password);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    res = int.Parse(dr["login_Mid"].ToString());
                }
                return res;
            }
            else
            {
                return res;
            }
        }
        catch (Exception ex)
        {
            ex.Data.Clear();
            return res;
        }
        finally
        {
            dm.CloseConnection();
        }
    }
}
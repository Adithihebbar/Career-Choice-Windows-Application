﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ClsRegistration
/// </summary>
public class ClsRegistration
{
    DataManager DBManager = new DataManager();

    public ClsRegistration()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int RegistrationTransaction(int Opt, int reg_Mid, string reg_name, string reg_email, string reg_mobile,
        string reg_address, string reg_password, string reg_extra1, string reg_extra2, string reg_extra3,
        string reg_extra4, string reg_extra5, int UserId)
    {
        int result = 0;
        try
        {
            bool blnattemptconn = DBManager.OpenSQLConnection();
            if (blnattemptconn == false)
            {
                DBManager.CloseConnection();
                DBManager.OpenSQLConnection();
            }
            SqlCommand cmd = new SqlCommand("usp_registration");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = DBManager.myConn;
            cmd.Parameters.AddWithValue("@opt", Opt);
            cmd.Parameters.AddWithValue("@reg_Mid", reg_Mid);
            cmd.Parameters.AddWithValue("@reg_name", reg_name);
            cmd.Parameters.AddWithValue("@reg_email", reg_email);
            cmd.Parameters.AddWithValue("@reg_mobile", reg_mobile);
            cmd.Parameters.AddWithValue("@reg_address", reg_address);
            cmd.Parameters.AddWithValue("@reg_password", reg_password);

            cmd.Parameters.AddWithValue("@reg_extra1", reg_extra1);
            cmd.Parameters.AddWithValue("@reg_extra2", reg_extra2);
            cmd.Parameters.AddWithValue("@reg_extra3", reg_extra3);
            cmd.Parameters.AddWithValue("@reg_extra4", reg_extra4);
            cmd.Parameters.AddWithValue("@reg_extra5", reg_extra5);
            cmd.Parameters.AddWithValue("@UserId", UserId);

            result = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ex.Data.Clear();
            result = 0;
        }
        finally
        {
            DBManager.CloseConnection();
        }
        return result;
    }



    public int Login(int opt, string reg_email, string reg_password)
    {
        int res = 0;
        try
        {
            bool blnAttmpt = DBManager.OpenSQLConnection();
            if (blnAttmpt == true)
            {
                SqlCommand cmd = new SqlCommand("usp_registration");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = DBManager.myConn;
                cmd.Parameters.AddWithValue("@opt", opt);
                cmd.Parameters.AddWithValue("@reg_email", reg_email);
                cmd.Parameters.AddWithValue("@reg_password", reg_password);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    res = int.Parse(dr["reg_Mid"].ToString());
                }
                return res;
            }
            else
            {
                return res;
            }
        }
        catch (Exception ex)
        {
            ex.Data.Clear();
            return res;
        }
        finally
        {
            DBManager.CloseConnection();
        }
    }
}
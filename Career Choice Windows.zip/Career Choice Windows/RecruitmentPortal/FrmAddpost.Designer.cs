﻿namespace RecruitmentPortal
{
    partial class FrmAddpost
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnljoblist = new System.Windows.Forms.Panel();
            this.lblheading = new System.Windows.Forms.Label();
            this.btnaddpost = new System.Windows.Forms.Button();
            this.dgvjoblist = new System.Windows.Forms.DataGridView();
            this.jobmid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colslno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.edit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.jobtitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jobcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jobdescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.joblocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jobsalary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.minexperience = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jobstatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnexportexcel = new System.Windows.Forms.Button();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.txtJobLocation = new System.Windows.Forms.TextBox();
            this.txtJobTitle = new System.Windows.Forms.TextBox();
            this.txtJobCode = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblJobLocation = new System.Windows.Forms.Label();
            this.lblJobTitle = new System.Windows.Forms.Label();
            this.lblJobCode = new System.Windows.Forms.Label();
            this.pnladdjob = new System.Windows.Forms.Panel();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblhead = new System.Windows.Forms.Label();
            this.txtagelimit = new System.Windows.Forms.TextBox();
            this.txtminexp = new System.Windows.Forms.TextBox();
            this.txtsalary = new System.Windows.Forms.TextBox();
            this.txtlocation = new System.Windows.Forms.TextBox();
            this.txtdescription = new System.Windows.Forms.TextBox();
            this.txtcode = new System.Windows.Forms.TextBox();
            this.txttitle = new System.Windows.Forms.TextBox();
            this.lblstatuss = new System.Windows.Forms.Label();
            this.rdbinactive = new System.Windows.Forms.RadioButton();
            this.rdbactive = new System.Windows.Forms.RadioButton();
            this.lblage = new System.Windows.Forms.Label();
            this.lblminexp = new System.Windows.Forms.Label();
            this.lblsalary = new System.Windows.Forms.Label();
            this.lbllocation = new System.Windows.Forms.Label();
            this.lbldescription = new System.Windows.Forms.Label();
            this.lblcode = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.pnlmain = new System.Windows.Forms.Panel();
            this.pnljoblist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvjoblist)).BeginInit();
            this.panel3.SuspendLayout();
            this.pnladdjob.SuspendLayout();
            this.pnlmain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnljoblist
            // 
            this.pnljoblist.BackColor = System.Drawing.Color.AliceBlue;
            this.pnljoblist.Controls.Add(this.lblheading);
            this.pnljoblist.Controls.Add(this.btnaddpost);
            this.pnljoblist.Controls.Add(this.dgvjoblist);
            this.pnljoblist.Controls.Add(this.panel3);
            this.pnljoblist.Location = new System.Drawing.Point(115, 0);
            this.pnljoblist.Name = "pnljoblist";
            this.pnljoblist.Size = new System.Drawing.Size(1186, 780);
            this.pnljoblist.TabIndex = 1;
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.BackColor = System.Drawing.Color.Transparent;
            this.lblheading.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.Location = new System.Drawing.Point(497, 9);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(121, 32);
            this.lblheading.TabIndex = 3;
            this.lblheading.Text = "Job List";
            // 
            // btnaddpost
            // 
            this.btnaddpost.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnaddpost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnaddpost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddpost.Location = new System.Drawing.Point(983, 36);
            this.btnaddpost.Name = "btnaddpost";
            this.btnaddpost.Size = new System.Drawing.Size(100, 41);
            this.btnaddpost.TabIndex = 2;
            this.btnaddpost.Text = "Add Post";
            this.btnaddpost.UseVisualStyleBackColor = false;
            this.btnaddpost.Click += new System.EventHandler(this.btnaddpost_Click);
            // 
            // dgvjoblist
            // 
            this.dgvjoblist.AllowUserToAddRows = false;
            this.dgvjoblist.AllowUserToDeleteRows = false;
            this.dgvjoblist.AllowUserToResizeColumns = false;
            this.dgvjoblist.AllowUserToResizeRows = false;
            this.dgvjoblist.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvjoblist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvjoblist.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvjoblist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvjoblist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.jobmid,
            this.colslno,
            this.edit,
            this.jobtitle,
            this.jobcode,
            this.jobdescription,
            this.joblocation,
            this.jobsalary,
            this.minexperience,
            this.age,
            this.jobstatus,
            this.delete});
            this.dgvjoblist.Location = new System.Drawing.Point(15, 347);
            this.dgvjoblist.Name = "dgvjoblist";
            this.dgvjoblist.RowHeadersVisible = false;
            this.dgvjoblist.RowTemplate.Height = 24;
            this.dgvjoblist.Size = new System.Drawing.Size(1147, 360);
            this.dgvjoblist.TabIndex = 1;
            this.dgvjoblist.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvjoblist_CellContentClick);
            this.dgvjoblist.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvjoblist_RowPostPaint);
            // 
            // jobmid
            // 
            this.jobmid.DataPropertyName = "job_Mid";
            this.jobmid.HeaderText = "Job Mid";
            this.jobmid.Name = "jobmid";
            this.jobmid.ReadOnly = true;
            this.jobmid.Visible = false;
            // 
            // colslno
            // 
            this.colslno.HeaderText = "Sl.No";
            this.colslno.Name = "colslno";
            this.colslno.ReadOnly = true;
            // 
            // edit
            // 
            this.edit.HeaderText = "Edit";
            this.edit.Name = "edit";
            this.edit.ReadOnly = true;
            this.edit.Text = "Edit";
            this.edit.UseColumnTextForButtonValue = true;
            // 
            // jobtitle
            // 
            this.jobtitle.DataPropertyName = "job_title";
            this.jobtitle.HeaderText = "Job Title";
            this.jobtitle.Name = "jobtitle";
            this.jobtitle.ReadOnly = true;
            // 
            // jobcode
            // 
            this.jobcode.DataPropertyName = "job_code";
            this.jobcode.HeaderText = "Job Code";
            this.jobcode.Name = "jobcode";
            this.jobcode.ReadOnly = true;
            // 
            // jobdescription
            // 
            this.jobdescription.DataPropertyName = "job_description";
            this.jobdescription.HeaderText = "Job Description";
            this.jobdescription.Name = "jobdescription";
            this.jobdescription.ReadOnly = true;
            // 
            // joblocation
            // 
            this.joblocation.DataPropertyName = "job_location";
            this.joblocation.HeaderText = "Job Location";
            this.joblocation.Name = "joblocation";
            this.joblocation.ReadOnly = true;
            // 
            // jobsalary
            // 
            this.jobsalary.DataPropertyName = "job_salary";
            this.jobsalary.HeaderText = "Job Salary";
            this.jobsalary.Name = "jobsalary";
            this.jobsalary.ReadOnly = true;
            // 
            // minexperience
            // 
            this.minexperience.DataPropertyName = "job_min_experience";
            this.minexperience.HeaderText = "Minimum Experience";
            this.minexperience.Name = "minexperience";
            this.minexperience.ReadOnly = true;
            // 
            // age
            // 
            this.age.DataPropertyName = "job_age_limit";
            this.age.HeaderText = "Age Limit";
            this.age.Name = "age";
            this.age.ReadOnly = true;
            // 
            // jobstatus
            // 
            this.jobstatus.DataPropertyName = "job_status";
            this.jobstatus.HeaderText = "Job Status";
            this.jobstatus.Name = "jobstatus";
            this.jobstatus.ReadOnly = true;
            // 
            // delete
            // 
            this.delete.HeaderText = "Delete";
            this.delete.Name = "delete";
            this.delete.ReadOnly = true;
            this.delete.Text = "Delete";
            this.delete.UseColumnTextForButtonValue = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel3.Controls.Add(this.dtpToDate);
            this.panel3.Controls.Add(this.dtpFromDate);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.btnexportexcel);
            this.panel3.Controls.Add(this.btnrefresh);
            this.panel3.Controls.Add(this.btnsearch);
            this.panel3.Controls.Add(this.cmbStatus);
            this.panel3.Controls.Add(this.txtJobLocation);
            this.panel3.Controls.Add(this.txtJobTitle);
            this.panel3.Controls.Add(this.txtJobCode);
            this.panel3.Controls.Add(this.lblStatus);
            this.panel3.Controls.Add(this.lblJobLocation);
            this.panel3.Controls.Add(this.lblJobTitle);
            this.panel3.Controls.Add(this.lblJobCode);
            this.panel3.Location = new System.Drawing.Point(36, 115);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1097, 213);
            this.panel3.TabIndex = 0;
            // 
            // dtpToDate
            // 
            this.dtpToDate.CustomFormat = "dd-MM-yyyy";
            this.dtpToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpToDate.Location = new System.Drawing.Point(857, 97);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(141, 27);
            this.dtpToDate.TabIndex = 15;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.CustomFormat = "dd-MM-yyyy";
            this.dtpFromDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(525, 102);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(141, 27);
            this.dtpFromDate.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(742, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "To Date :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(380, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "From Date :";
            // 
            // btnexportexcel
            // 
            this.btnexportexcel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnexportexcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnexportexcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexportexcel.Location = new System.Drawing.Point(679, 151);
            this.btnexportexcel.Name = "btnexportexcel";
            this.btnexportexcel.Size = new System.Drawing.Size(165, 41);
            this.btnexportexcel.TabIndex = 10;
            this.btnexportexcel.Text = "Export to Excel";
            this.btnexportexcel.UseVisualStyleBackColor = false;
            this.btnexportexcel.Click += new System.EventHandler(this.btnexportexcel_Click);
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.Location = new System.Drawing.Point(525, 151);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(100, 41);
            this.btnrefresh.TabIndex = 9;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(358, 151);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(100, 41);
            this.btnsearch.TabIndex = 8;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // cmbStatus
            // 
            this.cmbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Location = new System.Drawing.Point(148, 97);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(130, 28);
            this.cmbStatus.TabIndex = 7;
            // 
            // txtJobLocation
            // 
            this.txtJobLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobLocation.Location = new System.Drawing.Point(857, 31);
            this.txtJobLocation.Name = "txtJobLocation";
            this.txtJobLocation.Size = new System.Drawing.Size(130, 28);
            this.txtJobLocation.TabIndex = 6;
            // 
            // txtJobTitle
            // 
            this.txtJobTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobTitle.Location = new System.Drawing.Point(495, 31);
            this.txtJobTitle.Name = "txtJobTitle";
            this.txtJobTitle.Size = new System.Drawing.Size(130, 28);
            this.txtJobTitle.TabIndex = 5;
            // 
            // txtJobCode
            // 
            this.txtJobCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtJobCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJobCode.Location = new System.Drawing.Point(148, 31);
            this.txtJobCode.Name = "txtJobCode";
            this.txtJobCode.Size = new System.Drawing.Size(130, 28);
            this.txtJobCode.TabIndex = 4;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(45, 97);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(75, 20);
            this.lblStatus.TabIndex = 3;
            this.lblStatus.Text = "Status :";
            // 
            // lblJobLocation
            // 
            this.lblJobLocation.AutoSize = true;
            this.lblJobLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobLocation.Location = new System.Drawing.Point(701, 34);
            this.lblJobLocation.Name = "lblJobLocation";
            this.lblJobLocation.Size = new System.Drawing.Size(129, 20);
            this.lblJobLocation.TabIndex = 2;
            this.lblJobLocation.Text = "Job Location :";
            // 
            // lblJobTitle
            // 
            this.lblJobTitle.AutoSize = true;
            this.lblJobTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobTitle.Location = new System.Drawing.Point(376, 34);
            this.lblJobTitle.Name = "lblJobTitle";
            this.lblJobTitle.Size = new System.Drawing.Size(94, 20);
            this.lblJobTitle.TabIndex = 1;
            this.lblJobTitle.Text = "Job Title :";
            // 
            // lblJobCode
            // 
            this.lblJobCode.AutoSize = true;
            this.lblJobCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobCode.Location = new System.Drawing.Point(29, 34);
            this.lblJobCode.Name = "lblJobCode";
            this.lblJobCode.Size = new System.Drawing.Size(100, 20);
            this.lblJobCode.TabIndex = 0;
            this.lblJobCode.Text = "Job Code :";
            // 
            // pnladdjob
            // 
            this.pnladdjob.BackColor = System.Drawing.Color.AliceBlue;
            this.pnladdjob.Controls.Add(this.btnUpdate);
            this.pnladdjob.Controls.Add(this.btnBack);
            this.pnladdjob.Controls.Add(this.btnCancel);
            this.pnladdjob.Controls.Add(this.btnSave);
            this.pnladdjob.Controls.Add(this.lblhead);
            this.pnladdjob.Controls.Add(this.txtagelimit);
            this.pnladdjob.Controls.Add(this.txtminexp);
            this.pnladdjob.Controls.Add(this.txtsalary);
            this.pnladdjob.Controls.Add(this.txtlocation);
            this.pnladdjob.Controls.Add(this.txtdescription);
            this.pnladdjob.Controls.Add(this.txtcode);
            this.pnladdjob.Controls.Add(this.txttitle);
            this.pnladdjob.Controls.Add(this.lblstatuss);
            this.pnladdjob.Controls.Add(this.rdbinactive);
            this.pnladdjob.Controls.Add(this.rdbactive);
            this.pnladdjob.Controls.Add(this.lblage);
            this.pnladdjob.Controls.Add(this.lblminexp);
            this.pnladdjob.Controls.Add(this.lblsalary);
            this.pnladdjob.Controls.Add(this.lbllocation);
            this.pnladdjob.Controls.Add(this.lbldescription);
            this.pnladdjob.Controls.Add(this.lblcode);
            this.pnladdjob.Controls.Add(this.lbltitle);
            this.pnladdjob.Location = new System.Drawing.Point(50, 0);
            this.pnladdjob.Name = "pnladdjob";
            this.pnladdjob.Size = new System.Drawing.Size(693, 694);
            this.pnladdjob.TabIndex = 2;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(155, 598);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(100, 41);
            this.btnUpdate.TabIndex = 21;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(523, 39);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 41);
            this.btnBack.TabIndex = 20;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(344, 598);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 41);
            this.btnCancel.TabIndex = 19;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(155, 598);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 41);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblhead
            // 
            this.lblhead.AutoSize = true;
            this.lblhead.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhead.Location = new System.Drawing.Point(246, 9);
            this.lblhead.Name = "lblhead";
            this.lblhead.Size = new System.Drawing.Size(126, 32);
            this.lblhead.TabIndex = 17;
            this.lblhead.Text = "Add Job";
            // 
            // txtagelimit
            // 
            this.txtagelimit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtagelimit.Location = new System.Drawing.Point(318, 431);
            this.txtagelimit.Name = "txtagelimit";
            this.txtagelimit.Size = new System.Drawing.Size(147, 27);
            this.txtagelimit.TabIndex = 16;
            // 
            // txtminexp
            // 
            this.txtminexp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtminexp.Location = new System.Drawing.Point(318, 375);
            this.txtminexp.Name = "txtminexp";
            this.txtminexp.Size = new System.Drawing.Size(147, 27);
            this.txtminexp.TabIndex = 15;
            // 
            // txtsalary
            // 
            this.txtsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalary.Location = new System.Drawing.Point(318, 319);
            this.txtsalary.Name = "txtsalary";
            this.txtsalary.Size = new System.Drawing.Size(147, 27);
            this.txtsalary.TabIndex = 14;
            // 
            // txtlocation
            // 
            this.txtlocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlocation.Location = new System.Drawing.Point(318, 263);
            this.txtlocation.Name = "txtlocation";
            this.txtlocation.Size = new System.Drawing.Size(147, 27);
            this.txtlocation.TabIndex = 13;
            // 
            // txtdescription
            // 
            this.txtdescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescription.Location = new System.Drawing.Point(318, 207);
            this.txtdescription.Name = "txtdescription";
            this.txtdescription.Size = new System.Drawing.Size(147, 27);
            this.txtdescription.TabIndex = 12;
            // 
            // txtcode
            // 
            this.txtcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcode.Location = new System.Drawing.Point(318, 151);
            this.txtcode.Name = "txtcode";
            this.txtcode.Size = new System.Drawing.Size(147, 27);
            this.txtcode.TabIndex = 11;
            // 
            // txttitle
            // 
            this.txttitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttitle.Location = new System.Drawing.Point(318, 95);
            this.txttitle.Name = "txttitle";
            this.txttitle.Size = new System.Drawing.Size(147, 27);
            this.txttitle.TabIndex = 10;
            // 
            // lblstatuss
            // 
            this.lblstatuss.AutoSize = true;
            this.lblstatuss.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstatuss.Location = new System.Drawing.Point(177, 480);
            this.lblstatuss.Name = "lblstatuss";
            this.lblstatuss.Size = new System.Drawing.Size(75, 20);
            this.lblstatuss.TabIndex = 9;
            this.lblstatuss.Text = "Status :";
            // 
            // rdbinactive
            // 
            this.rdbinactive.AutoSize = true;
            this.rdbinactive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbinactive.Location = new System.Drawing.Point(268, 528);
            this.rdbinactive.Name = "rdbinactive";
            this.rdbinactive.Size = new System.Drawing.Size(95, 24);
            this.rdbinactive.TabIndex = 8;
            this.rdbinactive.TabStop = true;
            this.rdbinactive.Text = "Inactive";
            this.rdbinactive.UseVisualStyleBackColor = true;
            // 
            // rdbactive
            // 
            this.rdbactive.AutoSize = true;
            this.rdbactive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbactive.Location = new System.Drawing.Point(137, 528);
            this.rdbactive.Name = "rdbactive";
            this.rdbactive.Size = new System.Drawing.Size(82, 24);
            this.rdbactive.TabIndex = 7;
            this.rdbactive.TabStop = true;
            this.rdbactive.Text = "Active";
            this.rdbactive.UseVisualStyleBackColor = true;
            // 
            // lblage
            // 
            this.lblage.AutoSize = true;
            this.lblage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblage.Location = new System.Drawing.Point(151, 425);
            this.lblage.Name = "lblage";
            this.lblage.Size = new System.Drawing.Size(101, 20);
            this.lblage.TabIndex = 6;
            this.lblage.Text = "Age Limit :";
            // 
            // lblminexp
            // 
            this.lblminexp.AutoSize = true;
            this.lblminexp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminexp.Location = new System.Drawing.Point(57, 370);
            this.lblminexp.Name = "lblminexp";
            this.lblminexp.Size = new System.Drawing.Size(195, 20);
            this.lblminexp.TabIndex = 5;
            this.lblminexp.Text = "Minimum Experience :";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.Location = new System.Drawing.Point(178, 315);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(74, 20);
            this.lblsalary.TabIndex = 4;
            this.lblsalary.Text = "Salary :";
            // 
            // lbllocation
            // 
            this.lbllocation.AutoSize = true;
            this.lbllocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllocation.Location = new System.Drawing.Point(123, 260);
            this.lbllocation.Name = "lbllocation";
            this.lbllocation.Size = new System.Drawing.Size(129, 20);
            this.lbllocation.TabIndex = 3;
            this.lbllocation.Text = "Job Location :";
            // 
            // lbldescription
            // 
            this.lbldescription.AutoSize = true;
            this.lbldescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescription.Location = new System.Drawing.Point(98, 205);
            this.lbldescription.Name = "lbldescription";
            this.lbldescription.Size = new System.Drawing.Size(154, 20);
            this.lbldescription.TabIndex = 2;
            this.lbldescription.Text = "Job Description :";
            // 
            // lblcode
            // 
            this.lblcode.AutoSize = true;
            this.lblcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcode.Location = new System.Drawing.Point(152, 150);
            this.lblcode.Name = "lblcode";
            this.lblcode.Size = new System.Drawing.Size(100, 20);
            this.lblcode.TabIndex = 1;
            this.lblcode.Text = "Job Code :";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.Location = new System.Drawing.Point(158, 95);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(94, 20);
            this.lbltitle.TabIndex = 0;
            this.lbltitle.Text = "Job Title :";
            // 
            // pnlmain
            // 
            this.pnlmain.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlmain.Controls.Add(this.pnladdjob);
            this.pnlmain.Controls.Add(this.pnljoblist);
            this.pnlmain.Location = new System.Drawing.Point(0, 0);
            this.pnlmain.Name = "pnlmain";
            this.pnlmain.Size = new System.Drawing.Size(1468, 768);
            this.pnlmain.TabIndex = 3;
            // 
            // FrmAddpost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1430, 818);
            this.ControlBox = false;
            this.Controls.Add(this.pnlmain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmAddpost";
            this.Text = "FrmAddpost";
            this.Load += new System.EventHandler(this.FrmAddpost_Load);
            this.pnljoblist.ResumeLayout(false);
            this.pnljoblist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvjoblist)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnladdjob.ResumeLayout(false);
            this.pnladdjob.PerformLayout();
            this.pnlmain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnljoblist;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.TextBox txtJobLocation;
        private System.Windows.Forms.TextBox txtJobTitle;
        private System.Windows.Forms.TextBox txtJobCode;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblJobLocation;
        private System.Windows.Forms.Label lblJobTitle;
        private System.Windows.Forms.Label lblJobCode;
        private System.Windows.Forms.Panel pnladdjob;
        private System.Windows.Forms.TextBox txtagelimit;
        private System.Windows.Forms.TextBox txtminexp;
        private System.Windows.Forms.TextBox txtsalary;
        private System.Windows.Forms.TextBox txtlocation;
        private System.Windows.Forms.TextBox txtdescription;
        private System.Windows.Forms.TextBox txtcode;
        private System.Windows.Forms.TextBox txttitle;
        private System.Windows.Forms.Label lblstatuss;
        private System.Windows.Forms.RadioButton rdbinactive;
        private System.Windows.Forms.RadioButton rdbactive;
        private System.Windows.Forms.Label lblage;
        private System.Windows.Forms.Label lblminexp;
        private System.Windows.Forms.Label lblsalary;
        private System.Windows.Forms.Label lbllocation;
        private System.Windows.Forms.Label lbldescription;
        private System.Windows.Forms.Label lblcode;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Label lblhead;
        private System.Windows.Forms.Button btnaddpost;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.DataGridView dgvjoblist;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobmid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colslno;
        private System.Windows.Forms.DataGridViewButtonColumn edit;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobtitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobdescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn joblocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobsalary;
        private System.Windows.Forms.DataGridViewTextBoxColumn minexperience;
        private System.Windows.Forms.DataGridViewTextBoxColumn age;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobstatus;
        private System.Windows.Forms.DataGridViewButtonColumn delete;
        private System.Windows.Forms.Label lblheading;
        private System.Windows.Forms.Panel pnlmain;
        private System.Windows.Forms.Button btnexportexcel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmAddpost : Form
    {
        DataManager DM = new DataManager();
        ClsJob objJob = new ClsJob();
        int EditMid = 0;
        public FrmAddpost()
        {
            InitializeComponent();
        }

        private void FrmAddpost_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            this.AutoScroll = true;

            pnljoblist.Visible = true;
            pnladdjob.Visible = false;

            cmbStatus.Items.Clear();
            cmbStatus.Items.Add("--ALL--");
            cmbStatus.Items.Add("Active");
            cmbStatus.Items.Add("Inactive");
            cmbStatus.SelectedIndex = 0;

            BindGrid(false);
            CenterPanel();
            CenterInnerPanel();
        }

        private void CenterPanel()
        {
            pnlmain.Left = (this.ClientSize.Width - pnlmain.Width) / 2;
            pnlmain.Top = 20;
        }

        private void CenterInnerPanel()
        {
            pnladdjob.Left = (pnlmain.Width - pnladdjob.Width) / 2;
            pnladdjob.Top = 20;
        }

        private void BindGrid(bool applyDateFilter = false)
        {
            string query = "select job_Mid, job_title, job_code, job_description, job_location, job_salary, job_min_experience, job_age_limit, job_status from tbl_jobs where job_Activeflag = 1";

            if (txtJobCode.Text.Trim() != "")
                query += " and job_code like '%" + txtJobCode.Text.Trim() + "%'";

            if (txtJobTitle.Text.Trim() != "")
                query += " and job_title like '%" + txtJobTitle.Text.Trim() + "%'";

            if (txtJobLocation.Text.Trim() != "")
                query += " and job_location like '%" + txtJobLocation.Text.Trim() + "%'";

            if (cmbStatus.SelectedIndex > 0)
                query += " and job_status='" + cmbStatus.Text + "'";

            // DATE FILTER
            if (applyDateFilter)
            {
                if (dtpFromDate.Value.Date > dtpToDate.Value.Date)
                {
                    MessageBox.Show("From Date cannot be greater than To Date");
                    return;
                }

                query += " and job_CreatedOn >= '" +
                         dtpFromDate.Value.ToString("yyyy-MM-dd") + "'";

                query += " and job_CreatedOn < '" +
                         dtpToDate.Value.AddDays(1).ToString("yyyy-MM-dd") + "'";
            }

            query += ";select count(job_Mid) TotalRecords from tbl_jobs where job_Activeflag = 1";

            DataSet ds = DM.GetDataSet(query);

            dgvjoblist.AutoGenerateColumns = false;
            dgvjoblist.DataSource = ds.Tables[0];

            for (int i = 0; i < dgvjoblist.Rows.Count; i++)
            {
                dgvjoblist.Rows[i].Cells["colslno"].Value = i + 1;
            }
        }
        //private void BindGrid()
        //{
        //    string query = "select job_Mid, job_title, job_code, job_description, job_location, job_salary, job_min_experience, job_age_limit, job_status from tbl_jobs where job_Activeflag = 1";

        //    if (txtJobCode.Text.Trim() != "")
        //        query += " and job_code like '%" + txtJobCode.Text.Trim() + "%'";

        //    if (txtJobTitle.Text.Trim() != "")
        //        query += " and job_title like '%" + txtJobTitle.Text.Trim() + "%'";

        //    if (txtJobLocation.Text.Trim() != "")
        //        query += " and job_location like '%" + txtJobLocation.Text.Trim() + "%'";

        //    if (cmbStatus.SelectedIndex > 0)
        //        query += " and job_status='" + cmbStatus.Text + "'";

        //    query += ";select count(job_Mid) TotalRecords from tbl_jobs where job_Activeflag =1";

        //    MessageBox.Show(query);
        //    DataSet ds = DM.GetDataSet(query);

        //    dgvjoblist.AutoGenerateColumns = false;
        //    dgvjoblist.DataSource = ds.Tables[0];

        //    for (int i = 0; i < dgvjoblist.Rows.Count; i++)
        //    {
        //        dgvjoblist.Rows[i].Cells["colslno"].Value = i + 1;
        //    }
        //}

        private void btnaddpost_Click(object sender, EventArgs e)
        {
            ClearControls();

            pnljoblist.Visible = false;
            pnladdjob.Visible = true;

            btnSave.Visible = true;
            btnUpdate.Visible = false;

            rdbactive.Checked = true;
        }
        private void ClearControls()
        {
            txttitle.Clear();
            txtcode.Clear();
            txtdescription.Clear();
            txtsalary.Clear();
            txtminexp.Clear();
            txtagelimit.Clear();
            txtlocation.Clear();
            rdbactive.Checked = true;
            rdbinactive.Checked = false;

            EditMid = 0;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            pnljoblist.Visible = true;
            pnladdjob.Visible = false;

            ClearControls();
            BindGrid();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearControls();
        }

        private bool ValidateForm()
        {
            if (txttitle.Text.Trim() == "")
            {
                MessageBox.Show("Enter Job Title");
                txttitle.Focus();
                return false;
            }

            if (txtcode.Text.Trim() == "")
            {
                MessageBox.Show("Enter Job Code");
                txtcode.Focus();
                return false;
            }

            if (txtdescription.Text.Trim() == "")
            {
                MessageBox.Show("Enter Job Description");
                txtdescription.Focus();
                return false;
            }

            if (txtlocation.Text.Trim() == "")
            {
                MessageBox.Show("Enter Job Location");
                txtlocation.Focus();
                return false;
            }

            if (txtsalary.Text.Trim() == "")
            {
                MessageBox.Show("Enter Salary");
                txtsalary.Focus();
                return false;
            }

            decimal salaryVal;
            if (!decimal.TryParse(txtsalary.Text.Trim(), out salaryVal) || salaryVal <= 0)
            {
                MessageBox.Show("Enter a valid Salary");
                txtsalary.Focus();
                return false;
            }

            if (txtagelimit.Text.Trim() == "")
            {
                MessageBox.Show("Enter Age Limit");
                txtagelimit.Focus();
                return false;
            }

            int ageVal;
            if (!int.TryParse(txtagelimit.Text.Trim(), out ageVal) || ageVal <= 0)
            {
                MessageBox.Show("Enter a valid Age Limit");
                txtagelimit.Focus();
                return false;
            }

            if (txtminexp.Text.Trim() == "")
            {
                MessageBox.Show("Enter Minimum Experience");
                txtminexp.Focus();
                return false;
            }

            decimal expVal;
            if (!decimal.TryParse(txtminexp.Text.Trim(), out expVal) || expVal < 0)
            {
                MessageBox.Show("Enter a valid Minimum Experience");
                txtminexp.Focus();
                return false;
            }

            return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateForm())
                return;

            string checkQuery = "SELECT job_Mid FROM tbl_jobs WHERE job_code='" + txtcode.Text.Trim() + "' AND job_Activeflag=1";

            if (DM.CheckIsRecordExist(checkQuery))
            {
                MessageBox.Show("Job Code already exists.");
                txtcode.Focus();
                return;
            }
            string status = "";

            if (rdbactive.Checked)
                status = "Active";
            else
                status = "Inactive";
            int result = objJob.JobTransaction(
     2,                      // Insert
     0,
     txttitle.Text.Trim(),
     txtcode.Text.Trim(),
     txtdescription.Text.Trim(),
     txtlocation.Text.Trim(),
     txtsalary.Text.Trim(),
     txtminexp.Text.Trim(),
     txtagelimit.Text.Trim(),
     status,
     "",
     "",
     "",
     "",
     "",
     0
 );
            if (result > 0)
            {
                MessageBox.Show("Job added successfully.");

                ClearControls();

                pnljoblist.Visible = true;
                pnladdjob.Visible = false;

                BindGrid();
            }
            else
            {
                MessageBox.Show("Save Failed");
            }
        }
        private void dgvjoblist_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            if (dgvjoblist.Columns[e.ColumnIndex].Name == "edit")
            {
                EditMid = Convert.ToInt32(dgvjoblist.Rows[e.RowIndex].Cells["jobmid"].Value);
                string query = "select * from tbl_jobs where job_Mid = " + EditMid;

                DataSet ds = DM.GetDataSet(query);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];

                    txttitle.Text = dr["job_title"].ToString();
                    txtcode.Text = dr["job_code"].ToString();
                    txtdescription.Text = dr["job_description"].ToString();
                    txtlocation.Text = dr["job_location"].ToString();
                    txtsalary.Text = dr["job_salary"].ToString();
                    txtminexp.Text = dr["job_min_experience"].ToString();
                    txtagelimit.Text = dr["job_age_limit"].ToString();

                    if (dr["job_status"].ToString() == "Active")
                        rdbactive.Checked = true;
                    else
                        rdbinactive.Checked = true;

                    pnljoblist.Visible = false;
                    pnladdjob.Visible = true;

                    btnSave.Visible = false;
                    btnUpdate.Visible = true;
                }
            }
            if (dgvjoblist.Columns[e.ColumnIndex].Name == "delete")
            {
                int JobMid = Convert.ToInt32(dgvjoblist.Rows[e.RowIndex].Cells["jobmid"].Value);

                DialogResult dr = MessageBox.Show(
                    "Are you sure you want to delete this Job?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    int result = objJob.JobTransaction(
    4,          // Delete
    JobMid,
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    0
);
                    if (result > 0)
                    {
                        MessageBox.Show("Job deleted successfully.");
                        BindGrid();
                    }
                    else
                    {
                        MessageBox.Show("Delete Failed");
                    }
                }
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            //  MessageBox.Show("Job Title = [" + txtJobTitle.Text + "]");
            BindGrid(true);
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            txtJobCode.Clear();
            txtJobTitle.Clear();
            txtJobLocation.Clear();
            cmbStatus.SelectedIndex = 0;
            dtpFromDate.Value = DateTime.Today;
            dtpToDate.Value = DateTime.Today;
            BindGrid(false);
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!ValidateForm())
                return;

            string checkQuery = "SELECT job_Mid FROM tbl_jobs WHERE job_code='" + txtcode.Text.Trim() + "' AND job_Activeflag=1 AND job_Mid <> " + EditMid;

            if (DM.CheckIsRecordExist(checkQuery))
            {
                MessageBox.Show("Job Code already exists.");
                txtcode.Focus();
                return;
            }
            string status = rdbactive.Checked ? "Active" : "Inactive";

            int result = objJob.JobTransaction(
                3,
                EditMid,
                txttitle.Text.Trim(),
                txtcode.Text.Trim(),
                txtdescription.Text.Trim(),
                txtlocation.Text.Trim(),
                txtsalary.Text.Trim(),
                txtminexp.Text.Trim(),
                txtagelimit.Text.Trim(),
                status,
                "",
                "",
                "",
                "",
                "",
                0
            );

            if (result > 0)
            {
                MessageBox.Show("Job updated successfully.");

                ClearControls();
                EditMid = 0;

                pnljoblist.Visible = true;
                pnladdjob.Visible = false;

                BindGrid();
            }
            else
            {
                MessageBox.Show("Update Failed");
            }
        }

        private void dgvjoblist_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            dgvjoblist.Rows[e.RowIndex].Cells["colslno"].Value = (e.RowIndex + 1).ToString();
        }

        private void btnexportexcel_Click(object sender, EventArgs e)
        {

        }
    }
}

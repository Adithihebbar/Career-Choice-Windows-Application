﻿namespace RecruitmentPortal
{
    partial class FrmApply
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlapplication = new System.Windows.Forms.Panel();
            this.lblnojobs = new System.Windows.Forms.Label();
            this.btnback = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvjoblist = new System.Windows.Forms.DataGridView();
            this.colsln = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coljobtitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coljobcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coldescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.collocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colsalary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colminexp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colapply = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colapplymid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlapply = new System.Windows.Forms.Panel();
            this.btnback1 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.lblexperiencetotal = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblmandatory = new System.Windows.Forms.Label();
            this.lblheader = new System.Windows.Forms.Label();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.lblresume = new System.Windows.Forms.Label();
            this.btnresume = new System.Windows.Forms.Button();
            this.btnphoto = new System.Windows.Forms.Button();
            this.lblphoto = new System.Windows.Forms.Label();
            this.btnuploadreceipt = new System.Windows.Forms.Button();
            this.picbreceipt = new System.Windows.Forms.PictureBox();
            this.lblpayment = new System.Windows.Forms.Label();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.gbexperience = new System.Windows.Forms.GroupBox();
            this.rdbfresher = new System.Windows.Forms.RadioButton();
            this.rdbexperienced = new System.Windows.Forms.RadioButton();
            this.gbgender = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.rdbfemale = new System.Windows.Forms.RadioButton();
            this.rdbother = new System.Windows.Forms.RadioButton();
            this.rdbmale = new System.Windows.Forms.RadioButton();
            this.gbmarital = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rdbmarried = new System.Windows.Forms.RadioButton();
            this.rdbsingle = new System.Windows.Forms.RadioButton();
            this.txtqualification = new System.Windows.Forms.TextBox();
            this.txtnationality = new System.Windows.Forms.TextBox();
            this.txtdob = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtnumber = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtjobpost = new System.Windows.Forms.TextBox();
            this.lblqualification = new System.Windows.Forms.Label();
            this.lblnationality = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblmobilenumber = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lbljobpost = new System.Windows.Forms.Label();
            this.pnlmain = new System.Windows.Forms.Panel();
            this.pnlapplication.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvjoblist)).BeginInit();
            this.pnlapply.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbreceipt)).BeginInit();
            this.gbexperience.SuspendLayout();
            this.gbgender.SuspendLayout();
            this.gbmarital.SuspendLayout();
            this.pnlmain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlapplication
            // 
            this.pnlapplication.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlapplication.Controls.Add(this.lblnojobs);
            this.pnlapplication.Controls.Add(this.btnback);
            this.pnlapplication.Controls.Add(this.label1);
            this.pnlapplication.Controls.Add(this.dgvjoblist);
            this.pnlapplication.Location = new System.Drawing.Point(0, 0);
            this.pnlapplication.Name = "pnlapplication";
            this.pnlapplication.Size = new System.Drawing.Size(1037, 727);
            this.pnlapplication.TabIndex = 1;
            // 
            // lblnojobs
            // 
            this.lblnojobs.AutoSize = true;
            this.lblnojobs.BackColor = System.Drawing.Color.Transparent;
            this.lblnojobs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnojobs.Location = new System.Drawing.Point(320, 247);
            this.lblnojobs.Name = "lblnojobs";
            this.lblnojobs.Size = new System.Drawing.Size(362, 50);
            this.lblnojobs.TabIndex = 3;
            this.lblnojobs.Text = "No jobs are available at the moment.\r\nPlease check back later.";
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(845, 61);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(100, 40);
            this.btnback.TabIndex = 2;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(385, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Available Jobs";
            // 
            // dgvjoblist
            // 
            this.dgvjoblist.AllowUserToAddRows = false;
            this.dgvjoblist.AllowUserToDeleteRows = false;
            this.dgvjoblist.AllowUserToResizeRows = false;
            this.dgvjoblist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvjoblist.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvjoblist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvjoblist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvjoblist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colsln,
            this.coljobtitle,
            this.coljobcode,
            this.coldescription,
            this.collocation,
            this.colsalary,
            this.colminexp,
            this.colage,
            this.colapply,
            this.colapplymid});
            this.dgvjoblist.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgvjoblist.Location = new System.Drawing.Point(60, 146);
            this.dgvjoblist.Name = "dgvjoblist";
            this.dgvjoblist.ReadOnly = true;
            this.dgvjoblist.RowHeadersVisible = false;
            this.dgvjoblist.RowTemplate.Height = 24;
            this.dgvjoblist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvjoblist.ShowEditingIcon = false;
            this.dgvjoblist.Size = new System.Drawing.Size(840, 320);
            this.dgvjoblist.TabIndex = 0;
            this.dgvjoblist.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvjoblist_CellContentClick);
            this.dgvjoblist.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvjoblist_RowPostPaint);
            // 
            // colsln
            // 
            this.colsln.HeaderText = "Sl no.";
            this.colsln.Name = "colsln";
            this.colsln.ReadOnly = true;
            // 
            // coljobtitle
            // 
            this.coljobtitle.DataPropertyName = "job_title";
            this.coljobtitle.HeaderText = "Job Title";
            this.coljobtitle.Name = "coljobtitle";
            this.coljobtitle.ReadOnly = true;
            // 
            // coljobcode
            // 
            this.coljobcode.DataPropertyName = "job_code";
            this.coljobcode.HeaderText = "Job Code";
            this.coljobcode.Name = "coljobcode";
            this.coljobcode.ReadOnly = true;
            // 
            // coldescription
            // 
            this.coldescription.DataPropertyName = "job_description";
            this.coldescription.HeaderText = "Description";
            this.coldescription.Name = "coldescription";
            this.coldescription.ReadOnly = true;
            // 
            // collocation
            // 
            this.collocation.DataPropertyName = "job_location";
            this.collocation.HeaderText = "Job Location";
            this.collocation.Name = "collocation";
            this.collocation.ReadOnly = true;
            // 
            // colsalary
            // 
            this.colsalary.DataPropertyName = "job_salary";
            this.colsalary.HeaderText = "Job Salary";
            this.colsalary.Name = "colsalary";
            this.colsalary.ReadOnly = true;
            // 
            // colminexp
            // 
            this.colminexp.DataPropertyName = "job_min_experience";
            this.colminexp.HeaderText = "Minimum Experience";
            this.colminexp.Name = "colminexp";
            this.colminexp.ReadOnly = true;
            // 
            // colage
            // 
            this.colage.DataPropertyName = "job_age_limit";
            this.colage.HeaderText = "Age Limit";
            this.colage.Name = "colage";
            this.colage.ReadOnly = true;
            // 
            // colapply
            // 
            this.colapply.HeaderText = "Apply";
            this.colapply.Name = "colapply";
            this.colapply.ReadOnly = true;
            this.colapply.Text = "Apply";
            this.colapply.UseColumnTextForButtonValue = true;
            // 
            // colapplymid
            // 
            this.colapplymid.DataPropertyName = "job_mid";
            this.colapplymid.HeaderText = "Applymid";
            this.colapplymid.Name = "colapplymid";
            this.colapplymid.ReadOnly = true;
            this.colapplymid.Visible = false;
            // 
            // pnlapply
            // 
            this.pnlapply.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlapply.Controls.Add(this.btnback1);
            this.pnlapply.Controls.Add(this.label29);
            this.pnlapply.Controls.Add(this.lblexperiencetotal);
            this.pnlapply.Controls.Add(this.label15);
            this.pnlapply.Controls.Add(this.label14);
            this.pnlapply.Controls.Add(this.label13);
            this.pnlapply.Controls.Add(this.label11);
            this.pnlapply.Controls.Add(this.label8);
            this.pnlapply.Controls.Add(this.label7);
            this.pnlapply.Controls.Add(this.label6);
            this.pnlapply.Controls.Add(this.label5);
            this.pnlapply.Controls.Add(this.label4);
            this.pnlapply.Controls.Add(this.label3);
            this.pnlapply.Controls.Add(this.label2);
            this.pnlapply.Controls.Add(this.lblmandatory);
            this.pnlapply.Controls.Add(this.lblheader);
            this.pnlapply.Controls.Add(this.btnclear);
            this.pnlapply.Controls.Add(this.btnsubmit);
            this.pnlapply.Controls.Add(this.lblresume);
            this.pnlapply.Controls.Add(this.btnresume);
            this.pnlapply.Controls.Add(this.btnphoto);
            this.pnlapply.Controls.Add(this.lblphoto);
            this.pnlapply.Controls.Add(this.btnuploadreceipt);
            this.pnlapply.Controls.Add(this.picbreceipt);
            this.pnlapply.Controls.Add(this.lblpayment);
            this.pnlapply.Controls.Add(this.txttotal);
            this.pnlapply.Controls.Add(this.gbexperience);
            this.pnlapply.Controls.Add(this.gbgender);
            this.pnlapply.Controls.Add(this.gbmarital);
            this.pnlapply.Controls.Add(this.txtqualification);
            this.pnlapply.Controls.Add(this.txtnationality);
            this.pnlapply.Controls.Add(this.txtdob);
            this.pnlapply.Controls.Add(this.txtemail);
            this.pnlapply.Controls.Add(this.txtnumber);
            this.pnlapply.Controls.Add(this.txtname);
            this.pnlapply.Controls.Add(this.txtjobpost);
            this.pnlapply.Controls.Add(this.lblqualification);
            this.pnlapply.Controls.Add(this.lblnationality);
            this.pnlapply.Controls.Add(this.lbldob);
            this.pnlapply.Controls.Add(this.lblemail);
            this.pnlapply.Controls.Add(this.lblmobilenumber);
            this.pnlapply.Controls.Add(this.lblname);
            this.pnlapply.Controls.Add(this.lbljobpost);
            this.pnlapply.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pnlapply.Location = new System.Drawing.Point(12, 3);
            this.pnlapply.Name = "pnlapply";
            this.pnlapply.Size = new System.Drawing.Size(1010, 712);
            this.pnlapply.TabIndex = 2;
            // 
            // btnback1
            // 
            this.btnback1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnback1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback1.Location = new System.Drawing.Point(894, 33);
            this.btnback1.Name = "btnback1";
            this.btnback1.Size = new System.Drawing.Size(100, 40);
            this.btnback1.TabIndex = 46;
            this.btnback1.Text = "Back";
            this.btnback1.UseVisualStyleBackColor = false;
            this.btnback1.Click += new System.EventHandler(this.btnback1_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(9, 511);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(14, 17);
            this.label29.TabIndex = 45;
            this.label29.Text = "*";
            // 
            // lblexperiencetotal
            // 
            this.lblexperiencetotal.AutoSize = true;
            this.lblexperiencetotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexperiencetotal.Location = new System.Drawing.Point(24, 508);
            this.lblexperiencetotal.Name = "lblexperiencetotal";
            this.lblexperiencetotal.Size = new System.Drawing.Size(162, 20);
            this.lblexperiencetotal.TabIndex = 44;
            this.lblexperiencetotal.Text = "Total Experience :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(565, 300);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 17);
            this.label15.TabIndex = 43;
            this.label15.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(584, 253);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 17);
            this.label14.TabIndex = 42;
            this.label14.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(554, 347);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(14, 17);
            this.label13.TabIndex = 41;
            this.label13.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(9, 480);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 17);
            this.label11.TabIndex = 40;
            this.label11.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(9, 328);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 17);
            this.label8.TabIndex = 38;
            this.label8.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(56, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 17);
            this.label7.TabIndex = 37;
            this.label7.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(40, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 17);
            this.label6.TabIndex = 36;
            this.label6.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(98, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 17);
            this.label5.TabIndex = 35;
            this.label5.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(25, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 17);
            this.label4.TabIndex = 34;
            this.label4.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(97, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(77, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "*";
            // 
            // lblmandatory
            // 
            this.lblmandatory.AutoSize = true;
            this.lblmandatory.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmandatory.Location = new System.Drawing.Point(378, 46);
            this.lblmandatory.Name = "lblmandatory";
            this.lblmandatory.Size = new System.Drawing.Size(180, 17);
            this.lblmandatory.TabIndex = 31;
            this.lblmandatory.Text = "\'*\' Fields are Mandatory";
            // 
            // lblheader
            // 
            this.lblheader.AutoSize = true;
            this.lblheader.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheader.Location = new System.Drawing.Point(382, 9);
            this.lblheader.Name = "lblheader";
            this.lblheader.Size = new System.Drawing.Size(176, 32);
            this.lblheader.TabIndex = 30;
            this.lblheader.Text = "Application ";
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(557, 574);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(100, 40);
            this.btnclear.TabIndex = 29;
            this.btnclear.Text = "Refresh";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(381, 574);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(100, 40);
            this.btnsubmit.TabIndex = 28;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // lblresume
            // 
            this.lblresume.AutoSize = true;
            this.lblresume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresume.Location = new System.Drawing.Point(574, 301);
            this.lblresume.Name = "lblresume";
            this.lblresume.Size = new System.Drawing.Size(153, 20);
            this.lblresume.TabIndex = 27;
            this.lblresume.Text = "Upload Resume :";
            // 
            // btnresume
            // 
            this.btnresume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresume.Location = new System.Drawing.Point(753, 296);
            this.btnresume.Name = "btnresume";
            this.btnresume.Size = new System.Drawing.Size(165, 30);
            this.btnresume.TabIndex = 26;
            this.btnresume.Text = "Upload Resume";
            this.btnresume.UseVisualStyleBackColor = true;
            this.btnresume.Click += new System.EventHandler(this.btnresume_Click);
            // 
            // btnphoto
            // 
            this.btnphoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnphoto.Location = new System.Drawing.Point(753, 253);
            this.btnphoto.Name = "btnphoto";
            this.btnphoto.Size = new System.Drawing.Size(160, 27);
            this.btnphoto.TabIndex = 25;
            this.btnphoto.Text = "Upload Photo";
            this.btnphoto.UseVisualStyleBackColor = true;
            this.btnphoto.Click += new System.EventHandler(this.btnphoto_Click);
            // 
            // lblphoto
            // 
            this.lblphoto.AutoSize = true;
            this.lblphoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphoto.Location = new System.Drawing.Point(594, 256);
            this.lblphoto.Name = "lblphoto";
            this.lblphoto.Size = new System.Drawing.Size(133, 20);
            this.lblphoto.TabIndex = 24;
            this.lblphoto.Text = "Upload Photo :";
            // 
            // btnuploadreceipt
            // 
            this.btnuploadreceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuploadreceipt.Location = new System.Drawing.Point(753, 347);
            this.btnuploadreceipt.Name = "btnuploadreceipt";
            this.btnuploadreceipt.Size = new System.Drawing.Size(165, 30);
            this.btnuploadreceipt.TabIndex = 23;
            this.btnuploadreceipt.Text = "Upload Receipt";
            this.btnuploadreceipt.UseVisualStyleBackColor = true;
            this.btnuploadreceipt.Click += new System.EventHandler(this.btnuploadreceipt_Click);
            // 
            // picbreceipt
            // 
            this.picbreceipt.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picbreceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbreceipt.Location = new System.Drawing.Point(766, 123);
            this.picbreceipt.Name = "picbreceipt";
            this.picbreceipt.Size = new System.Drawing.Size(109, 107);
            this.picbreceipt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbreceipt.TabIndex = 22;
            this.picbreceipt.TabStop = false;
            // 
            // lblpayment
            // 
            this.lblpayment.AutoSize = true;
            this.lblpayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpayment.Location = new System.Drawing.Point(564, 352);
            this.lblpayment.Name = "lblpayment";
            this.lblpayment.Size = new System.Drawing.Size(163, 20);
            this.lblpayment.TabIndex = 21;
            this.lblpayment.Text = "Payment Receipt :";
            // 
            // txttotal
            // 
            this.txttotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotal.Location = new System.Drawing.Point(210, 505);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(160, 27);
            this.txttotal.TabIndex = 20;
            // 
            // gbexperience
            // 
            this.gbexperience.Controls.Add(this.rdbfresher);
            this.gbexperience.Controls.Add(this.rdbexperienced);
            this.gbexperience.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbexperience.Location = new System.Drawing.Point(12, 468);
            this.gbexperience.Name = "gbexperience";
            this.gbexperience.Size = new System.Drawing.Size(516, 29);
            this.gbexperience.TabIndex = 18;
            this.gbexperience.TabStop = false;
            this.gbexperience.Text = "Experience Type :";
            // 
            // rdbfresher
            // 
            this.rdbfresher.AutoSize = true;
            this.rdbfresher.Location = new System.Drawing.Point(198, 0);
            this.rdbfresher.Name = "rdbfresher";
            this.rdbfresher.Size = new System.Drawing.Size(95, 24);
            this.rdbfresher.TabIndex = 16;
            this.rdbfresher.TabStop = true;
            this.rdbfresher.Text = "Fresher";
            this.rdbfresher.UseVisualStyleBackColor = true;
            // 
            // rdbexperienced
            // 
            this.rdbexperienced.AutoSize = true;
            this.rdbexperienced.Location = new System.Drawing.Point(376, 0);
            this.rdbexperienced.Name = "rdbexperienced";
            this.rdbexperienced.Size = new System.Drawing.Size(133, 24);
            this.rdbexperienced.TabIndex = 17;
            this.rdbexperienced.TabStop = true;
            this.rdbexperienced.Text = "Experienced";
            this.rdbexperienced.UseVisualStyleBackColor = true;
            // 
            // gbgender
            // 
            this.gbgender.Controls.Add(this.label10);
            this.gbgender.Controls.Add(this.rdbfemale);
            this.gbgender.Controls.Add(this.rdbother);
            this.gbgender.Controls.Add(this.rdbmale);
            this.gbgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbgender.Location = new System.Drawing.Point(22, 370);
            this.gbgender.Name = "gbgender";
            this.gbgender.Size = new System.Drawing.Size(459, 39);
            this.gbgender.TabIndex = 15;
            this.gbgender.TabStop = false;
            this.gbgender.Text = "Gender :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(-3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 17);
            this.label10.TabIndex = 39;
            this.label10.Text = "*";
            // 
            // rdbfemale
            // 
            this.rdbfemale.AutoSize = true;
            this.rdbfemale.Location = new System.Drawing.Point(221, 0);
            this.rdbfemale.Name = "rdbfemale";
            this.rdbfemale.Size = new System.Drawing.Size(91, 24);
            this.rdbfemale.TabIndex = 2;
            this.rdbfemale.TabStop = true;
            this.rdbfemale.Text = "Female";
            this.rdbfemale.UseVisualStyleBackColor = true;
            // 
            // rdbother
            // 
            this.rdbother.AutoSize = true;
            this.rdbother.Location = new System.Drawing.Point(332, 0);
            this.rdbother.Name = "rdbother";
            this.rdbother.Size = new System.Drawing.Size(77, 24);
            this.rdbother.TabIndex = 1;
            this.rdbother.TabStop = true;
            this.rdbother.Text = "Other";
            this.rdbother.UseVisualStyleBackColor = true;
            // 
            // rdbmale
            // 
            this.rdbmale.AutoSize = true;
            this.rdbmale.Location = new System.Drawing.Point(120, 0);
            this.rdbmale.Name = "rdbmale";
            this.rdbmale.Size = new System.Drawing.Size(70, 24);
            this.rdbmale.TabIndex = 0;
            this.rdbmale.TabStop = true;
            this.rdbmale.Text = "Male";
            this.rdbmale.UseVisualStyleBackColor = true;
            // 
            // gbmarital
            // 
            this.gbmarital.Controls.Add(this.label9);
            this.gbmarital.Controls.Add(this.rdbmarried);
            this.gbmarital.Controls.Add(this.rdbsingle);
            this.gbmarital.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbmarital.Location = new System.Drawing.Point(28, 415);
            this.gbmarital.Name = "gbmarital";
            this.gbmarital.Size = new System.Drawing.Size(445, 33);
            this.gbmarital.TabIndex = 14;
            this.gbmarital.TabStop = false;
            this.gbmarital.Text = "Marital Status :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(-3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 17);
            this.label9.TabIndex = 39;
            this.label9.Text = "*";
            // 
            // rdbmarried
            // 
            this.rdbmarried.AutoSize = true;
            this.rdbmarried.Location = new System.Drawing.Point(320, 0);
            this.rdbmarried.Name = "rdbmarried";
            this.rdbmarried.Size = new System.Drawing.Size(94, 24);
            this.rdbmarried.TabIndex = 1;
            this.rdbmarried.TabStop = true;
            this.rdbmarried.Text = "Married";
            this.rdbmarried.UseVisualStyleBackColor = true;
            // 
            // rdbsingle
            // 
            this.rdbsingle.AutoSize = true;
            this.rdbsingle.Location = new System.Drawing.Point(172, 0);
            this.rdbsingle.Name = "rdbsingle";
            this.rdbsingle.Size = new System.Drawing.Size(82, 24);
            this.rdbsingle.TabIndex = 0;
            this.rdbsingle.TabStop = true;
            this.rdbsingle.Text = "Single";
            this.rdbsingle.UseVisualStyleBackColor = true;
            // 
            // txtqualification
            // 
            this.txtqualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtqualification.Location = new System.Drawing.Point(245, 325);
            this.txtqualification.Name = "txtqualification";
            this.txtqualification.Size = new System.Drawing.Size(160, 27);
            this.txtqualification.TabIndex = 13;
            // 
            // txtnationality
            // 
            this.txtnationality.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnationality.Location = new System.Drawing.Point(210, 286);
            this.txtnationality.Name = "txtnationality";
            this.txtnationality.Size = new System.Drawing.Size(160, 27);
            this.txtnationality.TabIndex = 12;
            // 
            // txtdob
            // 
            this.txtdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdob.Location = new System.Drawing.Point(210, 243);
            this.txtdob.Name = "txtdob";
            this.txtdob.Size = new System.Drawing.Size(160, 27);
            this.txtdob.TabIndex = 11;
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(210, 201);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(160, 27);
            this.txtemail.TabIndex = 10;
            // 
            // txtnumber
            // 
            this.txtnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumber.Location = new System.Drawing.Point(210, 163);
            this.txtnumber.Name = "txtnumber";
            this.txtnumber.Size = new System.Drawing.Size(160, 27);
            this.txtnumber.TabIndex = 9;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(210, 123);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(160, 27);
            this.txtname.TabIndex = 8;
            // 
            // txtjobpost
            // 
            this.txtjobpost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtjobpost.Location = new System.Drawing.Point(210, 80);
            this.txtjobpost.Name = "txtjobpost";
            this.txtjobpost.Size = new System.Drawing.Size(160, 27);
            this.txtjobpost.TabIndex = 7;
            // 
            // lblqualification
            // 
            this.lblqualification.AutoSize = true;
            this.lblqualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqualification.Location = new System.Drawing.Point(24, 328);
            this.lblqualification.Name = "lblqualification";
            this.lblqualification.Size = new System.Drawing.Size(212, 20);
            this.lblqualification.TabIndex = 6;
            this.lblqualification.Text = "Maximum Qualification :";
            // 
            // lblnationality
            // 
            this.lblnationality.AutoSize = true;
            this.lblnationality.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnationality.Location = new System.Drawing.Point(76, 289);
            this.lblnationality.Name = "lblnationality";
            this.lblnationality.Size = new System.Drawing.Size(110, 20);
            this.lblnationality.TabIndex = 5;
            this.lblnationality.Text = "Nationality :";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldob.Location = new System.Drawing.Point(56, 246);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(130, 20);
            this.lbldob.TabIndex = 4;
            this.lbldob.Text = "Date of Birth :";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(118, 204);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(68, 20);
            this.lblemail.TabIndex = 3;
            this.lblemail.Text = "Email :";
            // 
            // lblmobilenumber
            // 
            this.lblmobilenumber.AutoSize = true;
            this.lblmobilenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmobilenumber.Location = new System.Drawing.Point(39, 166);
            this.lblmobilenumber.Name = "lblmobilenumber";
            this.lblmobilenumber.Size = new System.Drawing.Size(147, 20);
            this.lblmobilenumber.TabIndex = 2;
            this.lblmobilenumber.Text = "Mobile Number :";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(117, 126);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(69, 20);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "Name :";
            // 
            // lbljobpost
            // 
            this.lbljobpost.AutoSize = true;
            this.lbljobpost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbljobpost.Location = new System.Drawing.Point(91, 83);
            this.lbljobpost.Name = "lbljobpost";
            this.lbljobpost.Size = new System.Drawing.Size(95, 20);
            this.lbljobpost.TabIndex = 0;
            this.lbljobpost.Text = "Job Post :";
            // 
            // pnlmain
            // 
            this.pnlmain.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlmain.Controls.Add(this.pnlapply);
            this.pnlmain.Controls.Add(this.pnlapplication);
            this.pnlmain.Location = new System.Drawing.Point(0, 0);
            this.pnlmain.Name = "pnlmain";
            this.pnlmain.Size = new System.Drawing.Size(1100, 800);
            this.pnlmain.TabIndex = 4;
            // 
            // FrmApply
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1500, 800);
            this.ControlBox = false;
            this.Controls.Add(this.pnlmain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmApply";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmApply";
            this.Load += new System.EventHandler(this.FrmApply_Load);
            this.pnlapplication.ResumeLayout(false);
            this.pnlapplication.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvjoblist)).EndInit();
            this.pnlapply.ResumeLayout(false);
            this.pnlapply.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbreceipt)).EndInit();
            this.gbexperience.ResumeLayout(false);
            this.gbexperience.PerformLayout();
            this.gbgender.ResumeLayout(false);
            this.gbgender.PerformLayout();
            this.gbmarital.ResumeLayout(false);
            this.gbmarital.PerformLayout();
            this.pnlmain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlapplication;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvjoblist;
        private System.Windows.Forms.DataGridViewTextBoxColumn colsln;
        private System.Windows.Forms.DataGridViewTextBoxColumn coljobtitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn coljobcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn coldescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn collocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn colsalary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colminexp;
        private System.Windows.Forms.DataGridViewTextBoxColumn colage;
        private System.Windows.Forms.DataGridViewButtonColumn colapply;
        private System.Windows.Forms.DataGridViewTextBoxColumn colapplymid;
        private System.Windows.Forms.Panel pnlapply;
        private System.Windows.Forms.Button btnback1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblexperiencetotal;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblmandatory;
        private System.Windows.Forms.Label lblheader;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Label lblresume;
        private System.Windows.Forms.Button btnresume;
        private System.Windows.Forms.Button btnphoto;
        private System.Windows.Forms.Label lblphoto;
        private System.Windows.Forms.Button btnuploadreceipt;
        private System.Windows.Forms.PictureBox picbreceipt;
        private System.Windows.Forms.Label lblpayment;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.GroupBox gbexperience;
        private System.Windows.Forms.RadioButton rdbfresher;
        private System.Windows.Forms.RadioButton rdbexperienced;
        private System.Windows.Forms.GroupBox gbgender;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton rdbfemale;
        private System.Windows.Forms.RadioButton rdbother;
        private System.Windows.Forms.RadioButton rdbmale;
        private System.Windows.Forms.GroupBox gbmarital;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rdbmarried;
        private System.Windows.Forms.RadioButton rdbsingle;
        private System.Windows.Forms.TextBox txtqualification;
        private System.Windows.Forms.TextBox txtnationality;
        private System.Windows.Forms.TextBox txtdob;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtnumber;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtjobpost;
        private System.Windows.Forms.Label lblqualification;
        private System.Windows.Forms.Label lblnationality;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblmobilenumber;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lbljobpost;
        private System.Windows.Forms.Panel pnlmain;
        private System.Windows.Forms.Label lblnojobs;
    }
}
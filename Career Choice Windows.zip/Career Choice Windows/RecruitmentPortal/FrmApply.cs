﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace RecruitmentPortal
{
    public partial class FrmApply : Form
    {
        DataManager DM = new DataManager();
        ClsApplication ObjApplication = new ClsApplication();
        ClsJob ObjJob = new ClsJob();

        string SelectedJobCode = "";
      //  int SelectedJobMid = 0;

        string PhotoPath = "";
        string ResumePath = "";
        string ReceiptPath = "";

        public FrmApply()
        {
            InitializeComponent();
        }
        private void CenterPanel()
        {
            pnlmain.Left = (this.ClientSize.Width - pnlmain.Width) / 2;
            pnlmain.Top = 40;
        }
        private void FrmApply_Load(object sender, EventArgs e)
        {
            BindJobList();

            txtjobpost.ReadOnly = true;
            txtdob.ReadOnly = true;

            pnlapplication.Visible = true;
            pnlapply.Visible = false;

            CenterPanel();
            dgvjoblist.EnableHeadersVisualStyles = false;

        }

        private void ShowPanel(Panel pnl)
        {
            pnlapplication.Visible = false;
            pnlapply.Visible = false;

            pnl.Visible = true;
        }

        private void BindJobList()
        {
            try
            {
                string query = "select job_Mid, job_title, job_code, job_description, job_salary, job_location, job_min_experience, job_age_limit from tbl_jobs where job_Activeflag = 1 order by job_Mid desc";
                DataSet ds = DM.GetDataSet(query);

                dgvjoblist.AutoGenerateColumns = false;
                dgvjoblist.DataSource = ds.Tables[0];

                if (ds.Tables[0].Rows.Count == 0)
                {
                    dgvjoblist.Visible = false;
                    lblnojobs.Visible = true;
                }
                else
                {
                    dgvjoblist.Visible = true;
                    lblnojobs.Visible = false;

                    for (int i = 0; i < dgvjoblist.Rows.Count; i++)
                    {
                        dgvjoblist.Rows[i].Cells["colsln"].Value = i + 1;
                    }

                    dgvjoblist.ClearSelection();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
      
        private void btnsubmit_Click(object sender, EventArgs e)
        {
            if (txtname.Text.Trim() == "")
            {
                MessageBox.Show("Enter Candidate Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtname.Focus();
                return;
            }
            if (txtnumber.Text.Trim() == "")
            {
                MessageBox.Show("Enter Mobile Number", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtnumber.Focus();
                return;
            }
            if (txtemail.Text.Trim() == "")
            {
                MessageBox.Show("Enter Email Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtemail.Focus();
                return;
            }
            if (txtnationality.Text.Trim() == "")
            {
                MessageBox.Show("Enter Nationality", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtnationality.Focus();
                return;
            }
            if (txtqualification.Text.Trim() == "")
            {
                MessageBox.Show("Enter Qualification", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtqualification.Focus();
                return;
            }
            if (!rdbmale.Checked && !rdbfemale.Checked && !rdbother.Checked)
            {
                MessageBox.Show("Select Gender", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!rdbsingle.Checked && !rdbmarried.Checked)
            {
                MessageBox.Show("Select Marital Status", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!rdbfresher.Checked && !rdbexperienced.Checked)
            {
                MessageBox.Show("Select Experience Type", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (rdbexperienced.Checked && txttotal.Text.Trim() == "")
            {
                MessageBox.Show("Enter Total Experience",
                    "Warning",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txttotal.Focus();
                return;
            }
            if (PhotoPath == "")
            {
                MessageBox.Show("Upload Photo", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (ResumePath == "")
            {
                MessageBox.Show("Upload Resume", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (ReceiptPath == "")
            {
                MessageBox.Show("Upload Receipt", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string Gender = "";
            if (rdbmale.Checked)
                Gender = "Male";
            else if (rdbfemale.Checked)
                Gender = "Female";
            else
                Gender = "Other";

            string MaritalStatus = "";
            if (rdbsingle.Checked)
                MaritalStatus = "Single";
            else
                MaritalStatus = "Married";

            string ExperienceType = "";
            if (rdbfresher.Checked)
                ExperienceType = "Fresher";
            else
                ExperienceType = "Experienced";

            string Query = "select * from tbl_application where apply_regMid = " + Program.LoginMid +
               " and apply_jobcode = '" + SelectedJobCode + "'" +
               " and apply_Activeflag = 1";

          //  MessageBox.Show("SelectedJobCode = " + SelectedJobCode);
           // MessageBox.Show(Query);

            DataSet ds = DM.GetDataSet(Query);

       //     MessageBox.Show("Rows found = " + ds.Tables[0].Rows.Count);
            if (ds.Tables[0].Rows.Count > 0)
            {
                MessageBox.Show("You have already applied for this job", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int Result = ObjApplication.ApplicationTransaction(
                2,                              // Opt
                0,                              // apply_Mid
                Program.LoginMid,               // apply_regMid
                SelectedJobCode,                // apply_jobcode
                txtjobpost.Text.Trim(),         // apply_jobpost
                "",                             // apply_reference_no
                txtname.Text.Trim(),            // apply_name
                txtnumber.Text.Trim(),          // apply_mobile_no
                txtemail.Text.Trim(),           // apply_email
              Convert.ToDateTime(txtdob.Text).ToString("yyyy-MM-dd"),
                txtnationality.Text.Trim(),     // apply_nationality
                MaritalStatus,                  // apply_marital_status
                Gender,                         // apply_gender
                txtqualification.Text.Trim(),   // apply_min_qualification
                ExperienceType,                 // apply_experience_type
                txttotal.Text.Trim(),           // apply_total_experience
                ResumePath,                     // apply_resume
                PhotoPath,                      // apply_photo
                ReceiptPath,                    // apply_payment_receipt
                "Pending",                      // status
                Program.LoginMid,               // UserId
                "",                             // apply_extra1
                "",                             // apply_extra2
                "",                             // apply_extra3
                "",                             // apply_extra4
                ""                              // apply_extra5
            );

            if (Result > 0)
            {
                GenerateReferenceNo(SelectedJobCode, txtnumber.Text.Trim(), txtemail.Text.Trim());

                MessageBox.Show("Application Submitted Successfully",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                btnclear_Click(null, null);
                BindJobList();
                ShowPanel(pnlapplication);
            }
            else
            {
                MessageBox.Show("Application Submission Failed",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void LoadCandidateDetails()
        {
            string query = "select reg_name, reg_email, reg_mobile, reg_dob from tbl_registration where reg_Mid = " + Program.LoginMid;
            DataSet ds = DM.GetDataSet(query);

            if (ds.Tables[0].Rows.Count > 0)
            {
                txtname.Text = ds.Tables[0].Rows[0]["reg_name"].ToString();
                txtnumber.Text = ds.Tables[0].Rows[0]["reg_mobile"].ToString();
                txtemail.Text = ds.Tables[0].Rows[0]["reg_email"].ToString();
                txtdob.Text = Convert.ToDateTime(ds.Tables[0].Rows[0]["reg_dob"]).ToString("dd-MM-yyyy");
            }
        }

        public void GenerateReferenceNo(string jobcode, string mobile, string email)
        {
            try
            {
                string qry = "select * from tbl_application where apply_jobcode = '" + jobcode +
                             "' and apply_mobile_no = '" + mobile +
                             "' and apply_email = '" + email +
                             "' order by apply_Mid desc";

                DataSet ds = DM.GetDataSet(qry);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    int Mid = Convert.ToInt32(ds.Tables[0].Rows[0]["apply_Mid"]);

                    // Get the actual Job Code (AB025) using Job Mid (25)
                    string jobQry = "select job_code from tbl_jobs where job_Mid = " + jobcode;
                    DataSet dsJob = DM.GetDataSet(jobQry);

                    string ActualJobCode = "";

                    if (dsJob.Tables[0].Rows.Count > 0)
                    {
                        ActualJobCode = dsJob.Tables[0].Rows[0]["job_code"].ToString();
                    }

                    int Number = 1000 + Mid;
                    string ReferenceNo = ActualJobCode + Number.ToString();

                    ObjApplication.ApplicationTransaction(
                        5,
                        Mid,
                        0,
                        "",
                        "",
                        ReferenceNo,
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        0,
                        "",
                        "",
                        "",
                        "",
                        ""
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            txtnationality.Clear();
            txtqualification.Clear();
            txttotal.Clear();
            rdbmale.Checked = false;
            rdbfemale.Checked = false;
            rdbother.Checked = false;

            rdbsingle.Checked = false;
            rdbmarried.Checked = false;

            rdbfresher.Checked = false;
            rdbexperienced.Checked = false;

            PhotoPath = "";
            ResumePath = "";
            ReceiptPath = "";
            picbreceipt.Image = null;
            txtname.Focus();
        }
        private void btnuploadreceipt_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Payment Receipt";
            ofd.Filter = "Image Files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png|PDF Files (*.pdf)|*.pdf";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ReceiptPath = SaveFileToFolder(ofd.FileName, "RECEIPT");

                MessageBox.Show("Receipt Selected Successfully",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private string SaveFileToFolder(string sourcePath, string prefix)
        {
            string folder = Path.Combine(Application.StartupPath, @"..\..\Reg_Photo");
            folder = Path.GetFullPath(folder);

            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);

            string destination = Path.Combine(
                folder,
                prefix + "_" + DateTime.Now.Ticks + Path.GetExtension(sourcePath));

            File.Copy(sourcePath, destination, true);

            return destination;
        }
        private void btnphoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Photo";
            ofd.Filter = "Image Files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                PhotoPath = SaveFileToFolder(ofd.FileName, "PHOTO");

                picbreceipt.Image = Image.FromFile(PhotoPath);
                picbreceipt.SizeMode = PictureBoxSizeMode.Zoom;

                MessageBox.Show("Photo Selected Successfully",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void btnresume_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Resume";
            ofd.Filter = "PDF Files (*.pdf)|*.pdf|Word Files (*.doc;*.docx)|*.doc;*.docx";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ResumePath = SaveFileToFolder(ofd.FileName, "RESUME");

                MessageBox.Show("Resume Selected Successfully",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void btnback1_Click(object sender, EventArgs e)
        {
            btnclear_Click(null, null);

            FrmApply frm = new FrmApply();
            frm.MdiParent = this.MdiParent;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.WindowState = FormWindowState.Normal;

            frm.Show();
            this.Close();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            FrmCandiateHome frm = new FrmCandiateHome();
            frm.MdiParent = this.MdiParent;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.WindowState = FormWindowState.Normal;

            frm.Show();
            this.Close();
        }

        private void dgvjoblist_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(
 //   "Job Mid = " + dgvjoblist.Rows[e.RowIndex].Cells["colapplymid"].Value +
 //   "\nJob Code = " + dgvjoblist.Rows[e.RowIndex].Cells["coljobcode"].Value);
            if (e.RowIndex < 0)
                return;
          //  SelectedJobMid = Convert.ToInt32(dgvjoblist.Rows[e.RowIndex].Cells["colapplymid"].Value);
            SelectedJobCode = dgvjoblist.Rows[e.RowIndex].Cells["colapplymid"].Value.ToString();
            txtjobpost.Text = dgvjoblist.Rows[e.RowIndex].Cells["coljobtitle"].Value.ToString();

            LoadCandidateDetails();
            ShowPanel(pnlapply);
        }

        private void dgvjoblist_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            dgvjoblist.Rows[e.RowIndex].Cells["colsln"].Value = (e.RowIndex + 1).ToString();
        }
    }
}

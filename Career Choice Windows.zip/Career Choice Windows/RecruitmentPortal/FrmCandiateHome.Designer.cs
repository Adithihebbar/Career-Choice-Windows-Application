﻿using System.Windows.Forms;
namespace RecruitmentPortal
{
    partial class FrmCandiateHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlhome = new System.Windows.Forms.Panel();
            this.lblcandname = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblnodata = new System.Windows.Forms.Label();
            this.btnapplication = new System.Windows.Forms.Button();
            this.pnlstat = new System.Windows.Forms.Panel();
            this.lblstat = new System.Windows.Forms.Label();
            this.lblhead = new System.Windows.Forms.Label();
            this.dgvappliedjob = new System.Windows.Forms.DataGridView();
            this.colslno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colview = new System.Windows.Forms.DataGridViewButtonColumn();
            this.coljobmid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colreferenceno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coljobdetails = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblheading = new System.Windows.Forms.Label();
            this.pnlview = new System.Windows.Forms.Panel();
            this.btnback2 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.picbphoto = new System.Windows.Forms.PictureBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblresume1 = new System.Windows.Forms.Label();
            this.lbltotalexperience = new System.Windows.Forms.Label();
            this.lblexperience = new System.Windows.Forms.Label();
            this.lblqualify = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblmaritalstatus = new System.Windows.Forms.Label();
            this.lblnation = new System.Windows.Forms.Label();
            this.lbldateofbirth = new System.Windows.Forms.Label();
            this.lblemailid = new System.Windows.Forms.Label();
            this.lblnumber = new System.Windows.Forms.Label();
            this.lblcandidatename = new System.Windows.Forms.Label();
            this.lblReferenceNumber = new System.Windows.Forms.Label();
            this.lblpost = new System.Windows.Forms.Label();
            this.pnlmain = new System.Windows.Forms.Panel();
            this.pnlhome.SuspendLayout();
            this.pnlstat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvappliedjob)).BeginInit();
            this.pnlview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbphoto)).BeginInit();
            this.pnlmain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlhome
            // 
            this.pnlhome.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlhome.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlhome.Controls.Add(this.lblcandname);
            this.pnlhome.Controls.Add(this.label2);
            this.pnlhome.Controls.Add(this.label12);
            this.pnlhome.Controls.Add(this.lblnodata);
            this.pnlhome.Controls.Add(this.btnapplication);
            this.pnlhome.Controls.Add(this.pnlstat);
            this.pnlhome.Controls.Add(this.dgvappliedjob);
            this.pnlhome.Controls.Add(this.lblheading);
            this.pnlhome.Location = new System.Drawing.Point(0, 0);
            this.pnlhome.Name = "pnlhome";
            this.pnlhome.Size = new System.Drawing.Size(991, 771);
            this.pnlhome.TabIndex = 0;
            // 
            // lblcandname
            // 
            this.lblcandname.AutoSize = true;
            this.lblcandname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcandname.Location = new System.Drawing.Point(154, 81);
            this.lblcandname.Name = "lblcandname";
            this.lblcandname.Size = new System.Drawing.Size(173, 25);
            this.lblcandname.TabIndex = 9;
            this.lblcandname.Text = "Candidate Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(45, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Welcome, ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(54, 389);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(196, 29);
            this.label12.TabIndex = 6;
            this.label12.Text = "My Applications";
            // 
            // lblnodata
            // 
            this.lblnodata.AutoSize = true;
            this.lblnodata.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblnodata.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnodata.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblnodata.Location = new System.Drawing.Point(202, 508);
            this.lblnodata.Name = "lblnodata";
            this.lblnodata.Size = new System.Drawing.Size(359, 60);
            this.lblnodata.TabIndex = 5;
            this.lblnodata.Text = "No applications submitted yet.\r\n\r\nClick \"New Application\" to apply for a job.";
            // 
            // btnapplication
            // 
            this.btnapplication.BackColor = System.Drawing.Color.White;
            this.btnapplication.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnapplication.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnapplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnapplication.ForeColor = System.Drawing.Color.Black;
            this.btnapplication.Location = new System.Drawing.Point(381, 308);
            this.btnapplication.Name = "btnapplication";
            this.btnapplication.Size = new System.Drawing.Size(180, 45);
            this.btnapplication.TabIndex = 4;
            this.btnapplication.Text = "New Application";
            this.btnapplication.UseVisualStyleBackColor = false;
            this.btnapplication.Click += new System.EventHandler(this.btnapplication_Click);
            // 
            // pnlstat
            // 
            this.pnlstat.BackColor = System.Drawing.Color.White;
            this.pnlstat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlstat.Controls.Add(this.lblstat);
            this.pnlstat.Controls.Add(this.lblhead);
            this.pnlstat.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlstat.Location = new System.Drawing.Point(340, 151);
            this.pnlstat.Name = "pnlstat";
            this.pnlstat.Size = new System.Drawing.Size(268, 121);
            this.pnlstat.TabIndex = 3;
            // 
            // lblstat
            // 
            this.lblstat.AutoSize = true;
            this.lblstat.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstat.ForeColor = System.Drawing.Color.Black;
            this.lblstat.Location = new System.Drawing.Point(101, 56);
            this.lblstat.Name = "lblstat";
            this.lblstat.Size = new System.Drawing.Size(33, 36);
            this.lblstat.TabIndex = 1;
            this.lblstat.Text = "0";
            // 
            // lblhead
            // 
            this.lblhead.AutoSize = true;
            this.lblhead.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhead.ForeColor = System.Drawing.Color.Black;
            this.lblhead.Location = new System.Drawing.Point(15, 11);
            this.lblhead.Name = "lblhead";
            this.lblhead.Size = new System.Drawing.Size(233, 25);
            this.lblhead.TabIndex = 0;
            this.lblhead.Text = "Applications Submitted";
            // 
            // dgvappliedjob
            // 
            this.dgvappliedjob.AllowUserToAddRows = false;
            this.dgvappliedjob.AllowUserToDeleteRows = false;
            this.dgvappliedjob.AllowUserToOrderColumns = true;
            this.dgvappliedjob.AllowUserToResizeColumns = false;
            this.dgvappliedjob.AllowUserToResizeRows = false;
            this.dgvappliedjob.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvappliedjob.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvappliedjob.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dgvappliedjob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvappliedjob.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colslno,
            this.colview,
            this.coljobmid,
            this.colreferenceno,
            this.coljobdetails});
            this.dgvappliedjob.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgvappliedjob.Location = new System.Drawing.Point(59, 447);
            this.dgvappliedjob.Name = "dgvappliedjob";
            this.dgvappliedjob.RowHeadersVisible = false;
            this.dgvappliedjob.RowTemplate.Height = 24;
            this.dgvappliedjob.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvappliedjob.Size = new System.Drawing.Size(889, 199);
            this.dgvappliedjob.TabIndex = 2;
            this.dgvappliedjob.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvappliedjob_CellContentClick);
            this.dgvappliedjob.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvappliedjob_RowPostPaint);
            // 
            // colslno
            // 
            this.colslno.HeaderText = "Sl no.";
            this.colslno.Name = "colslno";
            this.colslno.ReadOnly = true;
            // 
            // colview
            // 
            this.colview.HeaderText = "View";
            this.colview.Name = "colview";
            this.colview.ReadOnly = true;
            this.colview.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colview.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colview.Text = "View";
            this.colview.UseColumnTextForButtonValue = true;
            // 
            // coljobmid
            // 
            this.coljobmid.DataPropertyName = "job_Mid";
            this.coljobmid.HeaderText = "Job Mid";
            this.coljobmid.Name = "coljobmid";
            this.coljobmid.ReadOnly = true;
            this.coljobmid.Visible = false;
            // 
            // colreferenceno
            // 
            this.colreferenceno.DataPropertyName = "apply_reference_no";
            this.colreferenceno.HeaderText = "Recerence No";
            this.colreferenceno.Name = "colreferenceno";
            this.colreferenceno.ReadOnly = true;
            // 
            // coljobdetails
            // 
            this.coljobdetails.DataPropertyName = "apply_jobpost";
            this.coljobdetails.HeaderText = "Job Details";
            this.coljobdetails.Name = "coljobdetails";
            this.coljobdetails.ReadOnly = true;
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.BackColor = System.Drawing.Color.Transparent;
            this.lblheading.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.ForeColor = System.Drawing.Color.Navy;
            this.lblheading.Location = new System.Drawing.Point(323, 13);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(275, 38);
            this.lblheading.TabIndex = 1;
            this.lblheading.Text = "Candidate Home";
            // 
            // pnlview
            // 
            this.pnlview.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlview.Controls.Add(this.btnback2);
            this.pnlview.Controls.Add(this.label30);
            this.pnlview.Controls.Add(this.picbphoto);
            this.pnlview.Controls.Add(this.label28);
            this.pnlview.Controls.Add(this.label27);
            this.pnlview.Controls.Add(this.label26);
            this.pnlview.Controls.Add(this.label25);
            this.pnlview.Controls.Add(this.label24);
            this.pnlview.Controls.Add(this.label23);
            this.pnlview.Controls.Add(this.label22);
            this.pnlview.Controls.Add(this.label21);
            this.pnlview.Controls.Add(this.label20);
            this.pnlview.Controls.Add(this.label19);
            this.pnlview.Controls.Add(this.label18);
            this.pnlview.Controls.Add(this.label17);
            this.pnlview.Controls.Add(this.label16);
            this.pnlview.Controls.Add(this.lblresume1);
            this.pnlview.Controls.Add(this.lbltotalexperience);
            this.pnlview.Controls.Add(this.lblexperience);
            this.pnlview.Controls.Add(this.lblqualify);
            this.pnlview.Controls.Add(this.lblgender);
            this.pnlview.Controls.Add(this.lblmaritalstatus);
            this.pnlview.Controls.Add(this.lblnation);
            this.pnlview.Controls.Add(this.lbldateofbirth);
            this.pnlview.Controls.Add(this.lblemailid);
            this.pnlview.Controls.Add(this.lblnumber);
            this.pnlview.Controls.Add(this.lblcandidatename);
            this.pnlview.Controls.Add(this.lblReferenceNumber);
            this.pnlview.Controls.Add(this.lblpost);
            this.pnlview.Location = new System.Drawing.Point(0, 0);
            this.pnlview.Name = "pnlview";
            this.pnlview.Size = new System.Drawing.Size(896, 760);
            this.pnlview.TabIndex = 2;
            // 
            // btnback2
            // 
            this.btnback2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnback2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback2.Location = new System.Drawing.Point(758, 52);
            this.btnback2.Name = "btnback2";
            this.btnback2.Size = new System.Drawing.Size(100, 40);
            this.btnback2.TabIndex = 28;
            this.btnback2.Text = "Back";
            this.btnback2.UseVisualStyleBackColor = false;
            this.btnback2.Click += new System.EventHandler(this.btnback2_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label30.Location = new System.Drawing.Point(333, 17);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(242, 32);
            this.label30.TabIndex = 27;
            this.label30.Text = "View Application";
            // 
            // picbphoto
            // 
            this.picbphoto.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.picbphoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbphoto.Location = new System.Drawing.Point(59, 106);
            this.picbphoto.Name = "picbphoto";
            this.picbphoto.Size = new System.Drawing.Size(116, 134);
            this.picbphoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbphoto.TabIndex = 26;
            this.picbphoto.TabStop = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(316, 588);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(89, 20);
            this.label28.TabIndex = 25;
            this.label28.Text = "Resume :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(243, 548);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(162, 20);
            this.label27.TabIndex = 24;
            this.label27.Text = "Total Experience :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(245, 508);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(160, 20);
            this.label26.TabIndex = 23;
            this.label26.Text = "Experience Type :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(278, 468);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(127, 20);
            this.label25.TabIndex = 22;
            this.label25.Text = "Qualification :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(323, 428);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 20);
            this.label24.TabIndex = 21;
            this.label24.Text = "Gender :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(266, 388);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(139, 20);
            this.label23.TabIndex = 20;
            this.label23.Text = "Marital Status :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(295, 348);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 20);
            this.label22.TabIndex = 19;
            this.label22.Text = "Nationality :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(275, 308);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(130, 20);
            this.label21.TabIndex = 18;
            this.label21.Text = "Date of Birth :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(337, 268);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(68, 20);
            this.label20.TabIndex = 17;
            this.label20.Text = "Email :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(258, 228);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(147, 20);
            this.label19.TabIndex = 16;
            this.label19.Text = "Mobile Number :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(336, 188);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 20);
            this.label18.TabIndex = 15;
            this.label18.Text = "Name :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(227, 148);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(178, 20);
            this.label17.TabIndex = 14;
            this.label17.Text = "Reference Number :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(310, 108);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 20);
            this.label16.TabIndex = 13;
            this.label16.Text = "Job Post :";
            // 
            // lblresume1
            // 
            this.lblresume1.AutoSize = true;
            this.lblresume1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresume1.Location = new System.Drawing.Point(470, 588);
            this.lblresume1.Name = "lblresume1";
            this.lblresume1.Size = new System.Drawing.Size(165, 20);
            this.lblresume1.TabIndex = 12;
            this.lblresume1.Text = "Resume Download";
            this.lblresume1.Click += new System.EventHandler(this.lblresume1_Click);
            // 
            // lbltotalexperience
            // 
            this.lbltotalexperience.AutoSize = true;
            this.lbltotalexperience.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalexperience.Location = new System.Drawing.Point(470, 548);
            this.lbltotalexperience.Name = "lbltotalexperience";
            this.lbltotalexperience.Size = new System.Drawing.Size(156, 20);
            this.lbltotalexperience.TabIndex = 11;
            this.lbltotalexperience.Text = "Total Experience ";
            // 
            // lblexperience
            // 
            this.lblexperience.AutoSize = true;
            this.lblexperience.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexperience.Location = new System.Drawing.Point(470, 508);
            this.lblexperience.Name = "lblexperience";
            this.lblexperience.Size = new System.Drawing.Size(148, 20);
            this.lblexperience.TabIndex = 10;
            this.lblexperience.Text = "Experience Type";
            // 
            // lblqualify
            // 
            this.lblqualify.AutoSize = true;
            this.lblqualify.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqualify.Location = new System.Drawing.Point(470, 468);
            this.lblqualify.Name = "lblqualify";
            this.lblqualify.Size = new System.Drawing.Size(121, 20);
            this.lblqualify.TabIndex = 9;
            this.lblqualify.Text = "Qualification ";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.Location = new System.Drawing.Point(470, 428);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(76, 20);
            this.lblgender.TabIndex = 8;
            this.lblgender.Text = "Gender ";
            // 
            // lblmaritalstatus
            // 
            this.lblmaritalstatus.AutoSize = true;
            this.lblmaritalstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmaritalstatus.Location = new System.Drawing.Point(470, 388);
            this.lblmaritalstatus.Name = "lblmaritalstatus";
            this.lblmaritalstatus.Size = new System.Drawing.Size(133, 20);
            this.lblmaritalstatus.TabIndex = 7;
            this.lblmaritalstatus.Text = "Marital Status ";
            // 
            // lblnation
            // 
            this.lblnation.AutoSize = true;
            this.lblnation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnation.Location = new System.Drawing.Point(470, 348);
            this.lblnation.Name = "lblnation";
            this.lblnation.Size = new System.Drawing.Size(104, 20);
            this.lblnation.TabIndex = 6;
            this.lblnation.Text = "Nationality ";
            // 
            // lbldateofbirth
            // 
            this.lbldateofbirth.AutoSize = true;
            this.lbldateofbirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldateofbirth.Location = new System.Drawing.Point(470, 308);
            this.lbldateofbirth.Name = "lbldateofbirth";
            this.lbldateofbirth.Size = new System.Drawing.Size(124, 20);
            this.lbldateofbirth.TabIndex = 5;
            this.lbldateofbirth.Text = "Date of Birth ";
            // 
            // lblemailid
            // 
            this.lblemailid.AutoSize = true;
            this.lblemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemailid.Location = new System.Drawing.Point(470, 268);
            this.lblemailid.Name = "lblemailid";
            this.lblemailid.Size = new System.Drawing.Size(62, 20);
            this.lblemailid.TabIndex = 4;
            this.lblemailid.Text = "Email ";
            // 
            // lblnumber
            // 
            this.lblnumber.AutoSize = true;
            this.lblnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumber.Location = new System.Drawing.Point(470, 228);
            this.lblnumber.Name = "lblnumber";
            this.lblnumber.Size = new System.Drawing.Size(141, 20);
            this.lblnumber.TabIndex = 3;
            this.lblnumber.Text = "Mobile Number ";
            // 
            // lblcandidatename
            // 
            this.lblcandidatename.AutoSize = true;
            this.lblcandidatename.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcandidatename.Location = new System.Drawing.Point(470, 188);
            this.lblcandidatename.Name = "lblcandidatename";
            this.lblcandidatename.Size = new System.Drawing.Size(63, 20);
            this.lblcandidatename.TabIndex = 2;
            this.lblcandidatename.Text = "Name ";
            // 
            // lblReferenceNumber
            // 
            this.lblReferenceNumber.AutoSize = true;
            this.lblReferenceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReferenceNumber.Location = new System.Drawing.Point(470, 148);
            this.lblReferenceNumber.Name = "lblReferenceNumber";
            this.lblReferenceNumber.Size = new System.Drawing.Size(172, 20);
            this.lblReferenceNumber.TabIndex = 1;
            this.lblReferenceNumber.Text = "Reference Number ";
            // 
            // lblpost
            // 
            this.lblpost.AutoSize = true;
            this.lblpost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpost.Location = new System.Drawing.Point(470, 108);
            this.lblpost.Name = "lblpost";
            this.lblpost.Size = new System.Drawing.Size(89, 20);
            this.lblpost.TabIndex = 0;
            this.lblpost.Text = "Job Post ";
            // 
            // pnlmain
            // 
            this.pnlmain.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlmain.Controls.Add(this.pnlview);
            this.pnlmain.Controls.Add(this.pnlhome);
            this.pnlmain.Location = new System.Drawing.Point(0, 0);
            this.pnlmain.Name = "pnlmain";
            this.pnlmain.Size = new System.Drawing.Size(1100, 800);
            this.pnlmain.TabIndex = 3;
            // 
            // FrmCandiateHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1280, 768);
            this.ControlBox = false;
            this.Controls.Add(this.pnlmain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmCandiateHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmCandiateHome";
            this.Load += new System.EventHandler(this.FrmCandiateHome_Load);
            this.Resize += new System.EventHandler(this.FrmCandiateHome_Resize);
            this.pnlhome.ResumeLayout(false);
            this.pnlhome.PerformLayout();
            this.pnlstat.ResumeLayout(false);
            this.pnlstat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvappliedjob)).EndInit();
            this.pnlview.ResumeLayout(false);
            this.pnlview.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbphoto)).EndInit();
            this.pnlmain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlhome;
        private System.Windows.Forms.Panel pnlstat;
        private System.Windows.Forms.DataGridView dgvappliedjob;
        private System.Windows.Forms.Label lblheading;
        private System.Windows.Forms.Label lblstat;
        private System.Windows.Forms.Label lblhead;
        private System.Windows.Forms.Button btnapplication;
        private Panel pnlview;
        private Label lblpost;
        private Label lblresume1;
        private Label lbltotalexperience;
        private Label lblexperience;
        private Label lblqualify;
        private Label lblgender;
        private Label lblmaritalstatus;
        private Label lblnation;
        private Label lbldateofbirth;
        private Label lblemailid;
        private Label lblnumber;
        private Label lblcandidatename;
        private Label lblReferenceNumber;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private PictureBox picbphoto;
        private Label lblnodata;
        private Label label12;
        private DataGridViewTextBoxColumn colslno;
        private DataGridViewButtonColumn colview;
        private DataGridViewTextBoxColumn coljobmid;
        private DataGridViewTextBoxColumn colreferenceno;
        private DataGridViewTextBoxColumn coljobdetails;
        private Label label30;
        private Button btnback2;
        private Label lblcandname;
        private Label label2;
        private Panel pnlmain;
    }
}
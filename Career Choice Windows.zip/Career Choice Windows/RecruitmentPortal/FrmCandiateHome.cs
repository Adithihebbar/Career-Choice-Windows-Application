﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace RecruitmentPortal
{
    public partial class FrmCandiateHome : Form
    {
        DataManager DM = new DataManager();
        string ResumePath = "";

        public FrmCandiateHome()
        {
            InitializeComponent();
        }

        private void btnapplication_Click(object sender, EventArgs e)
        {
            FrmApply frm = new FrmApply();
            frm.MdiParent = this.MdiParent;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.WindowState = FormWindowState.Normal;

            this.Close();
            frm.Show();
        }

        private void FrmCandiateHome_Load(object sender, EventArgs e)
        {
           // this.AutoScroll = true;

            ShowPanel(pnlhome);
            BindDashboard();
            BindAppliedJobs();
            dgvappliedjob.AllowUserToAddRows = false;
            LoadCandidateName();
            CenterPanel();
            dgvappliedjob.EnableHeadersVisualStyles = false;
        }

        private void CenterPanel()
        {
            pnlmain.Left = (this.ClientSize.Width - pnlmain.Width) / 2;
            pnlmain.Top = 20;   // Adjust if you want more or less top spacing
        }

        private void FrmCandiateHome_Resize(object sender, EventArgs e)
        {
            // Load fires before the MDI parent docks/stretches this form
            // (Dock = DockStyle.Fill is applied afterward in OpenChildForm()),
            // so CenterPanel() must run again here to re-center pnlmain
            // against the form's actual final size, not just at Load.
            CenterPanel();
        }
        private void LoadCandidateName()
        {
            string query = "SELECT reg_name FROM tbl_registration WHERE reg_Mid = " + Program.LoginMid;
            DataSet ds = DM.GetDataSet(query);

            if (ds.Tables[0].Rows.Count > 0)
            {
                lblcandname.Text = ds.Tables[0].Rows[0]["reg_name"].ToString();
            }
        }
        private void ShowPanel(Panel pnl)
        {
            pnlhome.Visible = false;
            pnlview.Visible = false;

            pnl.Visible = true;
        }

        private void BindDashboard()
        {
            try
            {
                string Query = "select count(apply_Mid) total from tbl_application where apply_regMid = " + Program.LoginMid;
                DataSet ds = DM.GetDataSet(Query);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    lblstat.Text = ds.Tables[0].Rows[0]["Total"].ToString();
                }
                else
                {
                    lblstat.Text = "0";
                }
            }
            catch
            {
                lblstat.Text = "0";
            }
        }

        private void BindAppliedJobs()
        {
            try
            {
                string query = "select apply_reference_no, apply_jobpost, apply_status, apply_CreatedOn " +
                               "from tbl_application " +
                               "where apply_Activeflag = 1 and apply_regMid = " + Program.LoginMid +
                               " order by apply_Mid desc";

                DataSet ds = DM.GetDataSet(query);

                dgvappliedjob.AutoGenerateColumns = false;

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dgvappliedjob.Visible = true;
                    lblnodata.Visible = false;

                    dgvappliedjob.DataSource = ds.Tables[0];
                    for (int i = 0; i < dgvappliedjob.Rows.Count; i++)
                    {
                        dgvappliedjob.Rows[i].Cells["colslno"].Value = i + 1;
                    }
                    dgvappliedjob.ClearSelection();

                }
                else
                {
                    dgvappliedjob.Visible = false;
                    lblnodata.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvappliedjob_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            if (dgvappliedjob.Columns[e.ColumnIndex].Name == "colview")
            {
                string RefNo = dgvappliedjob.Rows[e.RowIndex].Cells["colreferenceno"].Value.ToString();
                LoadApplicationDetails(RefNo);
                ShowPanel(pnlview);
            }
        }

        private void LoadApplicationDetails(string RefNo)
        {
            try
            {
                string query = "select * from tbl_application where apply_reference_no = '" + RefNo + "'";

                DataSet ds = DM.GetDataSet(query);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];

                    lblpost.Text = dr["apply_jobpost"].ToString();
                    lblReferenceNumber.Text = dr["apply_reference_no"].ToString();
                    lblcandidatename.Text = dr["apply_name"].ToString();
                    lblnumber.Text = dr["apply_mobile_no"].ToString();
                    lblemailid.Text = dr["apply_email"].ToString();
                    lbldateofbirth.Text = Convert.ToDateTime(dr["apply_dob"]).ToString("dd-MM-yyyy");
                    lblnation.Text = dr["apply_nationality"].ToString();
                    lblmaritalstatus.Text = dr["apply_marital_status"].ToString();
                    lblgender.Text = dr["apply_gender"].ToString();
                    lblqualify.Text = dr["apply_min_qualification"].ToString();
                    lblexperience.Text = dr["apply_experience_type"].ToString();
                    string totalExp = dr["apply_total_experience"].ToString().Trim();

                    if (string.IsNullOrEmpty(totalExp))
                    {
                        lbltotalexperience.Text = "0";
                    }
                    else
                    {
                        lbltotalexperience.Text = totalExp;
                    }
                    lblresume1.Text = "Download Resume";

                    ResumePath = dr["apply_resume"].ToString();

                    string Photo = dr["apply_photo"].ToString();

                    string webRootPath = @"C:\Users\Adithi\OneDrive\Desktop\A1 logics\RecruitmentPortal";
                    string relativePath = Photo.Replace("~/", "").Replace("/", "\\");
                    string fullPath = Path.Combine(webRootPath, relativePath);
                    if (File.Exists(fullPath))
                    {
                        picbphoto.ImageLocation = fullPath;
                        picbphoto.SizeMode = PictureBoxSizeMode.StretchImage;
                    }
                    else
                    {
                        picbphoto.Image = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lblresume1_Click(object sender, EventArgs e)
        {
            if (ResumePath != "")
            {
                if (File.Exists(ResumePath))
                {
                    System.Diagnostics.Process.Start(ResumePath);
                }
                else
                {
                    MessageBox.Show("Resume not found");
                }
            }
        }

        private void dgvappliedjob_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            dgvappliedjob.Rows[e.RowIndex].Cells["colslno"].Value = (e.RowIndex + 1).ToString();
        }


        private void btnback2_Click(object sender, EventArgs e)
        {
            ShowPanel(pnlhome);
            BindAppliedJobs();
        }
    }
}
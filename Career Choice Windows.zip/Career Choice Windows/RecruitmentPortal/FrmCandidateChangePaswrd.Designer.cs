﻿namespace RecruitmentPortal
{
    partial class FrmCandidateChangePaswrd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlchangepassword = new System.Windows.Forms.Panel();
            this.btnback = new System.Windows.Forms.Button();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.txtnewpaswrd = new System.Windows.Forms.TextBox();
            this.txtcurrentpaswrd = new System.Windows.Forms.TextBox();
            this.txtconfirmpaswrd = new System.Windows.Forms.TextBox();
            this.lblconfirmpaswrd = new System.Windows.Forms.Label();
            this.lblnewpaswrd = new System.Windows.Forms.Label();
            this.lblcurrentpaswrd = new System.Windows.Forms.Label();
            this.lblchange = new System.Windows.Forms.Label();
            this.pnlchangepassword.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlchangepassword
            // 
            this.pnlchangepassword.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlchangepassword.Controls.Add(this.btnback);
            this.pnlchangepassword.Controls.Add(this.btnrefresh);
            this.pnlchangepassword.Controls.Add(this.btnsubmit);
            this.pnlchangepassword.Controls.Add(this.txtnewpaswrd);
            this.pnlchangepassword.Controls.Add(this.txtcurrentpaswrd);
            this.pnlchangepassword.Controls.Add(this.txtconfirmpaswrd);
            this.pnlchangepassword.Controls.Add(this.lblconfirmpaswrd);
            this.pnlchangepassword.Controls.Add(this.lblnewpaswrd);
            this.pnlchangepassword.Controls.Add(this.lblcurrentpaswrd);
            this.pnlchangepassword.Controls.Add(this.lblchange);
            this.pnlchangepassword.Location = new System.Drawing.Point(124, 47);
            this.pnlchangepassword.Name = "pnlchangepassword";
            this.pnlchangepassword.Size = new System.Drawing.Size(679, 438);
            this.pnlchangepassword.TabIndex = 0;
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(542, 64);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(100, 40);
            this.btnback.TabIndex = 10;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.Location = new System.Drawing.Point(329, 352);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(100, 40);
            this.btnrefresh.TabIndex = 9;
            this.btnrefresh.Text = "Reset";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(161, 352);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(100, 40);
            this.btnsubmit.TabIndex = 8;
            this.btnsubmit.Text = "Update";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // txtnewpaswrd
            // 
            this.txtnewpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewpaswrd.Location = new System.Drawing.Point(311, 177);
            this.txtnewpaswrd.Name = "txtnewpaswrd";
            this.txtnewpaswrd.Size = new System.Drawing.Size(140, 28);
            this.txtnewpaswrd.TabIndex = 7;
            // 
            // txtcurrentpaswrd
            // 
            this.txtcurrentpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcurrentpaswrd.Location = new System.Drawing.Point(311, 109);
            this.txtcurrentpaswrd.Name = "txtcurrentpaswrd";
            this.txtcurrentpaswrd.Size = new System.Drawing.Size(140, 28);
            this.txtcurrentpaswrd.TabIndex = 6;
            // 
            // txtconfirmpaswrd
            // 
            this.txtconfirmpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtconfirmpaswrd.Location = new System.Drawing.Point(311, 245);
            this.txtconfirmpaswrd.Name = "txtconfirmpaswrd";
            this.txtconfirmpaswrd.Size = new System.Drawing.Size(140, 28);
            this.txtconfirmpaswrd.TabIndex = 5;
            // 
            // lblconfirmpaswrd
            // 
            this.lblconfirmpaswrd.AutoSize = true;
            this.lblconfirmpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconfirmpaswrd.Location = new System.Drawing.Point(84, 245);
            this.lblconfirmpaswrd.Name = "lblconfirmpaswrd";
            this.lblconfirmpaswrd.Size = new System.Drawing.Size(175, 20);
            this.lblconfirmpaswrd.TabIndex = 3;
            this.lblconfirmpaswrd.Text = "Confirm Password :";
            // 
            // lblnewpaswrd
            // 
            this.lblnewpaswrd.AutoSize = true;
            this.lblnewpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnewpaswrd.Location = new System.Drawing.Point(114, 181);
            this.lblnewpaswrd.Name = "lblnewpaswrd";
            this.lblnewpaswrd.Size = new System.Drawing.Size(145, 20);
            this.lblnewpaswrd.TabIndex = 2;
            this.lblnewpaswrd.Text = "New Password :";
            // 
            // lblcurrentpaswrd
            // 
            this.lblcurrentpaswrd.AutoSize = true;
            this.lblcurrentpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcurrentpaswrd.Location = new System.Drawing.Point(87, 117);
            this.lblcurrentpaswrd.Name = "lblcurrentpaswrd";
            this.lblcurrentpaswrd.Size = new System.Drawing.Size(172, 20);
            this.lblcurrentpaswrd.TabIndex = 1;
            this.lblcurrentpaswrd.Text = "Current Password :";
            // 
            // lblchange
            // 
            this.lblchange.AutoSize = true;
            this.lblchange.BackColor = System.Drawing.Color.Transparent;
            this.lblchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchange.Location = new System.Drawing.Point(189, 22);
            this.lblchange.Name = "lblchange";
            this.lblchange.Size = new System.Drawing.Size(225, 29);
            this.lblchange.TabIndex = 0;
            this.lblchange.Text = "Change Password";
            // 
            // FrmCandidateChangePaswrd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1024, 768);
            this.ControlBox = false;
            this.Controls.Add(this.pnlchangepassword);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmCandidateChangePaswrd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmCandidateChangePaswrd";
            this.Load += new System.EventHandler(this.FrmCandidateChangePaswrd_Load);
            this.pnlchangepassword.ResumeLayout(false);
            this.pnlchangepassword.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlchangepassword;
        private System.Windows.Forms.Label lblconfirmpaswrd;
        private System.Windows.Forms.Label lblnewpaswrd;
        private System.Windows.Forms.Label lblcurrentpaswrd;
        private System.Windows.Forms.Label lblchange;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.TextBox txtnewpaswrd;
        private System.Windows.Forms.TextBox txtcurrentpaswrd;
        private System.Windows.Forms.TextBox txtconfirmpaswrd;
        private System.Windows.Forms.Button btnback;
    }
}
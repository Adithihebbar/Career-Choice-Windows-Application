﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmCandidateChangePaswrd : Form
    {
        DataManager DM = new DataManager();
        public FrmCandidateChangePaswrd()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            FrmCandiateHome frm = new FrmCandiateHome();
            frm.MdiParent = this.MdiParent;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.WindowState = FormWindowState.Normal;
            frm.Show();
            this.Close();
        }
        private void CenterPanel()
        {
            pnlchangepassword.Left = (this.ClientSize.Width - pnlchangepassword.Width) / 2;
            pnlchangepassword.Top = 40;
        }
        private void btnsubmit_Click(object sender, EventArgs e)
        {
            if (txtcurrentpaswrd.Text.Trim() == "")
            {
                MessageBox.Show("Enter Current Password");
                txtcurrentpaswrd.Focus();
                return;
            }
            if (txtnewpaswrd.Text.Trim() == "")
            {
                MessageBox.Show("Enter New Password");
                txtnewpaswrd.Focus();
                return;
            }
            if (txtconfirmpaswrd.Text.Trim() == "")
            {
                MessageBox.Show("Enter Confirm Password");
                txtconfirmpaswrd.Focus();
                return;
            }

            if (txtcurrentpaswrd.Text.Trim() == txtnewpaswrd.Text.Trim())
            {
                MessageBox.Show("New Password cannot be same as Current Password");
                txtnewpaswrd.Clear();
                txtconfirmpaswrd.Clear();
                txtnewpaswrd.Focus();
                return;
            }

            if (txtnewpaswrd.Text.Trim() != txtconfirmpaswrd.Text.Trim())
            {
                MessageBox.Show("New Password and Confirm Password do not match");
                txtconfirmpaswrd.Clear();
                txtconfirmpaswrd.Focus();
                return;
            }
            //   MessageBox.Show("Candidate ID = " + Program.LoginMid);
            string query = "select * from tbl_registration where reg_Mid = '" + Program.LoginMid + "' and reg_password = '" + txtcurrentpaswrd.Text.Trim() + "'";
            DataSet ds = DM.GetDataSet(query);

            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("Current Password is Incorrect");
                txtcurrentpaswrd.Focus();
                return;
            }

            query = "update tbl_registration set reg_password = '" + txtnewpaswrd.Text.Trim() + "' where reg_Mid = '" + Program.LoginMid + "'";
            DM.ExecuteSQLCommand(query, false);
            MessageBox.Show("Password Changed Successfully");
            txtnewpaswrd.Clear();
            txtcurrentpaswrd.Clear();
            txtconfirmpaswrd.Clear();
            txtcurrentpaswrd.Focus();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            txtcurrentpaswrd.Clear();
            txtnewpaswrd.Clear();
            txtconfirmpaswrd.Clear();

            txtcurrentpaswrd.Focus();
        }

        private void FrmCandidateChangePaswrd_Load(object sender, EventArgs e)
        {
            CenterPanel();
        }
    }
}

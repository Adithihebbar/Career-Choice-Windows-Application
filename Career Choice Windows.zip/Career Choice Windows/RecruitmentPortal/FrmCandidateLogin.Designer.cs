﻿namespace RecruitmentPortal
{
    partial class FrmCandidateLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblcaptcharefresh = new System.Windows.Forms.Label();
            this.lnkregister = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnback = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.txtsum = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.lblequal = new System.Windows.Forms.Label();
            this.lblnum2 = new System.Windows.Forms.Label();
            this.lbladd = new System.Windows.Forms.Label();
            this.lblnum1 = new System.Windows.Forms.Label();
            this.lblsum = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblcaptcharefresh);
            this.panel1.Controls.Add(this.lnkregister);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnback);
            this.panel1.Controls.Add(this.btnclear);
            this.panel1.Controls.Add(this.btnsubmit);
            this.panel1.Controls.Add(this.txtsum);
            this.panel1.Controls.Add(this.txtpassword);
            this.panel1.Controls.Add(this.txtusername);
            this.panel1.Controls.Add(this.lblequal);
            this.panel1.Controls.Add(this.lblnum2);
            this.panel1.Controls.Add(this.lbladd);
            this.panel1.Controls.Add(this.lblnum1);
            this.panel1.Controls.Add(this.lblsum);
            this.panel1.Controls.Add(this.lblpassword);
            this.panel1.Controls.Add(this.lblusername);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(670, 525);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(211, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(230, 36);
            this.label2.TabIndex = 17;
            this.label2.Text = "Candiate Login";
            // 
            // lblcaptcharefresh
            // 
            this.lblcaptcharefresh.AutoSize = true;
            this.lblcaptcharefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcaptcharefresh.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblcaptcharefresh.Location = new System.Drawing.Point(470, 315);
            this.lblcaptcharefresh.Name = "lblcaptcharefresh";
            this.lblcaptcharefresh.Size = new System.Drawing.Size(34, 25);
            this.lblcaptcharefresh.TabIndex = 16;
            this.lblcaptcharefresh.Text = "🔄";
            this.lblcaptcharefresh.Click += new System.EventHandler(this.lblcaptcharefresh_Click);
            // 
            // lnkregister
            // 
            this.lnkregister.AutoSize = true;
            this.lnkregister.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkregister.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lnkregister.Location = new System.Drawing.Point(330, 443);
            this.lnkregister.Name = "lnkregister";
            this.lnkregister.Size = new System.Drawing.Size(109, 17);
            this.lnkregister.TabIndex = 15;
            this.lnkregister.TabStop = true;
            this.lnkregister.Text = "Register Here";
            this.lnkregister.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkregister_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(183, 443);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 17);
            this.label1.TabIndex = 14;
            this.label1.Text = "New Candidate?";
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnback.Location = new System.Drawing.Point(544, 68);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(100, 40);
            this.btnback.TabIndex = 13;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnclear.Location = new System.Drawing.Point(353, 376);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(100, 40);
            this.btnclear.TabIndex = 12;
            this.btnclear.Text = "Reset";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnsubmit.Location = new System.Drawing.Point(186, 376);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(100, 40);
            this.btnsubmit.TabIndex = 11;
            this.btnsubmit.Text = "Login";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // txtsum
            // 
            this.txtsum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsum.Location = new System.Drawing.Point(314, 312);
            this.txtsum.Name = "txtsum";
            this.txtsum.Size = new System.Drawing.Size(140, 28);
            this.txtsum.TabIndex = 9;
            // 
            // txtpassword
            // 
            this.txtpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.Location = new System.Drawing.Point(314, 187);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(140, 28);
            this.txtpassword.TabIndex = 8;
            // 
            // txtusername
            // 
            this.txtusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtusername.Location = new System.Drawing.Point(314, 118);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(140, 28);
            this.txtusername.TabIndex = 7;
            // 
            // lblequal
            // 
            this.lblequal.AutoSize = true;
            this.lblequal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblequal.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblequal.Location = new System.Drawing.Point(256, 320);
            this.lblequal.Name = "lblequal";
            this.lblequal.Size = new System.Drawing.Size(20, 20);
            this.lblequal.TabIndex = 6;
            this.lblequal.Text = "=";
            // 
            // lblnum2
            // 
            this.lblnum2.AutoSize = true;
            this.lblnum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnum2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblnum2.Location = new System.Drawing.Point(213, 320);
            this.lblnum2.Name = "lblnum2";
            this.lblnum2.Size = new System.Drawing.Size(19, 20);
            this.lblnum2.TabIndex = 5;
            this.lblnum2.Text = "0";
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladd.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lbladd.Location = new System.Drawing.Point(178, 320);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(20, 20);
            this.lbladd.TabIndex = 4;
            this.lbladd.Text = "+";
            // 
            // lblnum1
            // 
            this.lblnum1.AutoSize = true;
            this.lblnum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnum1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblnum1.Location = new System.Drawing.Point(144, 320);
            this.lblnum1.Name = "lblnum1";
            this.lblnum1.Size = new System.Drawing.Size(19, 20);
            this.lblnum1.TabIndex = 3;
            this.lblnum1.Text = "0";
            // 
            // lblsum
            // 
            this.lblsum.AutoSize = true;
            this.lblsum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsum.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblsum.Location = new System.Drawing.Point(47, 267);
            this.lblsum.Name = "lblsum";
            this.lblsum.Size = new System.Drawing.Size(204, 20);
            this.lblsum.TabIndex = 2;
            this.lblsum.Text = "Please Enter the Sum :";
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblpassword.Location = new System.Drawing.Point(144, 192);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(103, 20);
            this.lblpassword.TabIndex = 1;
            this.lblpassword.Text = "Password :";
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblusername.Location = new System.Drawing.Point(141, 123);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(106, 20);
            this.lblusername.TabIndex = 0;
            this.lblusername.Text = "Username :";
            // 
            // FrmCandidateLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(670, 525);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "FrmCandidateLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmCandidateLogin";
            this.Load += new System.EventHandler(this.FrmCandidateLogin_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtsum;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Label lblequal;
        private System.Windows.Forms.Label lblnum2;
        private System.Windows.Forms.Label lbladd;
        private System.Windows.Forms.Label lblnum1;
        private System.Windows.Forms.Label lblsum;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.LinkLabel lnkregister;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblcaptcharefresh;
        private System.Windows.Forms.Label label2;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmCandidateLogin : Form
    {
        DataManager DM = new DataManager();
        Random rnd = new Random();
        int captchaAnswer;

        public FrmCandidateLogin()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            if (txtusername.Text.Trim() == "")
            {
                MessageBox.Show("Enter Username");
                txtusername.Focus();
                return;
            }

            if (txtpassword.Text.Trim() == "")
            {
                MessageBox.Show("Enter Password");
                txtpassword.Focus();
                return;
            }
            if (txtsum.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Captcha");
                txtsum.Focus();
                return;
            }
            if (txtsum.Text.Trim() != captchaAnswer.ToString())
            {
                MessageBox.Show("Invalid Captcha");

                FnGenerateCaptcha();
                txtsum.Clear();
                txtsum.Focus();
                return;
            }
            string query = "select * from tbl_registration where reg_Activeflag = 1 " + "and reg_email = '" + txtusername.Text.Trim() + "' " + "and reg_password = '" + txtpassword.Text.Trim() + "'";
            DataSet ds = DM.GetDataSet(query);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Program.LoginMid = Convert.ToInt32(ds.Tables[0].Rows[0]["reg_Mid"]);
                MessageBox.Show("Login Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MDIParentCandidate frm = new MDIParentCandidate();
                frm.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtpassword.Clear();
                txtsum.Clear();

                FnGenerateCaptcha();
                txtpassword.Focus();
            }
        }

        private void FnGenerateCaptcha()
        {
            int n1 = rnd.Next(1, 9);
            int n2 = rnd.Next(1, 9);

            captchaAnswer = n1 + n2;

            lblnum1.Text = n1.ToString();
            lblnum2.Text = n2.ToString();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtusername.Clear();
            txtpassword.Clear();
            txtusername.Focus();

            FnGenerateCaptcha();
            txtusername.Focus();
        }

        private void FrmCandidateLogin_Load(object sender, EventArgs e)
        {
            txtusername.Focus();
            txtpassword.UseSystemPasswordChar = true;
            FnGenerateCaptcha();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            FrmCareerChoice frm = new FrmCareerChoice();
            frm.Show();
            this.Close();
        }

        private void lnkregister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmRegistration frm = new FrmRegistration();
            frm.Show();
            this.Close();
        }

        private void lblcaptcharefresh_Click(object sender, EventArgs e)
        {
            FnGenerateCaptcha();
            txtsum.Clear();
            txtsum.Focus();
        }
    }
}

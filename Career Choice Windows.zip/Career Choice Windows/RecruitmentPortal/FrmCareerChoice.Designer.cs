﻿namespace RecruitmentPortal
{
    partial class FrmCareerChoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.btncandiatelogin = new System.Windows.Forms.Button();
            this.btnadminlogin = new System.Windows.Forms.Button();
            this.lblheadning = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnexit);
            this.panel1.Controls.Add(this.btncandiatelogin);
            this.panel1.Controls.Add(this.btnadminlogin);
            this.panel1.Controls.Add(this.lblheadning);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 500);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(214, 438);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Version 1.0 | © 2026";
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnexit.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.ForeColor = System.Drawing.Color.Navy;
            this.btnexit.Location = new System.Drawing.Point(206, 330);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(180, 45);
            this.btnexit.TabIndex = 3;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btncandiatelogin
            // 
            this.btncandiatelogin.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btncandiatelogin.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncandiatelogin.ForeColor = System.Drawing.Color.Navy;
            this.btncandiatelogin.Location = new System.Drawing.Point(206, 242);
            this.btncandiatelogin.Name = "btncandiatelogin";
            this.btncandiatelogin.Size = new System.Drawing.Size(180, 45);
            this.btncandiatelogin.TabIndex = 2;
            this.btncandiatelogin.Text = "Candidate Login";
            this.btncandiatelogin.UseVisualStyleBackColor = false;
            this.btncandiatelogin.Click += new System.EventHandler(this.btncandiatelogin_Click);
            // 
            // btnadminlogin
            // 
            this.btnadminlogin.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnadminlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadminlogin.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminlogin.ForeColor = System.Drawing.Color.Navy;
            this.btnadminlogin.Location = new System.Drawing.Point(206, 152);
            this.btnadminlogin.Name = "btnadminlogin";
            this.btnadminlogin.Size = new System.Drawing.Size(180, 45);
            this.btnadminlogin.TabIndex = 1;
            this.btnadminlogin.Text = "Admin Login";
            this.btnadminlogin.UseVisualStyleBackColor = false;
            this.btnadminlogin.Click += new System.EventHandler(this.btnadminlogin_Click);
            // 
            // lblheadning
            // 
            this.lblheadning.AutoSize = true;
            this.lblheadning.BackColor = System.Drawing.Color.Transparent;
            this.lblheadning.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheadning.ForeColor = System.Drawing.Color.Navy;
            this.lblheadning.Location = new System.Drawing.Point(149, 9);
            this.lblheadning.Name = "lblheadning";
            this.lblheadning.Size = new System.Drawing.Size(268, 51);
            this.lblheadning.TabIndex = 0;
            this.lblheadning.Text = "Career Choice";
            // 
            // FrmCareerChoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 500);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Location = new System.Drawing.Point(30, 20);
            this.MaximizeBox = false;
            this.Name = "FrmCareerChoice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Career Choice";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblheadning;
        private System.Windows.Forms.Button btncandiatelogin;
        private System.Windows.Forms.Button btnadminlogin;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label label1;
    }
}
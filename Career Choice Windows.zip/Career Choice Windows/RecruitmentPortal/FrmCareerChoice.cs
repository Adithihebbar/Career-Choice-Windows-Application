﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmCareerChoice : Form
    {
        public FrmCareerChoice()
        {
            InitializeComponent();
        }

        private void btnadminlogin_Click(object sender, EventArgs e)
        {
            FrmAdminLogin frm = new FrmAdminLogin();
            frm.Show();
            this.Hide();
        }

        private void btncandiatelogin_Click(object sender, EventArgs e)
        {
            FrmCandidateLogin frm = new FrmCandidateLogin();
            frm.Show();
            this.Hide();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

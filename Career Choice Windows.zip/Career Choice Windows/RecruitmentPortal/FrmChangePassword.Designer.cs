﻿namespace RecruitmentPortal
{
    partial class FrmChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcurrentpassword = new System.Windows.Forms.Label();
            this.lblnewpassword = new System.Windows.Forms.Label();
            this.lblconfirmpassword = new System.Windows.Forms.Label();
            this.txtcurrentpaswrd = new System.Windows.Forms.TextBox();
            this.txtnewpaswrd = new System.Windows.Forms.TextBox();
            this.txtconfirmpaswrd = new System.Windows.Forms.TextBox();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.lblchange = new System.Windows.Forms.Label();
            this.pnlmain = new System.Windows.Forms.Panel();
            this.btnback = new System.Windows.Forms.Button();
            this.pnlmain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblcurrentpassword
            // 
            this.lblcurrentpassword.AutoSize = true;
            this.lblcurrentpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcurrentpassword.Location = new System.Drawing.Point(87, 117);
            this.lblcurrentpassword.Name = "lblcurrentpassword";
            this.lblcurrentpassword.Size = new System.Drawing.Size(172, 20);
            this.lblcurrentpassword.TabIndex = 0;
            this.lblcurrentpassword.Text = "Current Password :";
            // 
            // lblnewpassword
            // 
            this.lblnewpassword.AutoSize = true;
            this.lblnewpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnewpassword.Location = new System.Drawing.Point(114, 181);
            this.lblnewpassword.Name = "lblnewpassword";
            this.lblnewpassword.Size = new System.Drawing.Size(145, 20);
            this.lblnewpassword.TabIndex = 1;
            this.lblnewpassword.Text = "New Passowrd :";
            // 
            // lblconfirmpassword
            // 
            this.lblconfirmpassword.AutoSize = true;
            this.lblconfirmpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconfirmpassword.Location = new System.Drawing.Point(84, 245);
            this.lblconfirmpassword.Name = "lblconfirmpassword";
            this.lblconfirmpassword.Size = new System.Drawing.Size(175, 20);
            this.lblconfirmpassword.TabIndex = 2;
            this.lblconfirmpassword.Text = "Confirm Password :";
            // 
            // txtcurrentpaswrd
            // 
            this.txtcurrentpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcurrentpaswrd.Location = new System.Drawing.Point(311, 109);
            this.txtcurrentpaswrd.Name = "txtcurrentpaswrd";
            this.txtcurrentpaswrd.Size = new System.Drawing.Size(140, 28);
            this.txtcurrentpaswrd.TabIndex = 3;
            // 
            // txtnewpaswrd
            // 
            this.txtnewpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnewpaswrd.Location = new System.Drawing.Point(311, 177);
            this.txtnewpaswrd.Name = "txtnewpaswrd";
            this.txtnewpaswrd.Size = new System.Drawing.Size(140, 28);
            this.txtnewpaswrd.TabIndex = 4;
            // 
            // txtconfirmpaswrd
            // 
            this.txtconfirmpaswrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtconfirmpaswrd.Location = new System.Drawing.Point(311, 245);
            this.txtconfirmpaswrd.Name = "txtconfirmpaswrd";
            this.txtconfirmpaswrd.Size = new System.Drawing.Size(140, 28);
            this.txtconfirmpaswrd.TabIndex = 5;
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(161, 352);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(100, 40);
            this.btnupdate.TabIndex = 6;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnreset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreset.Location = new System.Drawing.Point(329, 352);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(100, 40);
            this.btnreset.TabIndex = 7;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // lblchange
            // 
            this.lblchange.AutoSize = true;
            this.lblchange.BackColor = System.Drawing.Color.Transparent;
            this.lblchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchange.Location = new System.Drawing.Point(189, 22);
            this.lblchange.Name = "lblchange";
            this.lblchange.Size = new System.Drawing.Size(261, 32);
            this.lblchange.TabIndex = 8;
            this.lblchange.Text = "Change Password";
            // 
            // pnlmain
            // 
            this.pnlmain.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlmain.Controls.Add(this.btnback);
            this.pnlmain.Controls.Add(this.lblchange);
            this.pnlmain.Controls.Add(this.btnreset);
            this.pnlmain.Controls.Add(this.btnupdate);
            this.pnlmain.Controls.Add(this.txtconfirmpaswrd);
            this.pnlmain.Controls.Add(this.txtnewpaswrd);
            this.pnlmain.Controls.Add(this.txtcurrentpaswrd);
            this.pnlmain.Controls.Add(this.lblconfirmpassword);
            this.pnlmain.Controls.Add(this.lblnewpassword);
            this.pnlmain.Controls.Add(this.lblcurrentpassword);
            this.pnlmain.Location = new System.Drawing.Point(114, 58);
            this.pnlmain.Name = "pnlmain";
            this.pnlmain.Size = new System.Drawing.Size(679, 438);
            this.pnlmain.TabIndex = 0;
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(542, 64);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(100, 40);
            this.btnback.TabIndex = 9;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // FrmChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1024, 768);
            this.ControlBox = false;
            this.Controls.Add(this.pnlmain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangePassword";
            this.Load += new System.EventHandler(this.FrmChangePassword_Load);
            this.pnlmain.ResumeLayout(false);
            this.pnlmain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblcurrentpassword;
        private System.Windows.Forms.Label lblnewpassword;
        private System.Windows.Forms.Label lblconfirmpassword;
        private System.Windows.Forms.TextBox txtcurrentpaswrd;
        private System.Windows.Forms.TextBox txtnewpaswrd;
        private System.Windows.Forms.TextBox txtconfirmpaswrd;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Label lblchange;
        private System.Windows.Forms.Panel pnlmain;
        private System.Windows.Forms.Button btnback;

    }
}
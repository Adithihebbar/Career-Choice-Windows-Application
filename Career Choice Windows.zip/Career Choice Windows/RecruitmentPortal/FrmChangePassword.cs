﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmChangePassword : Form
    {
        DataManager DM = new DataManager();

        public FrmChangePassword()
        {
            InitializeComponent();
        }
        private void CenterPanel()
        {
            pnlmain.Left = (this.ClientSize.Width - pnlmain.Width) / 2;
            pnlmain.Top = 40;
        }
        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtcurrentpaswrd.Text.Trim() == "")
            {
                MessageBox.Show("Enter Current Password");
                txtcurrentpaswrd.Focus();
                return;
            }
            if (txtnewpaswrd.Text.Trim() == "")
            {
                MessageBox.Show("Enter New Password");
                txtnewpaswrd.Focus();
                return;
            }

            if (txtconfirmpaswrd.Text.Trim() == "")
            {
                MessageBox.Show("Enter Confirm Password");
                txtconfirmpaswrd.Focus();
                return;
            }

            if (txtcurrentpaswrd.Text.Trim() == txtnewpaswrd.Text.Trim())
            {
                MessageBox.Show("New Password cannot be the same as Current Password");
                txtnewpaswrd.Clear();
                txtconfirmpaswrd.Clear();
                txtnewpaswrd.Focus();
                return;
            }

            if (txtnewpaswrd.Text.Trim() != txtconfirmpaswrd.Text.Trim())
            {
                MessageBox.Show("New Password and Confirm Password do not match");
                txtconfirmpaswrd.Clear();
                txtconfirmpaswrd.Focus();
                return;
            }

            string query = "select * from tbl_login " + "where login_Mid =" + Program.LoginMid + " and login_password = '" + txtcurrentpaswrd.Text.Trim() + "'" + " and login_Activeflag = 1";

            DataSet ds = DM.GetDataSet(query);

            if (ds.Tables[0].Rows.Count > 0)
            {
                string update = "update tbl_login set " + "login_password = '" + txtnewpaswrd.Text.Trim() + "'," + "login_ModifiedOn = GETDATE(), " + "login_ModifiedBy = " + Program.LoginMid + " where login_Mid = " + Program.LoginMid;

                DM.ExecuteSQLCommand(update, false);

                MessageBox.Show("Password Changed Successfully");

                FrmHomepageAdmin frm = new FrmHomepageAdmin();
                frm.MdiParent = this.MdiParent;
                frm.FormBorderStyle = FormBorderStyle.None;
                frm.WindowState = FormWindowState.Normal;
                frm.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Current Password Incorrect");
                txtcurrentpaswrd.Clear();
                txtcurrentpaswrd.Focus();
            }


        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtcurrentpaswrd.Clear();
            txtnewpaswrd.Clear();
            txtconfirmpaswrd.Clear();

            txtcurrentpaswrd.Focus();
        }

        private void FrmChangePassword_Load(object sender, EventArgs e)
        {
            txtcurrentpaswrd.UseSystemPasswordChar = true;
            txtnewpaswrd.UseSystemPasswordChar = true;
            txtconfirmpaswrd.UseSystemPasswordChar = true;

            CenterPanel();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            FrmHomepageAdmin frm = new FrmHomepageAdmin();
            frm.MdiParent = this.MdiParent;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.WindowState = FormWindowState.Normal;
            frm.Show();
            this.Close();
        }
    }
}

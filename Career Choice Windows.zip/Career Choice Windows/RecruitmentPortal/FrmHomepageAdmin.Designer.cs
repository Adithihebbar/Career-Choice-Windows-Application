﻿namespace RecruitmentPortal
{
    partial class FrmHomepageAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlmain = new System.Windows.Forms.Panel();
            this.lblheading = new System.Windows.Forms.Label();
            this.dgvgender = new System.Windows.Forms.DataGridView();
            this.colgender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coltotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvapplication = new System.Windows.Forms.DataGridView();
            this.colslnum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colapplication = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colcount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlActiveJobs = new System.Windows.Forms.Panel();
            this.lblActive = new System.Windows.Forms.Label();
            this.lblActiveJobs = new System.Windows.Forms.Label();
            this.pnlRejected = new System.Windows.Forms.Panel();
            this.lblReject = new System.Windows.Forms.Label();
            this.lblRejected = new System.Windows.Forms.Label();
            this.pnlPending = new System.Windows.Forms.Panel();
            this.lblPend = new System.Windows.Forms.Label();
            this.lblPending = new System.Windows.Forms.Label();
            this.pnlApproved = new System.Windows.Forms.Panel();
            this.lblApprove = new System.Windows.Forms.Label();
            this.lblApproved = new System.Windows.Forms.Label();
            this.pnlTotalapplications = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblTotalApplications = new System.Windows.Forms.Label();
            this.lblstat = new System.Windows.Forms.Label();
            this.pnlmain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvgender)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvapplication)).BeginInit();
            this.pnlActiveJobs.SuspendLayout();
            this.pnlRejected.SuspendLayout();
            this.pnlPending.SuspendLayout();
            this.pnlApproved.SuspendLayout();
            this.pnlTotalapplications.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlmain
            // 
            this.pnlmain.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlmain.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlmain.Controls.Add(this.lblheading);
            this.pnlmain.Controls.Add(this.dgvgender);
            this.pnlmain.Controls.Add(this.dgvapplication);
            this.pnlmain.Controls.Add(this.pnlActiveJobs);
            this.pnlmain.Controls.Add(this.pnlRejected);
            this.pnlmain.Controls.Add(this.pnlPending);
            this.pnlmain.Controls.Add(this.pnlApproved);
            this.pnlmain.Controls.Add(this.pnlTotalapplications);
            this.pnlmain.Controls.Add(this.lblstat);
            this.pnlmain.ForeColor = System.Drawing.Color.Black;
            this.pnlmain.Location = new System.Drawing.Point(0, 0);
            this.pnlmain.Name = "pnlmain";
            this.pnlmain.Size = new System.Drawing.Size(1024, 768);
            this.pnlmain.TabIndex = 1;
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.BackColor = System.Drawing.Color.Transparent;
            this.lblheading.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.Location = new System.Drawing.Point(388, 16);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(108, 38);
            this.lblheading.TabIndex = 18;
            this.lblheading.Text = "Home";
            // 
            // dgvgender
            // 
            this.dgvgender.AllowUserToAddRows = false;
            this.dgvgender.AllowUserToDeleteRows = false;
            this.dgvgender.AllowUserToResizeColumns = false;
            this.dgvgender.AllowUserToResizeRows = false;
            this.dgvgender.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvgender.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvgender.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dgvgender.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvgender.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colgender,
            this.coltotal});
            this.dgvgender.Location = new System.Drawing.Point(535, 441);
            this.dgvgender.Name = "dgvgender";
            this.dgvgender.RowHeadersVisible = false;
            this.dgvgender.RowTemplate.Height = 24;
            this.dgvgender.Size = new System.Drawing.Size(293, 148);
            this.dgvgender.TabIndex = 17;
            // 
            // colgender
            // 
            this.colgender.DataPropertyName = "Gender";
            this.colgender.HeaderText = "Gender";
            this.colgender.Name = "colgender";
            this.colgender.ReadOnly = true;
            // 
            // coltotal
            // 
            this.coltotal.DataPropertyName = "Count";
            this.coltotal.HeaderText = "Total";
            this.coltotal.Name = "coltotal";
            this.coltotal.ReadOnly = true;
            // 
            // dgvapplication
            // 
            this.dgvapplication.AllowUserToAddRows = false;
            this.dgvapplication.AllowUserToDeleteRows = false;
            this.dgvapplication.AllowUserToResizeColumns = false;
            this.dgvapplication.AllowUserToResizeRows = false;
            this.dgvapplication.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvapplication.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvapplication.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dgvapplication.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvapplication.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colslnum,
            this.colapplication,
            this.colcount});
            this.dgvapplication.Location = new System.Drawing.Point(105, 441);
            this.dgvapplication.Name = "dgvapplication";
            this.dgvapplication.RowHeadersVisible = false;
            this.dgvapplication.RowTemplate.Height = 24;
            this.dgvapplication.Size = new System.Drawing.Size(342, 296);
            this.dgvapplication.TabIndex = 16;
            // 
            // colslnum
            // 
            this.colslnum.HeaderText = "SL No";
            this.colslnum.Name = "colslnum";
            this.colslnum.ReadOnly = true;
            this.colslnum.Visible = false;
            // 
            // colapplication
            // 
            this.colapplication.DataPropertyName = "Application";
            this.colapplication.HeaderText = "Applications";
            this.colapplication.Name = "colapplication";
            this.colapplication.ReadOnly = true;
            // 
            // colcount
            // 
            this.colcount.DataPropertyName = "Count";
            this.colcount.HeaderText = "Count";
            this.colcount.Name = "colcount";
            this.colcount.ReadOnly = true;
            // 
            // pnlActiveJobs
            // 
            this.pnlActiveJobs.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlActiveJobs.Controls.Add(this.lblActive);
            this.pnlActiveJobs.Controls.Add(this.lblActiveJobs);
            this.pnlActiveJobs.Location = new System.Drawing.Point(530, 301);
            this.pnlActiveJobs.Name = "pnlActiveJobs";
            this.pnlActiveJobs.Size = new System.Drawing.Size(214, 100);
            this.pnlActiveJobs.TabIndex = 15;
            // 
            // lblActive
            // 
            this.lblActive.AutoSize = true;
            this.lblActive.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActive.Location = new System.Drawing.Point(50, 17);
            this.lblActive.Name = "lblActive";
            this.lblActive.Size = new System.Drawing.Size(107, 20);
            this.lblActive.TabIndex = 5;
            this.lblActive.Text = "Active Jobs";
            // 
            // lblActiveJobs
            // 
            this.lblActiveJobs.AutoSize = true;
            this.lblActiveJobs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActiveJobs.Location = new System.Drawing.Point(90, 50);
            this.lblActiveJobs.Name = "lblActiveJobs";
            this.lblActiveJobs.Size = new System.Drawing.Size(24, 25);
            this.lblActiveJobs.TabIndex = 10;
            this.lblActiveJobs.Text = "0";
            // 
            // pnlRejected
            // 
            this.pnlRejected.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlRejected.Controls.Add(this.lblReject);
            this.pnlRejected.Controls.Add(this.lblRejected);
            this.pnlRejected.Location = new System.Drawing.Point(661, 149);
            this.pnlRejected.Name = "pnlRejected";
            this.pnlRejected.Size = new System.Drawing.Size(214, 100);
            this.pnlRejected.TabIndex = 14;
            // 
            // lblReject
            // 
            this.lblReject.AutoSize = true;
            this.lblReject.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReject.Location = new System.Drawing.Point(60, 11);
            this.lblReject.Name = "lblReject";
            this.lblReject.Size = new System.Drawing.Size(83, 20);
            this.lblReject.TabIndex = 3;
            this.lblReject.Text = "Rejected";
            // 
            // lblRejected
            // 
            this.lblRejected.AutoSize = true;
            this.lblRejected.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRejected.Location = new System.Drawing.Point(99, 48);
            this.lblRejected.Name = "lblRejected";
            this.lblRejected.Size = new System.Drawing.Size(24, 25);
            this.lblRejected.TabIndex = 8;
            this.lblRejected.Text = "0";
            // 
            // pnlPending
            // 
            this.pnlPending.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlPending.Controls.Add(this.lblPend);
            this.pnlPending.Controls.Add(this.lblPending);
            this.pnlPending.Location = new System.Drawing.Point(195, 301);
            this.pnlPending.Name = "pnlPending";
            this.pnlPending.Size = new System.Drawing.Size(214, 100);
            this.pnlPending.TabIndex = 13;
            // 
            // lblPend
            // 
            this.lblPend.AutoSize = true;
            this.lblPend.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPend.Location = new System.Drawing.Point(60, 17);
            this.lblPend.Name = "lblPend";
            this.lblPend.Size = new System.Drawing.Size(76, 20);
            this.lblPend.TabIndex = 4;
            this.lblPend.Text = "Pending";
            // 
            // lblPending
            // 
            this.lblPending.AutoSize = true;
            this.lblPending.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPending.Location = new System.Drawing.Point(88, 50);
            this.lblPending.Name = "lblPending";
            this.lblPending.Size = new System.Drawing.Size(24, 25);
            this.lblPending.TabIndex = 9;
            this.lblPending.Text = "0";
            // 
            // pnlApproved
            // 
            this.pnlApproved.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlApproved.Controls.Add(this.lblApprove);
            this.pnlApproved.Controls.Add(this.lblApproved);
            this.pnlApproved.Location = new System.Drawing.Point(351, 149);
            this.pnlApproved.Name = "pnlApproved";
            this.pnlApproved.Size = new System.Drawing.Size(214, 100);
            this.pnlApproved.TabIndex = 12;
            // 
            // lblApprove
            // 
            this.lblApprove.AutoSize = true;
            this.lblApprove.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApprove.Location = new System.Drawing.Point(58, 11);
            this.lblApprove.Name = "lblApprove";
            this.lblApprove.Size = new System.Drawing.Size(87, 20);
            this.lblApprove.TabIndex = 2;
            this.lblApprove.Text = "Approved";
            // 
            // lblApproved
            // 
            this.lblApproved.AutoSize = true;
            this.lblApproved.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApproved.Location = new System.Drawing.Point(89, 48);
            this.lblApproved.Name = "lblApproved";
            this.lblApproved.Size = new System.Drawing.Size(24, 25);
            this.lblApproved.TabIndex = 7;
            this.lblApproved.Text = "0";
            // 
            // pnlTotalapplications
            // 
            this.pnlTotalapplications.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlTotalapplications.Controls.Add(this.lblTotal);
            this.pnlTotalapplications.Controls.Add(this.lblTotalApplications);
            this.pnlTotalapplications.Location = new System.Drawing.Point(41, 149);
            this.pnlTotalapplications.Name = "pnlTotalapplications";
            this.pnlTotalapplications.Size = new System.Drawing.Size(214, 100);
            this.pnlTotalapplications.TabIndex = 11;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(25, 17);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(160, 20);
            this.lblTotal.TabIndex = 1;
            this.lblTotal.Text = "Total Applications";
            // 
            // lblTotalApplications
            // 
            this.lblTotalApplications.AutoSize = true;
            this.lblTotalApplications.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalApplications.Location = new System.Drawing.Point(87, 48);
            this.lblTotalApplications.Name = "lblTotalApplications";
            this.lblTotalApplications.Size = new System.Drawing.Size(24, 25);
            this.lblTotalApplications.TabIndex = 6;
            this.lblTotalApplications.Text = "0";
            // 
            // lblstat
            // 
            this.lblstat.AutoSize = true;
            this.lblstat.BackColor = System.Drawing.Color.Transparent;
            this.lblstat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstat.Location = new System.Drawing.Point(378, 93);
            this.lblstat.Name = "lblstat";
            this.lblstat.Size = new System.Drawing.Size(118, 29);
            this.lblstat.TabIndex = 0;
            this.lblstat.Text = "Statistics";
            // 
            // FrmHomepageAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1786, 829);
            this.ControlBox = false;
            this.Controls.Add(this.pnlmain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmHomepageAdmin";
            this.Text = "FrmHomepageAdmin";
            this.Load += new System.EventHandler(this.FrmHomepageAdmin_Load);
            this.pnlmain.ResumeLayout(false);
            this.pnlmain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvgender)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvapplication)).EndInit();
            this.pnlActiveJobs.ResumeLayout(false);
            this.pnlActiveJobs.PerformLayout();
            this.pnlRejected.ResumeLayout(false);
            this.pnlRejected.PerformLayout();
            this.pnlPending.ResumeLayout(false);
            this.pnlPending.PerformLayout();
            this.pnlApproved.ResumeLayout(false);
            this.pnlApproved.PerformLayout();
            this.pnlTotalapplications.ResumeLayout(false);
            this.pnlTotalapplications.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlmain;
        private System.Windows.Forms.Panel pnlActiveJobs;
        private System.Windows.Forms.Label lblActive;
        private System.Windows.Forms.Label lblActiveJobs;
        private System.Windows.Forms.Panel pnlRejected;
        private System.Windows.Forms.Label lblReject;
        private System.Windows.Forms.Label lblRejected;
        private System.Windows.Forms.Panel pnlPending;
        private System.Windows.Forms.Label lblPend;
        private System.Windows.Forms.Label lblPending;
        private System.Windows.Forms.Panel pnlApproved;
        private System.Windows.Forms.Label lblApprove;
        private System.Windows.Forms.Label lblApproved;
        private System.Windows.Forms.Panel pnlTotalapplications;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblTotalApplications;
        private System.Windows.Forms.DataGridView dgvgender;
        private System.Windows.Forms.DataGridView dgvapplication;
        private System.Windows.Forms.DataGridViewTextBoxColumn colgender;
        private System.Windows.Forms.DataGridViewTextBoxColumn coltotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colslnum;
        private System.Windows.Forms.DataGridViewTextBoxColumn colapplication;
        private System.Windows.Forms.DataGridViewTextBoxColumn colcount;
        private System.Windows.Forms.Label lblstat;
        private System.Windows.Forms.Label lblheading;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmHomepageAdmin : Form
    {
        DataManager DM = new DataManager();
        public FrmHomepageAdmin()
        {
            InitializeComponent();
        }

        private void FrmHomepageAdmin_Load(object sender, EventArgs e)
        {
            this.AutoScroll = true;

            LoadStatistics();
            BindGenderGrid();
            BindJobApplicationGrid();

            CenterPanel();
        }

        //private void FrmHomepageAdmin_Resize(object sender, EventArgs e)
        //{
        //    CenterPanel();
        //}

        private void CenterPanel()
        {
            pnlmain.Left = (this.ClientSize.Width - pnlmain.Width) / 2;
            pnlmain.Top = 20;
        }

        private void LoadStatistics()
        {
            try
            {
                DataSet ds;

                ds = DM.GetDataSet("select count(*) as total from tbl_application where apply_Activeflag = 1");
                lblTotalApplications.Text = ds.Tables[0].Rows[0]["Total"].ToString();

                ds = DM.GetDataSet("select count(*) as total from tbl_application where apply_status = 'Approved' and apply_Activeflag = 1");
                lblApproved.Text = ds.Tables[0].Rows[0]["Total"].ToString();

                ds = DM.GetDataSet("select count(*) as total from tbl_application where apply_status = 'Rejected' and apply_Activeflag = 1");
                lblRejected.Text = ds.Tables[0].Rows[0]["Total"].ToString();

                ds = DM.GetDataSet("select count(*) as total from tbl_application where apply_status='Pending' and apply_Activeflag = 1");
                lblPending.Text = ds.Tables[0].Rows[0]["Total"].ToString();

                ds = DM.GetDataSet("select count(*) as total from tbl_jobs where job_Activeflag = 1");
                lblActiveJobs.Text = ds.Tables[0].Rows[0]["Total"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BindGenderGrid()
        {
            try
            {
                string sql = @"SELECT
        apply_gender AS Gender,
        COUNT(*) AS Count
        FROM tbl_application
        WHERE apply_Activeflag = 1
        GROUP BY apply_gender
        ORDER BY apply_gender";

                DataSet ds = DM.GetDataSet(sql);

                dgvgender.AutoGenerateColumns = false;
                dgvgender.DataSource = ds.Tables[0];

                dgvgender.ClearSelection();
                dgvgender.CurrentCell = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BindJobApplicationGrid()
        {
            try
            {
                string sql = @"SELECT
        apply_jobpost AS Application,
        COUNT(*) AS Count
        FROM tbl_application
        WHERE apply_Activeflag = 1
        GROUP BY apply_jobpost
        ORDER BY COUNT(*) DESC";

                DataSet ds = DM.GetDataSet(sql);

                dgvapplication.AutoGenerateColumns = false;
                dgvapplication.DataSource = ds.Tables[0];

                dgvapplication.ClearSelection();
                dgvapplication.CurrentCell = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
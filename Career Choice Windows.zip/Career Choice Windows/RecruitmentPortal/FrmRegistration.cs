﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmRegistration : Form
    {
        DataManager DM = new DataManager();
        Random rnd = new Random();
        int captchaAnswer;

        public FrmRegistration()
        {
            InitializeComponent();

            // Candidate must be at least 18 years old
            dtpdob.MaxDate = DateTime.Today.AddYears(-18);

            // Center the registration form
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void FrmRegistration_Load(object sender, EventArgs e)
        {
            FnGenerateCaptcha();

            txtpassword.UseSystemPasswordChar = true;
            txtconfirmpassword.UseSystemPasswordChar = true;
        }
        private void FnGenerateCaptcha()
        {

            int n1 = rnd.Next(1, 9);
            int n2 = rnd.Next(1, 9);

            captchaAnswer = n1 + n2;

            lblnum1.Text = n1.ToString();
            lblnum2.Text = n2.ToString();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            if (txtname.Text.Trim() == "")
            {
                MessageBox.Show("Enter Name");
                txtname.Focus();
                return;
            }
            if (txtemail.Text.Trim() == "")
            {
                MessageBox.Show("Enter EmailId");
                txtemail.Focus();
                return;
            }
            if (txtmobilenumber.Text.Trim() == "")
            {
                MessageBox.Show("Enter Mobile Number");
                txtmobilenumber.Focus();
                return;
            }

            if (txtaddress.Text.Trim() == "")
            {
                MessageBox.Show("Enter Address");
                txtaddress.Focus();
                return;
            }
            if (txtpassword.Text.Trim() == "")
            {
                MessageBox.Show("Enter Password");
                txtpassword.Focus();
                return;
            }
            if (txtconfirmpassword.Text.Trim() == "")
            {
                MessageBox.Show("Enter Confirm Password");
                txtconfirmpassword.Focus();
                return;
            }
            if (txtpassword.Text.Trim() != txtconfirmpassword.Text.Trim())
            {
                MessageBox.Show("Password and confirm password do not match");
                txtconfirmpassword.Focus();
                return;
            }
            if (!txtemail.Text.Contains("@"))
            {
                MessageBox.Show("Enter Valid Email");
                txtemail.Focus();
                return;
            }
            if (txtmobilenumber.Text.Length != 10 || !txtmobilenumber.Text.All(char.IsDigit))
            {
                MessageBox.Show("Enter Valid Mobile Number");
                txtmobilenumber.Focus();
                return;
            }
            if (txtsum.Text.Trim() != captchaAnswer.ToString())
            {
                MessageBox.Show("Invalid Captcha");

                FnGenerateCaptcha();
                txtsum.Clear();
                txtsum.Focus();
                return;
            }
            DataSet ds = DM.GetDataSet(
        "SELECT * FROM tbl_registration WHERE reg_email='" + txtemail.Text.Trim() +
        "' OR reg_mobile='" + txtmobilenumber.Text.Trim() + "'");

            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["reg_email"].ToString().Trim() == txtemail.Text.Trim())
                {
                    MessageBox.Show("Email already exists");
                    txtemail.Focus();
                }
                else if (ds.Tables[0].Rows[0]["reg_mobile"].ToString().Trim() == txtmobilenumber.Text.Trim())
                {
                    MessageBox.Show("Mobile Number already exists");
                    txtmobilenumber.Focus();
                }
                txtsum.Clear();
                FnGenerateCaptcha();
                return;
            }
            string query = "INSERT INTO tbl_registration " +
                 "(reg_name,reg_email,reg_mobile,reg_dob,reg_address,reg_password," +
                 "reg_Activeflag,reg_CreatedOn,reg_CreatedBy," +
                 "reg_extra1,reg_extra2,reg_extra3,reg_extra4,reg_extra5) VALUES(" +
                 "'" + txtname.Text.Trim() + "'," +
                 "'" + txtemail.Text.Trim() + "'," +
                 "'" + txtmobilenumber.Text.Trim() + "'," +
                 "'" + dtpdob.Value.ToString("yyyy-MM-dd") + "'," +
                 "'" + txtaddress.Text.Trim() + "'," +
                 "'" + txtpassword.Text.Trim() + "'," +
                 "1," +
                 "GETDATE()," +
                 "0," +
                 "'','','','','')";


            string result = (DM.ExecuteSQLCommand(query, false));
            if (result == "")
            {
                MessageBox.Show("Registration Successful");

                FrmCandidateLogin frm = new FrmCandidateLogin();
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show(result);
                // MessageBox.Show("Registration Failed");

                txtpassword.Clear();
                txtconfirmpassword.Clear();
                txtsum.Clear();
                FnGenerateCaptcha();
                txtpassword.Focus();
            }

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtname.Clear();
            txtemail.Clear();
            dtpdob.Value = DateTime.Today;
            txtmobilenumber.Clear();
            txtaddress.Clear();
            txtpassword.Clear();
            txtconfirmpassword.Clear();
            txtsum.Clear();

            FnGenerateCaptcha();
            txtname.Focus();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            FrmCandidateLogin obj = new FrmCandidateLogin();
            obj.Show();
            this.Hide();
        }

        private void lblrefresh_Click(object sender, EventArgs e)
        {
            FnGenerateCaptcha();
            txtsum.Clear();
            txtsum.Focus();
        }
    }
}

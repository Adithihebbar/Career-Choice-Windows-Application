﻿namespace RecruitmentPortal
{
    partial class FrmViewApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvApplication = new System.Windows.Forms.DataGridView();
            this.apply_Mid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colslno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coledit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ColApprove = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ColReject = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ColView = new System.Windows.Forms.DataGridViewButtonColumn();
            this.apply_jobpost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_jobcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_reference_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_mobile_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_dob = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_nationality = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_marital_status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_gender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_min_qualification = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apply_total_experience = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.cmbjobpost = new System.Windows.Forms.ComboBox();
            this.lbljobpost = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblmobile = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.txtreference = new System.Windows.Forms.TextBox();
            this.lblreference = new System.Windows.Forms.Label();
            this.pnlview = new System.Windows.Forms.Panel();
            this.lblview = new System.Windows.Forms.Label();
            this.pnlmain = new System.Windows.Forms.Panel();
            this.pnlViewApplication = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.lblreceipt = new System.Windows.Forms.Label();
            this.lblresume1 = new System.Windows.Forms.Label();
            this.lblTotalExperience = new System.Windows.Forms.Label();
            this.lblExperiencetype = new System.Windows.Forms.Label();
            this.lblQualify = new System.Windows.Forms.Label();
            this.lblMaritalstatus = new System.Windows.Forms.Label();
            this.lblGender1 = new System.Windows.Forms.Label();
            this.lblNationality = new System.Windows.Forms.Label();
            this.lblDateob = new System.Windows.Forms.Label();
            this.lblIdEmail = new System.Windows.Forms.Label();
            this.lblMobilenumber = new System.Windows.Forms.Label();
            this.lblRefNumber = new System.Windows.Forms.Label();
            this.lblCandidatename = new System.Windows.Forms.Label();
            this.lblJobtitle = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picbphoto = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvApplication)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlview.SuspendLayout();
            this.pnlmain.SuspendLayout();
            this.pnlViewApplication.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbphoto)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvApplication
            // 
            this.dgvApplication.AllowUserToAddRows = false;
            this.dgvApplication.AllowUserToDeleteRows = false;
            this.dgvApplication.AllowUserToResizeColumns = false;
            this.dgvApplication.AllowUserToResizeRows = false;
            this.dgvApplication.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvApplication.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvApplication.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvApplication.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvApplication.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.apply_Mid,
            this.colslno,
            this.coledit,
            this.ColApprove,
            this.ColReject,
            this.ColView,
            this.apply_jobpost,
            this.apply_jobcode,
            this.apply_reference_no,
            this.apply_name,
            this.apply_mobile_no,
            this.apply_dob,
            this.apply_nationality,
            this.apply_email,
            this.apply_marital_status,
            this.apply_gender,
            this.apply_min_qualification,
            this.Status,
            this.apply_total_experience,
            this.ColDelete});
            this.dgvApplication.Location = new System.Drawing.Point(15, 324);
            this.dgvApplication.Name = "dgvApplication";
            this.dgvApplication.RowHeadersVisible = false;
            this.dgvApplication.RowTemplate.Height = 24;
            this.dgvApplication.Size = new System.Drawing.Size(1237, 348);
            this.dgvApplication.TabIndex = 1;
            this.dgvApplication.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvApplication_CellContentClick);
            this.dgvApplication.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvApplication_RowPostPaint);
            // 
            // apply_Mid
            // 
            this.apply_Mid.DataPropertyName = "apply_Mid";
            this.apply_Mid.HeaderText = "regMid";
            this.apply_Mid.Name = "apply_Mid";
            this.apply_Mid.ReadOnly = true;
            this.apply_Mid.Visible = false;
            // 
            // colslno
            // 
            this.colslno.HeaderText = "Sl.No";
            this.colslno.Name = "colslno";
            this.colslno.ReadOnly = true;
            // 
            // coledit
            // 
            this.coledit.HeaderText = "Edit";
            this.coledit.Name = "coledit";
            this.coledit.ReadOnly = true;
            this.coledit.Text = "Edit";
            this.coledit.UseColumnTextForButtonValue = true;
            this.coledit.Visible = false;
            // 
            // ColApprove
            // 
            this.ColApprove.HeaderText = "Approve";
            this.ColApprove.Name = "ColApprove";
            this.ColApprove.ReadOnly = true;
            this.ColApprove.Text = "Approve";
            this.ColApprove.UseColumnTextForButtonValue = true;
            // 
            // ColReject
            // 
            this.ColReject.HeaderText = "Reject";
            this.ColReject.Name = "ColReject";
            this.ColReject.ReadOnly = true;
            this.ColReject.Text = "Reject";
            this.ColReject.UseColumnTextForButtonValue = true;
            // 
            // ColView
            // 
            this.ColView.HeaderText = "View";
            this.ColView.Name = "ColView";
            this.ColView.ReadOnly = true;
            this.ColView.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColView.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColView.Text = "View";
            this.ColView.UseColumnTextForButtonValue = true;
            // 
            // apply_jobpost
            // 
            this.apply_jobpost.DataPropertyName = "apply_jobpost";
            this.apply_jobpost.HeaderText = "Job Post";
            this.apply_jobpost.Name = "apply_jobpost";
            this.apply_jobpost.ReadOnly = true;
            // 
            // apply_jobcode
            // 
            this.apply_jobcode.DataPropertyName = "apply_jobcode";
            this.apply_jobcode.HeaderText = "Job Code";
            this.apply_jobcode.Name = "apply_jobcode";
            this.apply_jobcode.ReadOnly = true;
            // 
            // apply_reference_no
            // 
            this.apply_reference_no.DataPropertyName = "apply_reference_no";
            this.apply_reference_no.HeaderText = "Reference Number";
            this.apply_reference_no.Name = "apply_reference_no";
            this.apply_reference_no.ReadOnly = true;
            // 
            // apply_name
            // 
            this.apply_name.DataPropertyName = "apply_name";
            this.apply_name.HeaderText = "Name";
            this.apply_name.Name = "apply_name";
            this.apply_name.ReadOnly = true;
            // 
            // apply_mobile_no
            // 
            this.apply_mobile_no.DataPropertyName = "apply_mobile_no";
            this.apply_mobile_no.HeaderText = "Mobile Number";
            this.apply_mobile_no.Name = "apply_mobile_no";
            this.apply_mobile_no.ReadOnly = true;
            // 
            // apply_dob
            // 
            this.apply_dob.DataPropertyName = "apply_dob";
            this.apply_dob.HeaderText = "Date of Birth";
            this.apply_dob.Name = "apply_dob";
            this.apply_dob.ReadOnly = true;
            this.apply_dob.Visible = false;
            // 
            // apply_nationality
            // 
            this.apply_nationality.DataPropertyName = "apply_nationality";
            this.apply_nationality.HeaderText = "Nationality";
            this.apply_nationality.Name = "apply_nationality";
            this.apply_nationality.ReadOnly = true;
            this.apply_nationality.Visible = false;
            // 
            // apply_email
            // 
            this.apply_email.DataPropertyName = "apply_email";
            this.apply_email.HeaderText = "Email";
            this.apply_email.Name = "apply_email";
            this.apply_email.ReadOnly = true;
            // 
            // apply_marital_status
            // 
            this.apply_marital_status.DataPropertyName = "apply_marital_status";
            this.apply_marital_status.HeaderText = "Marital";
            this.apply_marital_status.Name = "apply_marital_status";
            this.apply_marital_status.ReadOnly = true;
            this.apply_marital_status.Visible = false;
            // 
            // apply_gender
            // 
            this.apply_gender.DataPropertyName = "apply_gender";
            this.apply_gender.HeaderText = "Gender";
            this.apply_gender.Name = "apply_gender";
            this.apply_gender.ReadOnly = true;
            this.apply_gender.Visible = false;
            // 
            // apply_min_qualification
            // 
            this.apply_min_qualification.DataPropertyName = "apply_min_qualification";
            this.apply_min_qualification.HeaderText = "Minimum qualification";
            this.apply_min_qualification.Name = "apply_min_qualification";
            this.apply_min_qualification.ReadOnly = true;
            this.apply_min_qualification.Visible = false;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "apply_status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // apply_total_experience
            // 
            this.apply_total_experience.DataPropertyName = "apply_total_experience";
            this.apply_total_experience.HeaderText = "Experience";
            this.apply_total_experience.Name = "apply_total_experience";
            this.apply_total_experience.ReadOnly = true;
            this.apply_total_experience.Visible = false;
            // 
            // ColDelete
            // 
            this.ColDelete.HeaderText = "Delete";
            this.ColDelete.Name = "ColDelete";
            this.ColDelete.ReadOnly = true;
            this.ColDelete.Text = "Delete";
            this.ColDelete.UseColumnTextForButtonValue = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.dtpToDate);
            this.panel1.Controls.Add(this.dtpFromDate);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.btnsearch);
            this.panel1.Controls.Add(this.btnrefresh);
            this.panel1.Controls.Add(this.cmbjobpost);
            this.panel1.Controls.Add(this.lbljobpost);
            this.panel1.Controls.Add(this.txtemail);
            this.panel1.Controls.Add(this.txtmobile);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.lblemail);
            this.panel1.Controls.Add(this.lblmobile);
            this.panel1.Controls.Add(this.lblname);
            this.panel1.Controls.Add(this.txtreference);
            this.panel1.Controls.Add(this.lblreference);
            this.panel1.Location = new System.Drawing.Point(40, 82);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1173, 218);
            this.panel1.TabIndex = 2;
            // 
            // dtpToDate
            // 
            this.dtpToDate.CustomFormat = "dd-MM-yyyy";
            this.dtpToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpToDate.Location = new System.Drawing.Point(152, 170);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(141, 27);
            this.dtpToDate.TabIndex = 15;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.CustomFormat = "dd-MM-yyyy";
            this.dtpFromDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(926, 103);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(141, 27);
            this.dtpFromDate.TabIndex = 14;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(33, 175);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(88, 20);
            this.label17.TabIndex = 13;
            this.label17.Text = "To Date :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(791, 106);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 20);
            this.label16.TabIndex = 12;
            this.label16.Text = "From Date :";
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(629, 162);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(100, 40);
            this.btnsearch.TabIndex = 11;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.Location = new System.Drawing.Point(782, 162);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(100, 40);
            this.btnrefresh.TabIndex = 10;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // cmbjobpost
            // 
            this.cmbjobpost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbjobpost.FormattingEnabled = true;
            this.cmbjobpost.Location = new System.Drawing.Point(555, 102);
            this.cmbjobpost.Name = "cmbjobpost";
            this.cmbjobpost.Size = new System.Drawing.Size(153, 28);
            this.cmbjobpost.TabIndex = 9;
            // 
            // lbljobpost
            // 
            this.lbljobpost.AutoSize = true;
            this.lbljobpost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbljobpost.Location = new System.Drawing.Point(447, 106);
            this.lbljobpost.Name = "lbljobpost";
            this.lbljobpost.Size = new System.Drawing.Size(95, 20);
            this.lbljobpost.TabIndex = 8;
            this.lbljobpost.Text = "Job Post :";
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(177, 103);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(153, 27);
            this.txtemail.TabIndex = 7;
            // 
            // txtmobile
            // 
            this.txtmobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.Location = new System.Drawing.Point(1005, 22);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(153, 27);
            this.txtmobile.TabIndex = 6;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(593, 26);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(153, 27);
            this.txtname.TabIndex = 5;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(33, 106);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(89, 20);
            this.lblemail.TabIndex = 4;
            this.lblemail.Text = "Email Id :";
            // 
            // lblmobile
            // 
            this.lblmobile.AutoSize = true;
            this.lblmobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmobile.Location = new System.Drawing.Point(840, 29);
            this.lblmobile.Name = "lblmobile";
            this.lblmobile.Size = new System.Drawing.Size(147, 20);
            this.lblmobile.TabIndex = 3;
            this.lblmobile.Text = "Mobile Number :";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(419, 29);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(159, 20);
            this.lblname.TabIndex = 2;
            this.lblname.Text = "Candidate Name :";
            // 
            // txtreference
            // 
            this.txtreference.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreference.Location = new System.Drawing.Point(177, 22);
            this.txtreference.Name = "txtreference";
            this.txtreference.Size = new System.Drawing.Size(153, 27);
            this.txtreference.TabIndex = 1;
            // 
            // lblreference
            // 
            this.lblreference.AutoSize = true;
            this.lblreference.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreference.Location = new System.Drawing.Point(14, 25);
            this.lblreference.Name = "lblreference";
            this.lblreference.Size = new System.Drawing.Size(136, 20);
            this.lblreference.TabIndex = 0;
            this.lblreference.Text = "Reference No :";
            // 
            // pnlview
            // 
            this.pnlview.Controls.Add(this.lblview);
            this.pnlview.Controls.Add(this.panel1);
            this.pnlview.Controls.Add(this.dgvApplication);
            this.pnlview.Location = new System.Drawing.Point(45, 3);
            this.pnlview.Name = "pnlview";
            this.pnlview.Size = new System.Drawing.Size(1289, 755);
            this.pnlview.TabIndex = 12;
            // 
            // lblview
            // 
            this.lblview.AutoSize = true;
            this.lblview.BackColor = System.Drawing.Color.Transparent;
            this.lblview.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblview.Location = new System.Drawing.Point(435, 20);
            this.lblview.Name = "lblview";
            this.lblview.Size = new System.Drawing.Size(242, 32);
            this.lblview.TabIndex = 3;
            this.lblview.Text = "VIew Application";
            // 
            // pnlmain
            // 
            this.pnlmain.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlmain.Controls.Add(this.pnlViewApplication);
            this.pnlmain.Controls.Add(this.pnlview);
            this.pnlmain.Location = new System.Drawing.Point(0, 0);
            this.pnlmain.Name = "pnlmain";
            this.pnlmain.Size = new System.Drawing.Size(1300, 755);
            this.pnlmain.TabIndex = 13;
            // 
            // pnlViewApplication
            // 
            this.pnlViewApplication.Controls.Add(this.picbphoto);
            this.pnlViewApplication.Controls.Add(this.btnBack);
            this.pnlViewApplication.Controls.Add(this.label15);
            this.pnlViewApplication.Controls.Add(this.lblreceipt);
            this.pnlViewApplication.Controls.Add(this.lblresume1);
            this.pnlViewApplication.Controls.Add(this.lblTotalExperience);
            this.pnlViewApplication.Controls.Add(this.lblExperiencetype);
            this.pnlViewApplication.Controls.Add(this.lblQualify);
            this.pnlViewApplication.Controls.Add(this.lblMaritalstatus);
            this.pnlViewApplication.Controls.Add(this.lblGender1);
            this.pnlViewApplication.Controls.Add(this.lblNationality);
            this.pnlViewApplication.Controls.Add(this.lblDateob);
            this.pnlViewApplication.Controls.Add(this.lblIdEmail);
            this.pnlViewApplication.Controls.Add(this.lblMobilenumber);
            this.pnlViewApplication.Controls.Add(this.lblRefNumber);
            this.pnlViewApplication.Controls.Add(this.lblCandidatename);
            this.pnlViewApplication.Controls.Add(this.lblJobtitle);
            this.pnlViewApplication.Controls.Add(this.label14);
            this.pnlViewApplication.Controls.Add(this.label13);
            this.pnlViewApplication.Controls.Add(this.label12);
            this.pnlViewApplication.Controls.Add(this.label11);
            this.pnlViewApplication.Controls.Add(this.label10);
            this.pnlViewApplication.Controls.Add(this.label9);
            this.pnlViewApplication.Controls.Add(this.label8);
            this.pnlViewApplication.Controls.Add(this.label7);
            this.pnlViewApplication.Controls.Add(this.label6);
            this.pnlViewApplication.Controls.Add(this.label5);
            this.pnlViewApplication.Controls.Add(this.label4);
            this.pnlViewApplication.Controls.Add(this.label3);
            this.pnlViewApplication.Controls.Add(this.label2);
            this.pnlViewApplication.Controls.Add(this.label1);
            this.pnlViewApplication.Location = new System.Drawing.Point(100, 0);
            this.pnlViewApplication.Name = "pnlViewApplication";
            this.pnlViewApplication.Size = new System.Drawing.Size(952, 755);
            this.pnlViewApplication.TabIndex = 4;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(847, 87);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 40);
            this.btnBack.TabIndex = 29;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(374, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(242, 32);
            this.label15.TabIndex = 28;
            this.label15.Text = "View Application";
            // 
            // lblreceipt
            // 
            this.lblreceipt.AutoSize = true;
            this.lblreceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreceipt.Location = new System.Drawing.Point(540, 638);
            this.lblreceipt.Name = "lblreceipt";
            this.lblreceipt.Size = new System.Drawing.Size(167, 20);
            this.lblreceipt.TabIndex = 27;
            this.lblreceipt.Text = "Download Receipt ";
            this.lblreceipt.Click += new System.EventHandler(this.lblreceipt_Click);
            // 
            // lblresume1
            // 
            this.lblresume1.AutoSize = true;
            this.lblresume1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresume1.Location = new System.Drawing.Point(540, 601);
            this.lblresume1.Name = "lblresume1";
            this.lblresume1.Size = new System.Drawing.Size(171, 20);
            this.lblresume1.TabIndex = 26;
            this.lblresume1.Text = "Download Resume ";
            this.lblresume1.Click += new System.EventHandler(this.lblresume1_Click);
            // 
            // lblTotalExperience
            // 
            this.lblTotalExperience.AutoSize = true;
            this.lblTotalExperience.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalExperience.Location = new System.Drawing.Point(540, 564);
            this.lblTotalExperience.Name = "lblTotalExperience";
            this.lblTotalExperience.Size = new System.Drawing.Size(156, 20);
            this.lblTotalExperience.TabIndex = 25;
            this.lblTotalExperience.Text = "Total Experience ";
            // 
            // lblExperiencetype
            // 
            this.lblExperiencetype.AutoSize = true;
            this.lblExperiencetype.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExperiencetype.Location = new System.Drawing.Point(540, 527);
            this.lblExperiencetype.Name = "lblExperiencetype";
            this.lblExperiencetype.Size = new System.Drawing.Size(154, 20);
            this.lblExperiencetype.TabIndex = 24;
            this.lblExperiencetype.Text = "Experience Type ";
            // 
            // lblQualify
            // 
            this.lblQualify.AutoSize = true;
            this.lblQualify.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQualify.Location = new System.Drawing.Point(540, 490);
            this.lblQualify.Name = "lblQualify";
            this.lblQualify.Size = new System.Drawing.Size(121, 20);
            this.lblQualify.TabIndex = 23;
            this.lblQualify.Text = "Qualification ";
            // 
            // lblMaritalstatus
            // 
            this.lblMaritalstatus.AutoSize = true;
            this.lblMaritalstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaritalstatus.Location = new System.Drawing.Point(540, 453);
            this.lblMaritalstatus.Name = "lblMaritalstatus";
            this.lblMaritalstatus.Size = new System.Drawing.Size(133, 20);
            this.lblMaritalstatus.TabIndex = 22;
            this.lblMaritalstatus.Text = "Marital Status ";
            // 
            // lblGender1
            // 
            this.lblGender1.AutoSize = true;
            this.lblGender1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender1.Location = new System.Drawing.Point(540, 416);
            this.lblGender1.Name = "lblGender1";
            this.lblGender1.Size = new System.Drawing.Size(76, 20);
            this.lblGender1.TabIndex = 21;
            this.lblGender1.Text = "Gender ";
            // 
            // lblNationality
            // 
            this.lblNationality.AutoSize = true;
            this.lblNationality.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNationality.Location = new System.Drawing.Point(540, 379);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.Size = new System.Drawing.Size(104, 20);
            this.lblNationality.TabIndex = 20;
            this.lblNationality.Text = "Nationality ";
            // 
            // lblDateob
            // 
            this.lblDateob.AutoSize = true;
            this.lblDateob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateob.Location = new System.Drawing.Point(540, 342);
            this.lblDateob.Name = "lblDateob";
            this.lblDateob.Size = new System.Drawing.Size(124, 20);
            this.lblDateob.TabIndex = 19;
            this.lblDateob.Text = "Date of Birth ";
            // 
            // lblIdEmail
            // 
            this.lblIdEmail.AutoSize = true;
            this.lblIdEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdEmail.Location = new System.Drawing.Point(540, 305);
            this.lblIdEmail.Name = "lblIdEmail";
            this.lblIdEmail.Size = new System.Drawing.Size(62, 20);
            this.lblIdEmail.TabIndex = 18;
            this.lblIdEmail.Text = "Email ";
            // 
            // lblMobilenumber
            // 
            this.lblMobilenumber.AutoSize = true;
            this.lblMobilenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobilenumber.Location = new System.Drawing.Point(540, 268);
            this.lblMobilenumber.Name = "lblMobilenumber";
            this.lblMobilenumber.Size = new System.Drawing.Size(141, 20);
            this.lblMobilenumber.TabIndex = 17;
            this.lblMobilenumber.Text = "Mobile Number ";
            // 
            // lblRefNumber
            // 
            this.lblRefNumber.AutoSize = true;
            this.lblRefNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRefNumber.Location = new System.Drawing.Point(540, 231);
            this.lblRefNumber.Name = "lblRefNumber";
            this.lblRefNumber.Size = new System.Drawing.Size(172, 20);
            this.lblRefNumber.TabIndex = 16;
            this.lblRefNumber.Text = "Reference Number ";
            // 
            // lblCandidatename
            // 
            this.lblCandidatename.AutoSize = true;
            this.lblCandidatename.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCandidatename.Location = new System.Drawing.Point(540, 194);
            this.lblCandidatename.Name = "lblCandidatename";
            this.lblCandidatename.Size = new System.Drawing.Size(153, 20);
            this.lblCandidatename.TabIndex = 15;
            this.lblCandidatename.Text = "Candidate Name ";
            // 
            // lblJobtitle
            // 
            this.lblJobtitle.AutoSize = true;
            this.lblJobtitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobtitle.Location = new System.Drawing.Point(540, 157);
            this.lblJobtitle.Name = "lblJobtitle";
            this.lblJobtitle.Size = new System.Drawing.Size(89, 20);
            this.lblJobtitle.TabIndex = 14;
            this.lblJobtitle.Text = "Job Post ";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(297, 605);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(210, 24);
            this.label14.TabIndex = 13;
            this.label14.Text = "Resume :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(297, 568);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(210, 24);
            this.label13.TabIndex = 12;
            this.label13.Text = "Total Experience :";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(297, 638);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(210, 24);
            this.label12.TabIndex = 11;
            this.label12.Text = "Receipt :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(297, 529);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(210, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Experience Type :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(297, 494);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(210, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "Qualification :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(297, 457);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(210, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Marital Status :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(297, 416);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(210, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "Gender :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(297, 383);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Nationality :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(297, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(210, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "Date of Birth :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(297, 309);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Email :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(297, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(210, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mobile Number :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(297, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Reference Number :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(297, 191);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Candidate Name :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(297, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Job Post :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // picbphoto
            // 
            this.picbphoto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picbphoto.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.picbphoto.Location = new System.Drawing.Point(93, 115);
            this.picbphoto.Name = "picbphoto";
            this.picbphoto.Size = new System.Drawing.Size(123, 140);
            this.picbphoto.TabIndex = 32;
            this.picbphoto.TabStop = false;
            // 
            // FrmViewApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1468, 768);
            this.ControlBox = false;
            this.Controls.Add(this.pnlmain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmViewApplication";
            this.Text = "AdminHome";
            this.Load += new System.EventHandler(this.FrmAdminhome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvApplication)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlview.ResumeLayout(false);
            this.pnlview.PerformLayout();
            this.pnlmain.ResumeLayout(false);
            this.pnlViewApplication.ResumeLayout(false);
            this.pnlViewApplication.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbphoto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvApplication;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblmobile;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtreference;
        private System.Windows.Forms.Label lblreference;
        private System.Windows.Forms.ComboBox cmbjobpost;
        private System.Windows.Forms.Label lbljobpost;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Panel pnlview;
        private System.Windows.Forms.Label lblview;
        private System.Windows.Forms.Panel pnlmain;
        private System.Windows.Forms.Panel pnlViewApplication;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblreceipt;
        private System.Windows.Forms.Label lblresume1;
        private System.Windows.Forms.Label lblTotalExperience;
        private System.Windows.Forms.Label lblExperiencetype;
        private System.Windows.Forms.Label lblQualify;
        private System.Windows.Forms.Label lblMaritalstatus;
        private System.Windows.Forms.Label lblGender1;
        private System.Windows.Forms.Label lblNationality;
        private System.Windows.Forms.Label lblDateob;
        private System.Windows.Forms.Label lblIdEmail;
        private System.Windows.Forms.Label lblMobilenumber;
        private System.Windows.Forms.Label lblRefNumber;
        private System.Windows.Forms.Label lblCandidatename;
        private System.Windows.Forms.Label lblJobtitle;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_Mid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colslno;
        private System.Windows.Forms.DataGridViewButtonColumn coledit;
        private System.Windows.Forms.DataGridViewButtonColumn ColApprove;
        private System.Windows.Forms.DataGridViewButtonColumn ColReject;
        private System.Windows.Forms.DataGridViewButtonColumn ColView;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_jobpost;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_jobcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_reference_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_mobile_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_dob;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_nationality;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_email;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_marital_status;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_gender;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_min_qualification;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn apply_total_experience;
        private System.Windows.Forms.DataGridViewButtonColumn ColDelete;
        private System.Windows.Forms.PictureBox picbphoto;
    }
}
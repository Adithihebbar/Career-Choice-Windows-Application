﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace RecruitmentPortal
{
    public partial class FrmViewApplication : Form
    {
        string webRootPath = @"C:\Users\Adithi\OneDrive\Desktop\A1 logics\RecruitmentPortal";   // ASP.NET project path
        string winRootPath = Application.StartupPath;

        DataManager DM = new DataManager();
        ClsApplication objApplication = new ClsApplication();
        string ResumePath = "";
        string ReceiptPath = "";
        public FrmViewApplication()
        {
            InitializeComponent();
        }
        private void FrmAdminhome_Load(object sender, EventArgs e)
        {
            dgvApplication.AllowUserToAddRows = false;
            BindJobPost();
            BindGrid(false);
            dgvApplication.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
           // CenterPanel();
            ShowPanel(pnlview);
        }

        private void CenterPanel()
        {
            pnlmain.Left = (this.ClientSize.Width - pnlmain.Width) / 2;
            pnlmain.Top = 40;
        }

        private void ShowPanel(Panel pnl)
        {
            pnlview.Visible = false;
            pnlViewApplication.Visible = false;

            pnl.Visible = true;
        }

        private void BindGrid(bool applyDateFilter = true)
        {
            string qry = "SELECT apply_Mid,apply_status, apply_jobpost, apply_jobcode, apply_reference_no, apply_name, apply_mobile_no, apply_dob, apply_nationality, apply_email, apply_marital_status, apply_gender, apply_min_qualification, apply_total_experience FROM tbl_application WHERE apply_Activeflag = 1";

            if (txtreference.Text.Trim() != "")
                qry += " AND apply_reference_no LIKE '%" + txtreference.Text.Trim() + "%'";

            if (txtname.Text.Trim() != "")
                qry += " AND apply_name LIKE '%" + txtname.Text.Trim() + "%'";

            if (txtmobile.Text.Trim() != "")
                qry += " AND apply_mobile_no LIKE '%" + txtmobile.Text.Trim() + "%'";

            if (txtemail.Text.Trim() != "")
                qry += " AND apply_email LIKE '%" + txtemail.Text.Trim() + "%'";

            if (cmbjobpost.SelectedIndex > 0)
                qry += " AND apply_jobpost = '" + cmbjobpost.Text + "'";

            if (applyDateFilter)
            {
                if (dtpFromDate.Value.Date > dtpToDate.Value.Date)
                {
                    MessageBox.Show("From Date cannot be greater than To Date");
                    return;
                }

                qry += " AND apply_CreatedOn >= '" +
                       dtpFromDate.Value.ToString("yyyy-MM-dd") + "'";

                qry += " AND apply_CreatedOn < '" +
                       dtpToDate.Value.AddDays(1).ToString("yyyy-MM-dd") + "'";
            }
            try
            {
                DataSet ds = DM.GetDataSet(qry);

                if (ds != null && ds.Tables.Count > 0)
                {
                    dgvApplication.AutoGenerateColumns = false;
                    dgvApplication.DataSource = ds.Tables[0];

                    for (int i = 0; i < dgvApplication.Rows.Count; i++)
                    {
                        dgvApplication.Rows[i].Cells["colslno"].Value = i + 1;
                    }

                    dgvApplication.Columns["Status"].HeaderText = "Status";
                }
                else
                {
                  //  dgvApplication.DataSource = ds.Tables[0];
                    dgvApplication.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BindJobPost()
        {
            string qry = "SELECT job_Mid, job_title FROM tbl_jobs WHERE job_Activeflag = 1";

            DataSet ds = DM.GetDataSet(qry);

            DataRow dr = ds.Tables[0].NewRow();
            dr["job_Mid"] = 0;
            dr["job_title"] = "--ALL--";
            ds.Tables[0].Rows.InsertAt(dr, 0);

            cmbjobpost.DataSource = ds.Tables[0];
            cmbjobpost.DisplayMember = "job_title";
            cmbjobpost.ValueMember = "job_Mid";
            cmbjobpost.SelectedIndex = 0;
        }

        private void dgvApplication_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            if (dgvApplication.Columns[e.ColumnIndex].Name == "coledit")
            {
                int applyMid = Convert.ToInt32(
                    dgvApplication.Rows[e.RowIndex].Cells["apply_Mid"].Value);

                MessageBox.Show(applyMid.ToString());
            }
            if (dgvApplication.Columns[e.ColumnIndex].Name == "ColView")
            {
                int applyMid = Convert.ToInt32(dgvApplication.Rows[e.RowIndex].Cells["apply_Mid"].Value);
                pnlview.Visible = false;
                pnlViewApplication.Visible = true;
                LoadApplication(applyMid);
            }

            if (dgvApplication.Columns[e.ColumnIndex].Name == "ColApprove")
            {
                int applyMid = Convert.ToInt32(dgvApplication.Rows[e.RowIndex].Cells["apply_Mid"].Value);

                DialogResult dr = MessageBox.Show(
                    "Approve this application?",
                    "Confirmation",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    string status = dgvApplication.Rows[e.RowIndex].Cells["Status"].Value.ToString();

                    if (status == "Approved")
                    {
                        MessageBox.Show("Application is already approved.");
                        return;
                    }
                    else if (status == "Rejected")
                    {
                        MessageBox.Show("This application has already been rejected.");
                        return;
                    }

                    int result = objApplication.ApplicationTransaction(
        6,
        applyMid,
        0,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "Approved",
        0,
        "",
        "",
        "",
        "",
        ""
    );

                    if (result > 0)
                    {
                        MessageBox.Show("Application Approved Successfully.");
                        BindGrid();
                    }
                    else
                    {
                        MessageBox.Show("Approve Failed");
                    }
                }
            }
            if (dgvApplication.Columns[e.ColumnIndex].Name == "ColReject")
            {
                int applyMid = Convert.ToInt32(dgvApplication.Rows[e.RowIndex].Cells["apply_Mid"].Value);

                DialogResult dr = MessageBox.Show(
                    "Reject this application?",
                    "Confirmation",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    string status = dgvApplication.Rows[e.RowIndex].Cells["Status"].Value.ToString();

                    if (status == "Rejected")
                    {
                        MessageBox.Show("Application is already rejected.");
                        return;
                    }
                    else if (status == "Approved")
                    {
                        MessageBox.Show("This application has already been approved.");
                        return;
                    }

                    int result = objApplication.ApplicationTransaction(
    6,                  // Update Status
    applyMid,
    0,                  // apply_regMid
    "",                 // apply_jobcode
    "",                 // apply_jobpost
    "",                 // apply_reference_no
    "",                 // apply_name
    "",                 // apply_mobile_no
    "",                 // apply_email
    "",                 // apply_dob
    "",                 // apply_nationality
    "",                 // apply_marital_status
    "",                 // apply_gender
    "",                 // apply_min_qualification
    "",                 // apply_experience_type
    "",                 // apply_total_experience
    "",                 // apply_resume
    "",                 // apply_photo
    "",                 // apply_payment_receipt
    "Rejected",         // apply_status
    0,                  // UserId
    "",                 // apply_extra1
    "",                 // apply_extra2
    "",                 // apply_extra3
    "",                 // apply_extra4
    ""                  // apply_extra5
);

                    if (result > 0)
                    {
                        MessageBox.Show("Application Rejected Successfully.");
                        BindGrid();
                    }
                    else
                    {
                        MessageBox.Show("Reject Failed");
                    }
                }
            }
            if (dgvApplication.Columns[e.ColumnIndex].Name == "ColDelete")
            {
                int applyMid = Convert.ToInt32(dgvApplication.Rows[e.RowIndex].Cells["apply_Mid"].Value);

                DialogResult dr = MessageBox.Show(
                    "Are you sure you want to delete this application?",
                    "Delete Confirmation",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (dr == DialogResult.Yes)
                {
                    string qry = "UPDATE tbl_application SET apply_Activeflag = 0 WHERE apply_Mid = " + applyMid;

                    string result = DM.ExecuteSQLCommand(qry, false);

                    if (result == "")
                    {
                        MessageBox.Show("Application Deleted Successfully.");
                        BindGrid();
                    }
                    else
                    {
                        MessageBox.Show(result);
                    }
                }
            }
        }

        private void LoadApplication(int applyMid)
        {
            string qry = "select * from tbl_application where apply_Mid = " + applyMid;
            DataSet ds = DM.GetDataSet(qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];

                lblJobtitle.Text = dr["apply_jobpost"].ToString();
                lblCandidatename.Text = dr["apply_name"].ToString();
                lblRefNumber.Text = dr["apply_reference_no"].ToString();
                lblMobilenumber.Text = dr["apply_mobile_no"].ToString();
                lblMobilenumber.Text = dr["apply_email"].ToString();
                lblDateob.Text = Convert.ToDateTime(dr["apply_dob"]).ToString("dd-MM-yyyy");
                lblNationality.Text = dr["apply_nationality"].ToString();
                lblGender1.Text = dr["apply_gender"].ToString();
                lblMaritalstatus.Text = dr["apply_marital_status"].ToString();
                lblQualify.Text = dr["apply_min_qualification"].ToString();
                lblExperiencetype.Text = dr["apply_experience_type"].ToString();
                lblTotalExperience.Text = dr["apply_total_experience"].ToString();
                ResumePath = dr["apply_resume"].ToString();
                ReceiptPath = dr["apply_payment_receipt"].ToString();
                //MessageBox.Show(ReceiptPath);
                string dbPhotoPath = dr["apply_photo"].ToString();
                string localPath = EnsurePhotoInWinForms(dbPhotoPath);
                if (!string.IsNullOrEmpty(localPath) && File.Exists(localPath))
                {
                    picbphoto.ImageLocation = localPath;
                    picbphoto.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                else
                {
                    picbphoto.Image = null;
                }
            }
        }

        private string EnsurePhotoInWinForms(string dbPhotoPath)
        {
            if (string.IsNullOrWhiteSpace(dbPhotoPath))
                return "";

            // If it's already a physical path, use it directly.
            if (Path.IsPathRooted(dbPhotoPath))
            {
                return File.Exists(dbPhotoPath) ? dbPhotoPath : "";
            }

            // Otherwise it's a virtual path like ~/Reg_Photo/abc.jpg
            string relativePath = dbPhotoPath.Replace("~/", "").Replace("/", "\\");

            string webFullPath = Path.Combine(webRootPath, relativePath);

            string winFullPath = Path.Combine(winRootPath, relativePath);

            string folder = Path.GetDirectoryName(winFullPath);

            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);

            if (File.Exists(webFullPath))
            {
                if (!File.Exists(winFullPath))
                {
                    File.Copy(webFullPath, winFullPath);
                }

                return winFullPath;
            }

            return "";
        }

        private void dgvApplication_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            dgvApplication.Rows[e.RowIndex].Cells["colslno"].Value = (e.RowIndex + 1).ToString();
            dgvApplication.AllowUserToAddRows = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            txtreference.Clear();
            txtname.Clear();
            txtmobile.Clear();
            txtemail.Clear();

            cmbjobpost.SelectedIndex = 0;
            dtpFromDate.Value = DateTime.Today;
            dtpToDate.Value = DateTime.Today;
            BindGrid(false);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            pnlViewApplication.Visible = false;
            pnlview.Visible = true;
            BindGrid();
        }

        private void lblresume1_Click(object sender, EventArgs e)
        {
            string relativePath = ResumePath.Replace("~/", "").Replace("/", "\\");
            string webFullPath = Path.Combine(webRootPath, relativePath);

            if (File.Exists(webFullPath))
            {
                System.Diagnostics.Process.Start(webFullPath);
            }
            else
            {
                MessageBox.Show("Resume not found");
            }
        }
        private void lblreceipt_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ReceiptPath))
            {
                MessageBox.Show("No receipt uploaded.");
                return;
            }

            string relativePath = ReceiptPath.Replace("~/", "").Replace("/", "\\");
            string webFullPath = Path.Combine(webRootPath, relativePath);

            if (File.Exists(webFullPath))
            {
                System.Diagnostics.Process.Start(webFullPath);
            }
            else
            {
                MessageBox.Show("Receipt not found.");
            }
        }

        private void pnlViewApplication_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

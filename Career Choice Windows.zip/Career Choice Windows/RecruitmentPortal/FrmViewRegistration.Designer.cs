﻿namespace RecruitmentPortal
{
    partial class FrmViewRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlViewRegistration = new System.Windows.Forms.Panel();
            this.dgvRegistration = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.colslno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regmid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactinfo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colpassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coladdress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colregdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlViewRegistration.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegistration)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlViewRegistration
            // 
            this.pnlViewRegistration.Controls.Add(this.dgvRegistration);
            this.pnlViewRegistration.Controls.Add(this.panel1);
            this.pnlViewRegistration.Controls.Add(this.label1);
            this.pnlViewRegistration.Location = new System.Drawing.Point(92, 3);
            this.pnlViewRegistration.Name = "pnlViewRegistration";
            this.pnlViewRegistration.Size = new System.Drawing.Size(1300, 706);
            this.pnlViewRegistration.TabIndex = 0;
            // 
            // dgvRegistration
            // 
            this.dgvRegistration.AllowUserToAddRows = false;
            this.dgvRegistration.AllowUserToDeleteRows = false;
            this.dgvRegistration.AllowUserToResizeColumns = false;
            this.dgvRegistration.AllowUserToResizeRows = false;
            this.dgvRegistration.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvRegistration.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRegistration.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colslno,
            this.regmid,
            this.colname,
            this.contactinfo,
            this.colpassword,
            this.coladdress,
            this.colregdate});
            this.dgvRegistration.Location = new System.Drawing.Point(42, 379);
            this.dgvRegistration.Name = "dgvRegistration";
            this.dgvRegistration.RowHeadersVisible = false;
            this.dgvRegistration.RowTemplate.Height = 24;
            this.dgvRegistration.Size = new System.Drawing.Size(1173, 265);
            this.dgvRegistration.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.btnrefresh);
            this.panel1.Controls.Add(this.btnsearch);
            this.panel1.Controls.Add(this.txtaddress);
            this.panel1.Controls.Add(this.txtmobile);
            this.panel1.Controls.Add(this.txtemail);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(42, 114);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1173, 201);
            this.panel1.TabIndex = 1;
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.Location = new System.Drawing.Point(612, 110);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(100, 40);
            this.btnrefresh.TabIndex = 9;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(435, 111);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(100, 40);
            this.btnsearch.TabIndex = 8;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txtaddress
            // 
            this.txtaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress.Location = new System.Drawing.Point(157, 108);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(153, 27);
            this.txtaddress.TabIndex = 7;
            // 
            // txtmobile
            // 
            this.txtmobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.Location = new System.Drawing.Point(920, 22);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(153, 27);
            this.txtmobile.TabIndex = 6;
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(540, 22);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(153, 27);
            this.txtemail.TabIndex = 5;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(157, 22);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(153, 27);
            this.txtname.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(45, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Address :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(784, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Mobile No :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(427, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Email Id :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(66, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(467, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "View Registration";
            // 
            // colslno
            // 
            this.colslno.HeaderText = "SlNo";
            this.colslno.Name = "colslno";
            this.colslno.ReadOnly = true;
            // 
            // regmid
            // 
            this.regmid.DataPropertyName = "reg_Mid";
            this.regmid.HeaderText = "MId";
            this.regmid.Name = "regmid";
            this.regmid.ReadOnly = true;
            this.regmid.Visible = false;
            // 
            // colname
            // 
            this.colname.DataPropertyName = "reg_name";
            this.colname.HeaderText = "Name";
            this.colname.Name = "colname";
            this.colname.ReadOnly = true;
            // 
            // contactinfo
            // 
            this.contactinfo.HeaderText = "Contact Info";
            this.contactinfo.Name = "contactinfo";
            this.contactinfo.ReadOnly = true;
            // 
            // colpassword
            // 
            this.colpassword.DataPropertyName = "reg_password";
            this.colpassword.HeaderText = "Password";
            this.colpassword.Name = "colpassword";
            this.colpassword.ReadOnly = true;
            // 
            // coladdress
            // 
            this.coladdress.DataPropertyName = "reg_address";
            this.coladdress.HeaderText = "Address";
            this.coladdress.Name = "coladdress";
            this.coladdress.ReadOnly = true;
            // 
            // colregdate
            // 
            this.colregdate.DataPropertyName = "reg_CreatedOn";
            this.colregdate.HeaderText = "Regestered Date";
            this.colregdate.Name = "colregdate";
            this.colregdate.ReadOnly = true;
            // 
            // FrmViewRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1450, 721);
            this.ControlBox = false;
            this.Controls.Add(this.pnlViewRegistration);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmViewRegistration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Registration";
            this.Load += new System.EventHandler(this.FrmViewRegistration_Load);
            this.pnlViewRegistration.ResumeLayout(false);
            this.pnlViewRegistration.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegistration)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlViewRegistration;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvRegistration;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn colslno;
        private System.Windows.Forms.DataGridViewTextBoxColumn regmid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colname;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactinfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colpassword;
        private System.Windows.Forms.DataGridViewTextBoxColumn coladdress;
        private System.Windows.Forms.DataGridViewTextBoxColumn colregdate;
    }
}
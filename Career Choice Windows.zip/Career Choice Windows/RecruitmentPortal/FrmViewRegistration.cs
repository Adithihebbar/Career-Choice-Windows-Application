﻿////using System;
////using System.Collections.Generic;
////using System.ComponentModel;
////using System.Data;
////using System.Drawing;
////using System.Linq;
////using System.Text;
////using System.Windows.Forms;

////namespace RecruitmentPortal
////{
////    public partial class FrmViewRegistration : Form
////    {
////        DataManager DM = new DataManager();

////        public FrmViewRegistration()
////        {
////            InitializeComponent();
////             dgvRegistration.RowPostPaint +=
////        dgvRegistration_RowPostPaint;
////        }

////        private void FrmViewRegistration_Load(object sender, EventArgs e)
////        {
////            dgvRegistration.AllowUserToAddRows = false;
////            dgvRegistration.AutoGenerateColumns = false;

////            dgvRegistration.AutoSizeColumnsMode =
////                DataGridViewAutoSizeColumnsMode.Fill;

////            // Registered Date
////            dgvRegistration.Columns["colregdate"]
////                .DefaultCellStyle.Format = "dd-MM-yyyy";

////            // Contact Info
////            dgvRegistration.Columns["contactinfo"]
////                .DefaultCellStyle.WrapMode =
////                DataGridViewTriState.True;

////            dgvRegistration.AutoSizeRowsMode =
////                DataGridViewAutoSizeRowsMode.AllCells;

////          //  BindGrid();
////        }
////        private void FrmViewRegistration_Shown(object sender, EventArgs e)
////{
////    BindGrid();
////}
////        private void BindGrid()
////        {
////            string qry = "SELECT " +
////             "ROW_NUMBER() OVER (ORDER BY reg_Mid DESC) AS SlNo, " +
////             "reg_Mid, " +
////             "reg_name, " +
////             "reg_email, " +
////             "reg_mobile, " +
////             "reg_password, " +
////             "reg_address, " +
////             "reg_CreatedOn, " +
////             "reg_email + CHAR(13) + CHAR(10) + reg_mobile AS ContactInfo " +
////             "FROM tbl_registration " +
////             "WHERE reg_Activeflag = 1";
////            //string qry = "SELECT reg_Mid, reg_name, reg_email, reg_mobile, " +
////            //             "reg_password, reg_address, reg_CreatedOn " +
////            //             "FROM tbl_registration " +
////            //             "WHERE reg_Activeflag = 1";

////            if (txtname.Text.Trim() != "")
////            {
////                qry += " AND reg_name LIKE '%" +
////                       txtname.Text.Trim() + "%'";
////            }

////            if (txtemail.Text.Trim() != "")
////            {
////                qry += " AND reg_email LIKE '%" +
////                       txtemail.Text.Trim() + "%'";
////            }

////            if (txtmobile.Text.Trim() != "")
////            {
////                qry += " AND reg_mobile LIKE '%" +
////                       txtmobile.Text.Trim() + "%'";
////            }

////            if (txtaddress.Text.Trim() != "")
////            {
////                qry += " AND reg_address LIKE '%" +
////                       txtaddress.Text.Trim() + "%'";
////            }

////            qry += " ORDER BY reg_Mid DESC";

////            try
////            {
////                DataSet ds = DM.GetDataSet(qry);

////                if (ds != null && ds.Tables.Count > 0)
////                {
////                    dgvRegistration.AutoGenerateColumns = false;

////                    dgvRegistration.DataSource = ds.Tables[0];

////                    // Sl No
////                    //for (int i = 0; i < dgvRegistration.Rows.Count; i++)
////                    //{
////                    //    dgvRegistration.Rows[i]
////                    //        .Cells["colslno"].Value = (i + 1).ToString();
////                    //}

////                    //MessageBox.Show(
////                    //    "Sl No = " +
////                    //    dgvRegistration.Rows[0].Cells["colslno"].Value);


////                    //// Contact Info
////                    //for (int i = 0; i < dgvRegistration.Rows.Count; i++)
////                    //{
////                    //    string email = ds.Tables[0]
////                    //        .Rows[i]["reg_email"].ToString();

////                    //    string mobile = ds.Tables[0]
////                    //        .Rows[i]["reg_mobile"].ToString();

////                    //    dgvRegistration.Rows[i]
////                    //        .Cells["contactinfo"].Value =
////                    //        email + Environment.NewLine + mobile;
////                    //}

////    //                MessageBox.Show(
////    //                    "Contact = " +
////    //                    dgvRegistration.Rows[0].Cells["contactinfo"].Value);
////    //                MessageBox.Show(
////    //"Rows: " + dgvRegistration.Rows.Count +
////    //"\nSlNo: " + dgvRegistration.Rows[0].Cells["colslno"].Value +
////    //"\nContact: " + dgvRegistration.Rows[0].Cells["contactinfo"].Value);
////                }
////                else
////                {
////                    dgvRegistration.DataSource = null;
////                }
////            }
////            catch (Exception ex)
////            {
////                MessageBox.Show(ex.Message);
////            }
////        }
     
////        private void btnsearch_Click(object sender, EventArgs e)
////        {
////            BindGrid();
////        }

////        // -------------------------
////        // Refresh Button
////        // -------------------------
////        private void btnrefresh_Click(object sender, EventArgs e)
////        {
////            txtname.Clear();
////            txtemail.Clear();
////            txtmobile.Clear();
////            txtaddress.Clear();

////            BindGrid();
////        }

////        // -------------------------
////        // Sl No
////        // -------------------------
////        private void dgvRegistration_RowPostPaint(
////    object sender,
////    DataGridViewRowPostPaintEventArgs e)
////{
////    dgvRegistration.Rows[e.RowIndex]
////        .Cells["colslno"].Value = (e.RowIndex + 1).ToString();

////    DataRowView row =
////        dgvRegistration.Rows[e.RowIndex].DataBoundItem as DataRowView;

////    if (row != null)
////    {
////        dgvRegistration.Rows[e.RowIndex]
////            .Cells["contactinfo"].Value =
////            row["reg_email"].ToString() +
////            Environment.NewLine +
////            row["reg_mobile"].ToString();
////    }
////}

////        // -------------------------
////        // Resend Email
////        // -------------------------
////        private void dgvRegistration_CellContentClick(
////            object sender,
////            DataGridViewCellEventArgs e)
////        {
////        //    if (e.RowIndex < 0)
////        //        return;

////        //    if (dgvRegistration.Columns[e.ColumnIndex].Name
////        //        == "ResendEmail")
////        //    {
////        //        DataRowView row =
////        //            dgvRegistration.Rows[e.RowIndex]
////        //            .DataBoundItem as DataRowView;

////        //        if (row == null)
////        //            return;

////        //        string email =
////        //            row["reg_email"].ToString();

////        //        if (string.IsNullOrWhiteSpace(email))
////        //        {
////        //            MessageBox.Show(
////        //                "Email address not found.");
////        //            return;
////        //        }

////        //        MessageBox.Show(
////        //            "Resend email to:\n" + email);

////        //        // Email sending code will go here
////         }
////        }
////    }
////}
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Windows.Forms;

//namespace RecruitmentPortal
//{
//    public partial class FrmViewRegistration : Form
//    {
//        DataManager DM = new DataManager();

//        public FrmViewRegistration()
//        {
//            InitializeComponent();
//        }

//        private void FrmViewRegistration_Load(object sender, EventArgs e)
//        {
//            dgvRegistration.AllowUserToAddRows = false;
//            dgvRegistration.AutoGenerateColumns = false;

//            dgvRegistration.AutoSizeColumnsMode =
//                DataGridViewAutoSizeColumnsMode.Fill;

//            // Registered Date
//            dgvRegistration.Columns["colregdate"]
//                .DefaultCellStyle.Format = "dd-MM-yyyy";

//            // Contact Info
//            dgvRegistration.Columns["contactinfo"]
//                .DefaultCellStyle.WrapMode =
//                DataGridViewTriState.True;

//            dgvRegistration.AutoSizeRowsMode =
//                DataGridViewAutoSizeRowsMode.AllCells;

//            BindGrid();
//        }

//        private void BindGrid()
//        {
//            string qry = "SELECT " +
//                         "ROW_NUMBER() OVER (ORDER BY reg_Mid DESC) AS SlNo, " +
//                         "reg_Mid, " +
//                         "reg_name, " +
//                         "reg_email, " +
//                         "reg_mobile, " +
//                         "reg_password, " +
//                         "reg_address, " +
//                         "reg_CreatedOn, " +
//                         "reg_email + CHAR(13) + CHAR(10) + reg_mobile AS ContactInfo " +
//                         "FROM tbl_registration " +
//                         "WHERE reg_Activeflag = 1";

//            if (txtname.Text.Trim() != "")
//            {
//                qry += " AND reg_name LIKE '%" +
//                       txtname.Text.Trim() + "%'";
//            }

//            if (txtemail.Text.Trim() != "")
//            {
//                qry += " AND reg_email LIKE '%" +
//                       txtemail.Text.Trim() + "%'";
//            }

//            if (txtmobile.Text.Trim() != "")
//            {
//                qry += " AND reg_mobile LIKE '%" +
//                       txtmobile.Text.Trim() + "%'";
//            }

//            if (txtaddress.Text.Trim() != "")
//            {
//                qry += " AND reg_address LIKE '%" +
//                       txtaddress.Text.Trim() + "%'";
//            }

//            qry += " ORDER BY reg_Mid DESC";

//            try
//            {
//                DataSet ds = DM.GetDataSet(qry);

//                if (ds != null && ds.Tables.Count > 0)
//                {
//                    dgvRegistration.DataSource = null;

//                    dgvRegistration.AutoGenerateColumns = false;

//                    dgvRegistration.DataSource = ds.Tables[0];
//                }
//                else
//                {
//                    dgvRegistration.DataSource = null;
//                }
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show(ex.Message);
//            }
//        }

//        private void btnsearch_Click(object sender, EventArgs e)
//        {
//            BindGrid();
//        }

//        private void btnrefresh_Click(object sender, EventArgs e)
//        {
//            txtname.Clear();
//            txtemail.Clear();
//            txtmobile.Clear();
//            txtaddress.Clear();

//            BindGrid();
//        }
//    }
//}

using System;
using System.Data;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class FrmViewRegistration : Form
    {
        DataManager DM = new DataManager();

        public FrmViewRegistration()
        {
            InitializeComponent();

        }
        private void FrmViewRegistration_Load(object sender, EventArgs e)
        {
            dgvRegistration.AllowUserToAddRows = false;
            dgvRegistration.AutoGenerateColumns = false;

            dgvRegistration.Columns["colslno"].DataPropertyName = "SlNo";
            dgvRegistration.Columns["contactinfo"].DataPropertyName = "ContactInfo";

            dgvRegistration.Columns["colregdate"]
                .DefaultCellStyle.Format = "dd-MM-yyyy";

            dgvRegistration.Columns["contactinfo"]
                .DefaultCellStyle.WrapMode =
                DataGridViewTriState.True;

            dgvRegistration.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            //dgvRegistration.AutoSizeRowsMode =
            //    DataGridViewAutoSizeRowsMode.AllCells;
            dgvRegistration.AutoSizeRowsMode =
    DataGridViewAutoSizeRowsMode.None;

            dgvRegistration.RowTemplate.Height = 45;
         //   dgvRegistration.RowTemplate.Height = 40;
            dgvRegistration.Columns["contactinfo"].FillWeight = 180;
            this.BeginInvoke(new MethodInvoker(delegate
            {
                BindGrid();
            }));
        }
      
        //private void FrmViewRegistration_Load(object sender, EventArgs e)
        //{
        //    dgvRegistration.AllowUserToAddRows = false;
        //    dgvRegistration.AutoGenerateColumns = false;

        //    // IMPORTANT:
        //    // Set the DataPropertyName here instead of depending on Designer
        //    dgvRegistration.Columns["colslno"].DataPropertyName = "SlNo";
        //    dgvRegistration.Columns["contactinfo"].DataPropertyName = "ContactInfo";

        //    dgvRegistration.Columns["colregdate"]
        //        .DefaultCellStyle.Format = "dd-MM-yyyy";

        //    dgvRegistration.Columns["contactinfo"]
        //        .DefaultCellStyle.WrapMode =
        //        DataGridViewTriState.True;

        //    dgvRegistration.AutoSizeColumnsMode =
        //        DataGridViewAutoSizeColumnsMode.Fill;

        //    dgvRegistration.AutoSizeRowsMode =
        //        DataGridViewAutoSizeRowsMode.AllCells;

        //    BindGrid();
        //}

        private void BindGrid()
        {
            string qry = "SELECT " +
                         "ROW_NUMBER() OVER (ORDER BY reg_Mid DESC) AS SlNo, " +
                         "reg_Mid, " +
                         "reg_name, " +
                         "reg_email, " +
                         "reg_mobile, " +
                         "reg_password, " +
                         "reg_address, " +
                         "reg_CreatedOn, " +
                         "CONCAT(reg_email, CHAR(13), CHAR(10), reg_mobile) AS ContactInfo " +
                   //      "reg_email + CHAR(13) + CHAR(10) + reg_mobile AS ContactInfo " +
                         "FROM tbl_registration " +
                         "WHERE reg_Activeflag = 1";

            if (txtname.Text.Trim() != "")
            {
                qry += " AND reg_name LIKE '%" +
                       txtname.Text.Trim() + "%'";
            }

            if (txtemail.Text.Trim() != "")
            {
                qry += " AND reg_email LIKE '%" +
                       txtemail.Text.Trim() + "%'";
            }

            if (txtmobile.Text.Trim() != "")
            {
                qry += " AND reg_mobile LIKE '%" +
                       txtmobile.Text.Trim() + "%'";
            }

            if (txtaddress.Text.Trim() != "")
            {
                qry += " AND reg_address LIKE '%" +
                       txtaddress.Text.Trim() + "%'";
            }

            qry += " ORDER BY reg_Mid DESC";

            try
            {
                DataSet ds = DM.GetDataSet(qry);

                if (ds != null &&
                    ds.Tables.Count > 0 &&
                    ds.Tables[0].Rows.Count > 0)
                {
                    dgvRegistration.DataSource = null;

                    dgvRegistration.DataSource = ds.Tables[0];
                    //this.BeginInvoke(new MethodInvoker(delegate
                    //{
                    //    dgvRegistration.AutoResizeRows(
                    //        DataGridViewAutoSizeRowsMode.AllCells);

                    //    if (dgvRegistration.Rows.Count > 0)
                    //    {
                    //        dgvRegistration.AutoResizeRow(
                    //            0,
                    //            DataGridViewAutoSizeRowMode.AllCells);
                    //    }
                    //}));
                }
                else
                {
                    dgvRegistration.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            txtname.Clear();
            txtemail.Clear();
            txtmobile.Clear();
            txtaddress.Clear();

            BindGrid();
        }
    }
}
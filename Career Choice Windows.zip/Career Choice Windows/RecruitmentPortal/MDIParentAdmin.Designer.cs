﻿namespace RecruitmentPortal
{
    partial class MDIParentAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addPostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.addPostToolStripMenuItem,
            this.viewApplicationToolStripMenuItem,
            this.viewRegistrationToolStripMenuItem,
            this.changePasswordeToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1520, 28);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(62, 24);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // addPostToolStripMenuItem
            // 
            this.addPostToolStripMenuItem.Name = "addPostToolStripMenuItem";
            this.addPostToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.addPostToolStripMenuItem.Text = "Add Post";
            this.addPostToolStripMenuItem.Click += new System.EventHandler(this.addPostToolStripMenuItem_Click);
            // 
            // viewApplicationToolStripMenuItem
            // 
            this.viewApplicationToolStripMenuItem.Name = "viewApplicationToolStripMenuItem";
            this.viewApplicationToolStripMenuItem.Size = new System.Drawing.Size(134, 24);
            this.viewApplicationToolStripMenuItem.Text = "View Application";
            this.viewApplicationToolStripMenuItem.Click += new System.EventHandler(this.viewApplicationToolStripMenuItem_Click);
            // 
            // viewRegistrationToolStripMenuItem
            // 
            this.viewRegistrationToolStripMenuItem.Name = "viewRegistrationToolStripMenuItem";
            this.viewRegistrationToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
            this.viewRegistrationToolStripMenuItem.Text = "View Registration";
            this.viewRegistrationToolStripMenuItem.Click += new System.EventHandler(this.viewRegistrationToolStripMenuItem_Click);
            // 
            // changePasswordeToolStripMenuItem
            // 
            this.changePasswordeToolStripMenuItem.Name = "changePasswordeToolStripMenuItem";
            this.changePasswordeToolStripMenuItem.Size = new System.Drawing.Size(136, 24);
            this.changePasswordeToolStripMenuItem.Text = "Change Password";
            this.changePasswordeToolStripMenuItem.Click += new System.EventHandler(this.changePasswordeToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 845);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip.Size = new System.Drawing.Size(1520, 25);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(49, 20);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // MDIParentAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1520, 870);
            this.ControlBox = false;
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1300, 700);
            this.Name = "MDIParentAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MDIParentAdmin";
            this.Load += new System.EventHandler(this.MDIParentAdmin_Load);
            this.Shown += new System.EventHandler(this.MDIParentAdmin_Shown);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addPostToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewApplicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewRegistrationToolStripMenuItem;
    }
}




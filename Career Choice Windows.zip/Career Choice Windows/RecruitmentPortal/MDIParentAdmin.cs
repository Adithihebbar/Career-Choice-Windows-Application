﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class MDIParentAdmin : Form
    {
        public MDIParentAdmin()
        {
            InitializeComponent();

            this.IsMdiContainer = true;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Prevent DPI / font scaling from changing the form size
            this.AutoScaleMode = AutoScaleMode.None;
            this.AutoSize = false;

            // Fixed size
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.WindowState = FormWindowState.Normal;

            this.MinimumSize = new Size(1100, 700);
            this.MaximumSize = new Size(1100, 700);
            this.ClientSize = new Size(1100, 700);
         //   SetMdiClientColor();
            this.BackColor = Color.AliceBlue;
            this.IsMdiContainer = true;
        }

        private void CloseOpenForm()
        {
            foreach (Form frm in this.MdiChildren)
            {
                frm.Close();
            }
        }
        private void OpenChildForm(Form frm)
        {
            CloseOpenForm();

            frm.MdiParent = this;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            frm.ShowInTaskbar = false;

            frm.Show();
        }
        //private void SetMdiClientColor()
        //{
        //    foreach (Control control in this.Controls)
        //    {
        //        if (control is MdiClient)
        //        {
        //            control.BackColor = Color.AliceBlue;
        //            control.Dock = DockStyle.Fill;
        //        }
        //    }
        //}
        private void MDIParentAdmin_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Normal;
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmHomepageAdmin());
        }
        private void addPostToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmAddpost());
        }

        private void viewApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmViewApplication());
        }

        private void changePasswordeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmChangePassword());
        }

        private void MDIParentAdmin_Shown(object sender, EventArgs e)
        {
            homeToolStripMenuItem_Click(sender, e);
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseOpenForm();

            Program.LoginMid = 0;

            FrmAdminLogin login = new FrmAdminLogin();
            login.Show();

            this.Close();
        }

        private void viewRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmViewRegistration());
        }
    }
}




//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Windows.Forms;

//namespace RecruitmentPortal
//{
//    public partial class MDIParentAdmin : Form
//    {
//        public MDIParentAdmin()
//        {
//            InitializeComponent();
//            // Open the MDI parent as a normal window
//            this.WindowState = FormWindowState.Normal;
//            this.StartPosition = FormStartPosition.CenterScreen;

//            // Set the size of the main window
//            this.ClientSize = new Size(1100, 700);
//        }

//        private void CloseOpenForm()
//        {
//            foreach (Form frm in this.MdiChildren)
//            {
//                frm.Close();
//            }
//        }

//        private void MDIParentAdmin_Load(object sender, EventArgs e)
//        {
//            this.IsMdiContainer = true;
//            this.StartPosition = FormStartPosition.CenterScreen;
//            this.WindowState = FormWindowState.Normal;
//        }
//        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            CloseOpenForm();

//            FrmHomepageAdmin frmHome = new FrmHomepageAdmin();
//            frmHome.MdiParent = this;
//            frmHome.WindowState = FormWindowState.Maximized;
//            frmHome.FormBorderStyle = FormBorderStyle.None;
//            frmHome.Dock = DockStyle.Fill;
//            frmHome.Show();

//        }

//        private void addPostToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            CloseOpenForm();

//            FrmAddpost frmApp = new FrmAddpost();
//            frmApp.MdiParent = this;
//            frmApp.WindowState = FormWindowState.Maximized;
//            frmApp.FormBorderStyle = FormBorderStyle.None;
//            frmApp.Dock = DockStyle.Fill;
//            frmApp.Show();
//        }

//        private void viewApplicationToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            CloseOpenForm();

//            FrmViewApplication frmApp = new FrmViewApplication();
//            frmApp.MdiParent = this;
//            frmApp.WindowState = FormWindowState.Maximized;
//            frmApp.FormBorderStyle = FormBorderStyle.None;
//            frmApp.Dock = DockStyle.Fill;
//            frmApp.Show();
//        }

//        private void MDIParentAdmin_Shown(object sender, EventArgs e)
//        {
//            homeToolStripMenuItem_Click(sender, e);
//        }

//        private void changePasswordeToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            CloseOpenForm();
//            FrmChangePassword frmApp = new FrmChangePassword();
//            frmApp.MdiParent = this;
//            frmApp.WindowState = FormWindowState.Maximized;
//            frmApp.FormBorderStyle = FormBorderStyle.None;
//            frmApp.Dock = DockStyle.Fill;
//            frmApp.Show();
//        }

//        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            CloseOpenForm();
//            Program.LoginMid = 0;
//            FrmAdminLogin login = new FrmAdminLogin();
//            login.Show();

//            this.Close();
//        }
//    }
//}

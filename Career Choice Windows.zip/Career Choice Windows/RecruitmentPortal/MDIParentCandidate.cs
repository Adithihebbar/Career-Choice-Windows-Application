﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    public partial class MDIParentCandidate : Form
    {
        public MDIParentCandidate()
        {
            InitializeComponent();

            this.IsMdiContainer = true;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Prevent DPI / font scaling from changing the form size
            this.AutoScaleMode = AutoScaleMode.None;
            this.AutoSize = false;

            // Fixed size
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.WindowState = FormWindowState.Normal;

            this.MinimumSize = new Size(1100, 700);
            this.MaximumSize = new Size(1100, 700);
            this.ClientSize = new Size(1100, 700);
        }

        private void CloseOpenForm()
        {
            foreach (Form frm in this.MdiChildren)
            {
                frm.Close();
            }
        }

        private void OpenChildForm(Form frm)
        {
            CloseOpenForm();

            frm.MdiParent = this;
            frm.WindowState = FormWindowState.Normal;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            frm.ShowInTaskbar = false;

            frm.Show();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmCandiateHome());
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmCandidateChangePaswrd());
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseOpenForm();

            Program.LoginMid = 0;

            FrmCandidateLogin login = new FrmCandidateLogin();
            login.Show();

            this.Close();
        }

        private void MDIParentCandidate_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Normal;
            foreach (Control c in this.Controls)
            {
                if (c is MdiClient)
                {
                    c.BackColor = Color.AliceBlue;
                }
            }
        }

        private void MDIParentCandidate_Shown(object sender, EventArgs e)
        {
            homeToolStripMenuItem_Click(sender, e);
        }
    }
}



//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Windows.Forms;

//namespace RecruitmentPortal
//{
//    public partial class MDIParentCandidate : Form
//    {
//        public MDIParentCandidate()
//        {
//            InitializeComponent();

//            // Open the MDI parent as a normal window
//            this.WindowState = FormWindowState.Normal;
//            this.StartPosition = FormStartPosition.CenterScreen;

//            // Set the size of the main window
//            this.ClientSize = new Size(1100, 700);
//        }

//        private void CloseOpenForm()
//        {
//            foreach (Form frm in this.MdiChildren)
//            {
//                frm.Close();
//            }
//        }

//        private void OpenChildForm(Form frm)
//        {
//            CloseOpenForm();

//            // Keep the form as an MDI child
//            frm.MdiParent = this;

//            // Child fills the MDI area
//            frm.FormBorderStyle = FormBorderStyle.None;
//            frm.Dock = DockStyle.Fill;
//            frm.ShowInTaskbar = false;

//            frm.Show();
//        }

//        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            OpenChildForm(new FrmCandiateHome());
//        }

//        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            OpenChildForm(new FrmCandidateChangePaswrd());
//        }

//        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
//        {
//            CloseOpenForm();

//            Program.LoginMid = 0;

//            FrmCandidateLogin login = new FrmCandidateLogin();
//            login.Show();

//            this.Close();
//        }

//        private void MDIParentCandidate_Load(object sender, EventArgs e)
//        {
//            // Make sure the parent does NOT maximize
//            this.WindowState = FormWindowState.Normal;

//            // Set MDI background color
//            foreach (Control c in this.Controls)
//            {
//                if (c is MdiClient)
//                {
//                    c.BackColor = SystemColors.Control;
//                }
//            }
//        }

//        private void MDIParentCandidate_Shown(object sender, EventArgs e)
//        {
//            homeToolStripMenuItem_Click(sender, e);
//        }
//    }
//}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace RecruitmentPortal
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
         // Application.Run(new FrmViewRegistration());
           Application.Run(new FrmCareerChoice());
        }
        public static int LoginMid = 0;
        public static int ChildFormWidth;
        public static int ChildFormHeight;
    }
}

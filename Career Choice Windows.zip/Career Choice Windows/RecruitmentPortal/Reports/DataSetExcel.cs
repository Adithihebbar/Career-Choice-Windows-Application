﻿namespace RecruitmentPortal.Reports {
    
    
    public partial class DataSetExcel {
        partial class DTAddpostDataTable
        {
        }
    }
}
